using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerInputAbility : PlayerAbility
{
    private const float SCREEN_SPLIT_RATIO = 0.5f;

    [SerializeField] private bool _useHitSound;
    [SerializeField] private float _inputQueueTime = 0.2f; // 입력 큐 유지 시간 (0.2초로 증가)

    // 입력 상태
    private bool _isUpPressed;
    private bool _isLeftPressed;
    private bool _isRightPressed;
    private bool _anyButtonDown;

    // MultiTap 상태
    private bool _isTappingNoteActive;
    private int _tapCount;

    // TapTap 상태
    private bool _isTapTapInProgress;
    private Note _currentDoubleTapNote; // DoubleTap 노트 저장

    // 입력 큐 시스템
    private struct InputEvent
    {
        public EDirectionType Direction;
        public float Time;
        public bool IsPress;
    }
    private Queue<InputEvent> _inputQueue = new Queue<InputEvent>();
    private HashSet<EDirectionType> _currentlyPressed = new HashSet<EDirectionType>();

    public event Action<int> OnMultiTap;
    public event Action OnMultiTapEnd;

    private void Start()
    {
    }

    private void OnDestroy()
    {
    }

    private void Update()
    {
        ProcessInput();

        if (_owner.GetAbility<PlayerMovementAbility>().IsMoving) return;

        if (_isTappingNoteActive)
        {
            HandleMultiTapInput();
        }
        else
        {
            HandleNormalInput();
        }
    }

    private void ProcessInput()
    {
        ResetInputState();
        CleanupInputQueue();

#if UNITY_EDITOR || UNITY_STANDALONE
        ProcessKeyboardInput();
#elif UNITY_ANDROID || UNITY_IOS
        ProcessTouchInput();
#endif     
        ProcessInputQueue();
    }

    private void ResetInputState()
    {
        _isLeftPressed = false;
        _isRightPressed = false;
        _isUpPressed = false;
        _anyButtonDown = false;
    }

    private void CleanupInputQueue()
    {
        // 오래된 입력 이벤트 제거
        float currentTime = Time.time;
        while (_inputQueue.Count > 0 && currentTime - _inputQueue.Peek().Time > _inputQueueTime)
        {
            _inputQueue.Dequeue();
        }
    }

    private void AddInputEvent(EDirectionType direction, bool isPress)
    {
        _inputQueue.Enqueue(new InputEvent
        {
            Direction = direction,
            Time = Time.time,
            IsPress = isPress
        });

        if (isPress)
        {
            _currentlyPressed.Add(direction);
        }
        else
        {
            _currentlyPressed.Remove(direction);
        }
    }

    private void ProcessInputQueue()
    {
        // 다음 노트가 Up 방향인지 확인
        bool isNextNoteUp = false;
        if (NoteManager.Instance != null && NoteManager.Instance.TryGetCurrentNote(out Note currentNote))
        {
            isNextNoteUp = currentNote.TargetDir == EDirectionType.Up;
        }

        // 현재 눌려있는 상태 확인
        bool isLeftCurrentlyPressed = _currentlyPressed.Contains(EDirectionType.Left);
        bool isRightCurrentlyPressed = _currentlyPressed.Contains(EDirectionType.Right);

        // 큐에서 Left와 Right 입력이 모두 있는지 확인
        bool hasLeftPress = false;
        bool hasRightPress = false;
        bool leftJustPressed = false;
        bool rightJustPressed = false;

        foreach (var inputEvent in _inputQueue)
        {
            if (inputEvent.IsPress)
            {
                if (inputEvent.Direction == EDirectionType.Left)
                {
                    hasLeftPress = true;
                    if (Time.time - inputEvent.Time < Time.deltaTime * 2)
                        leftJustPressed = true;
                }
                else if (inputEvent.Direction == EDirectionType.Right)
                {
                    hasRightPress = true;
                    if (Time.time - inputEvent.Time < Time.deltaTime * 2)
                        rightJustPressed = true;
                }
            }
        }

        // Up 입력 처리: 큐에 둘 다 있거나, 현재 둘 다 눌려있으면 OK
        bool canBeUpInput = (hasLeftPress && hasRightPress) || (isLeftCurrentlyPressed && isRightCurrentlyPressed);

        if (isNextNoteUp && canBeUpInput)
        {
            _isUpPressed = true;
            _anyButtonDown = leftJustPressed || rightJustPressed || _anyButtonDown;
        }
        else
        {
            // 일반 입력 처리
            _isLeftPressed = isLeftCurrentlyPressed;
            _isRightPressed = isRightCurrentlyPressed;
        }
    }

    private void ProcessKeyboardInput()
    {
        bool keyDownLeft = Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow);
        bool keyDownRight = Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow);

        bool keyUpLeft = Input.GetKeyUp(KeyCode.A) || Input.GetKeyUp(KeyCode.LeftArrow);
        bool keyUpRight = Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.RightArrow);

        // 입력 큐에 이벤트 추가
        if (keyDownLeft)
        {
            AddInputEvent(EDirectionType.Left, true);
            _anyButtonDown = true;
        }
        if (keyDownRight)
        {
            AddInputEvent(EDirectionType.Right, true);
            _anyButtonDown = true;
        }
        if (keyUpLeft)
        {
            AddInputEvent(EDirectionType.Left, false);
        }
        if (keyUpRight)
        {
            AddInputEvent(EDirectionType.Right, false);
        }
    }

    private void ProcessTouchInput()
    {
        foreach (Touch touch in Input.touches)
        {
            if (EventSystem.current.IsPointerOverGameObject(touch.fingerId))
                continue;

            bool isLeftSide = touch.position.x < Screen.width * SCREEN_SPLIT_RATIO;

            if (isLeftSide)
            {
                ProcessLeftTouch(touch);
            }
            else
            {
                ProcessRightTouch(touch);
            }
        }

    }

    private void ProcessLeftTouch(Touch touch)
    {
        switch (touch.phase)
        {
            case TouchPhase.Began:
                AddInputEvent(EDirectionType.Left, true);
                _anyButtonDown = true;
                break;

            case TouchPhase.Moved:
            case TouchPhase.Stationary:
                // 터치가 유지되는 동안은 입력 상태만 유지
                break;

            case TouchPhase.Ended:
            case TouchPhase.Canceled:
                AddInputEvent(EDirectionType.Left, false);
                break;
        }
    }

    private void ProcessRightTouch(Touch touch)
    {
        switch (touch.phase)
        {
            case TouchPhase.Began:
                AddInputEvent(EDirectionType.Right, true);
                _anyButtonDown = true;
                break;

            case TouchPhase.Moved:
            case TouchPhase.Stationary:
                // 터치가 유지되는 동안은 입력 상태만 유지
                break;

            case TouchPhase.Ended:
            case TouchPhase.Canceled:
                AddInputEvent(EDirectionType.Right, false);
                break;
        }
    }


    private bool IsUpPressed() => _isUpPressed;
    private bool IsLeftPressed() => _isLeftPressed && !_isUpPressed;
    private bool IsRightPressed() => _isRightPressed && !_isUpPressed;
    private bool AnyDirectionalInputDown() => _anyButtonDown;
    private bool AnyTapInputDown() => _anyButtonDown;


    private void HandleNormalInput()
    {
        if (AnyDirectionalInputDown())
        {
            if (NoteManager.Instance.TryGetCurrentNote(out var note))
            {
                switch (note.NoteType)
                {
                    case ENoteType.MultiTapNote:
                        StartMultiTapHandling();
                        break;
                    default:
                        CheckTapNote();
                        break;
                }
            }
        }
    }

    private void HandleMultiTapInput()
    {
        // 멀티탭 종료 시점 확인 (다음 노트의 타겟 타임 - 배드 윈도우)
        double multiTapEndTime = NoteManager.Instance.GetMultiTapEndTime();

        if (NoteManager.Instance.SongPosition >= multiTapEndTime)
        {
            // 종료 시점이 지나면 멀티탭 종료
            ProcessMultiTapNote();
            return;
        }

        // 종료 시점 전까지 계속 탭 가능
        if (AnyTapInputDown())
        {
            ObjectPool.Instance.Get(EPoolType.NoteHitVfx).transform.position = transform.position;
            SoundManager.Instance.PlayHitSound(SoundType.SFX_HitSound);

            _tapCount++;
            OnMultiTap?.Invoke(_tapCount);
        }
    }

    private void CheckTapNote()
    {
        // 현재 노트의 타겟 방향이 눌려있는지 확인
        if (!NoteManager.Instance.TryGetCurrentNote(out Note targetNote))
            return;

        EDirectionType targetDirection = targetNote.TargetDir;

        // 타겟 방향이 눌려있으면 성공
        if (IsDirectionPressed(targetDirection))
        {
            ProcessTapNote(targetDirection);
        }
        else
        {
            // 타겟 방향이 안 눌려있는데 다른 방향이 눌려있으면 Miss
            EDirectionType wrongDirection = GetCurrentPressedDirection();
            if (wrongDirection != EDirectionType.None)
            {
                ProcessTapNote(wrongDirection); // NoteManager에서 Miss 처리됨
            }
        }
    }



    private EDirectionType GetCurrentPressedDirection(EDirectionType excludeDirection = EDirectionType.None)
    {

        if (IsUpPressed() && excludeDirection != EDirectionType.Up)
            return EDirectionType.Up;
        if (IsLeftPressed() && excludeDirection != EDirectionType.Left)
            return EDirectionType.Left;
        if (IsRightPressed() && excludeDirection != EDirectionType.Right)
            return EDirectionType.Right;


        return EDirectionType.None;
    }

    private void ProcessTapNote(EDirectionType direction)
    {
        if (!NoteManager.Instance.TryGetCurrentNote(out Note targetNote))
            return;

        bool isHit = NoteManager.Instance.CheckTapNote(direction, out EJudgement judgement);

        if (isHit)
        {
            if (targetNote.TargetDir == EDirectionType.Left)
                _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.LeftJump, judgement);
            else if (targetNote.TargetDir == EDirectionType.Right)
                _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.RightJump, judgement);
            else if (targetNote.TargetDir == EDirectionType.Up)
            {
                // Up 방향일 때 랜덤으로 왼쪽/오른쪽 애니메이션 선택
                bool isLeft = UnityEngine.Random.Range(0, 2) == 0;
                _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(
                    isLeft ? EPlayerAnimState.LeftJump : EPlayerAnimState.RightJump, judgement
                );
            }


            if (_useHitSound)
            {
                SoundManager.Instance.PlayHitSound(SoundType.SFX_HitSound);
            }

            _owner.GetAbility<PlayerMovementAbility>().MoveToTile(targetNote);
        }
    }

    // 특정 방향이 현재 눌려있는지 확인 (다른 버튼 상태는 무시)
    private bool IsDirectionPressed(EDirectionType direction)
    {
        switch (direction)
        {
            case EDirectionType.Up:
                return IsUpPressed();
            case EDirectionType.Left:
                return IsLeftPressed();
            case EDirectionType.Right:
                return IsRightPressed();
            default:
                return false;
        }
    }

    private void StartMultiTapHandling()
    {
        _isTappingNoteActive = true;
        _tapCount = 1;
        OnMultiTap?.Invoke(_tapCount);

        if (NoteManager.Instance.TryGetCurrentNote(out Note targetNote))
        {
            _owner.GetAbility<PlayerMovementAbility>().MoveToTile(targetNote, skipTileDestruction: false);
        }

        CameraShake.Instance.DoZoom(2.5f, 0.2f);
    }

    private void StopMultiTapHandling()
    {
        _isTappingNoteActive = false;
        _tapCount = 0;
        OnMultiTapEnd?.Invoke();
        CameraShake.Instance.ResetZoom(0.2f);
    }


    private void ProcessMultiTapNote()
    {
        if (!NoteManager.Instance.TryGetCurrentNote(out Note targetNote))
            return;

        bool isHit = NoteManager.Instance.CheckMultiTapNote();

        if (isHit)
        {
            if (_useHitSound)
            {
                SoundManager.Instance.PlayHitSound(SoundType.SFX_HitSound);
            }

            if (NoteManager.Instance != null)
            {
                NoteManager.Instance.NotifyPlayerPassedTile(targetNote);
            }
        }

        StopMultiTapHandling();
    }

}
