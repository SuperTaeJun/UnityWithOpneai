using UnityEngine;
using DG.Tweening;
using System.Collections;
using System;

public class PlayerMovementAbility : PlayerAbility
{
    [Header("이동 설정")]
    [SerializeField] private float _moveDuration = 0.1f;
    [SerializeField] private float _minMoveDuration = 0.03f; // 최소 이동 시간
    [SerializeField] private float _maxMoveDuration = 0.15f; // 최대 이동 시간
    [SerializeField] private float _moveTimeRatio = 0.7f; // 다음 노트까지 시간의 몇 %를 이동에 사용할지
    [SerializeField] private float _jumpPower = 0.5f;
    [Tooltip("점프할때 최고 지점의 도달하는데 걸리는 시간의 비율 ex) 0.3 = 전체 시간중 최고 지점에 도달하는데 30% 필요")]
    [SerializeField] private float _ascentRatio = 0.4f;
    private bool _isMoving = false;
    public bool IsMoving => _isMoving;

    private Note _targetNote; // 이동할 타겟 노트
    private Note _previousNote; // 이전에 있던 노트 (파괴할 타일)
    private bool _skipTileDestruction = false; // 타일 파괴를 건너뛸지 여부 (멀티탭용)
    private bool _isHoldSliding = false; // 홀드 노트 슬라이딩 중인지 여부

    // 카메라 이동을 위한 이벤트
    public static event Action<Vector2> OnPlayerTargetPositionChanged;


    //-----------------------임시

    // 엘리베이터(순수 Y기준) 옵션
    [SerializeField] private bool _enableElevatorAssist = true;
    [SerializeField] private float _yGapThreshold = 1.0f;        // 다음 타일과 현재 타일 Y 차가 이 값 이상일 때만 시작
    [SerializeField] private float _elevatorOffsetFromNext = 1.0f; // 항상 nextY - offset에서 멈춤(항상 아래)
    [SerializeField] private float _elevatorMaxDeltaY = 4.0f;     // 1회 최대 상승량(과도한 점프 방지)

    private DG.Tweening.Tween _elevatorPlayerTween;
    private DG.Tweening.Tween _elevatorTileTween;
    private bool _elevatorActive = false;

    private TileSpawner _tileSpawner;

    private void Start()
    {
        NoteManager.Instance.OnMiss += OnMissMove;
        _tileSpawner = FindObjectOfType<TileSpawner>();
    }

    private void OnDestroy()
    {

        NoteManager.Instance.OnMiss -= OnMissMove;

    }
    private void TryStartElevatorAssistAfterLanding()
    {
        if (!_enableElevatorAssist) return;
        if (_targetNote == null) return;
        if (_tileSpawner == null) return;

        // 다음 노트 있어야 함
        if (!NoteManager.Instance.TryGetCurrentNote(out Note nextNote)) return;

        // 현재(착지) 타일 객체
        var currentTile = _tileSpawner.GetTileForNote(_targetNote);
        if (currentTile == null) return;

        // 판정선 속도 필요
        float judgeLineSpeed =  _owner.GetAbility<PlayerJudgeLine>().YMoveSpeed;
        if (judgeLineSpeed <= 0f) return;

        float currentY = currentTile.transform.position.y;
        float nextY = nextNote.TilePosition.y;

        // 다음 타일이 "위"에 있고, Y 격차가 임계 이상일 때만
        float gap = nextY - currentY;
        if (gap <= _yGapThreshold) return;

        Debug.Log($"엘리베이터 어시스트 시작: 현재Y={currentY:F2}, 다음Y={nextY:F2}, 격차={gap:F2}");

        // 항상 다음 타일 "아래"에서 멈춘다
        float desiredOffset = Mathf.Max(0.001f, _elevatorOffsetFromNext); // 음수 금지
        float targetY = nextY - desiredOffset;

        // 한 번의 상승량 제한
        float deltaY = Mathf.Clamp(targetY - currentY, 0f, _elevatorMaxDeltaY);
        targetY = currentY + deltaY;

        float distance = Mathf.Abs(targetY - currentY);
        if (distance <= 0.0001f) return;

        // ★ 판정선과 동일한 속도 → duration = 거리 / 속도
        float duration = distance / judgeLineSpeed;

        _elevatorActive = true;

        // 플레이어 & 현재 타일을 같은 Y로, 선형 이동(오버슈트 없음)
        _elevatorTileTween = currentTile.transform.DOMoveY(targetY, duration).SetEase(Ease.Linear);
        _elevatorPlayerTween = _owner.transform.DOMoveY(targetY, duration).SetEase(Ease.Linear);

        _elevatorTileTween.onKill += () => _elevatorActive = false;
        _elevatorPlayerTween.onKill += () => _elevatorActive = false;

        // (선택) 동기화: 이후 로직이 TilePosition을 읽을 수 있으니 맞춰두기
        _targetNote.SetTilePosition(new Vector2(_targetNote.TilePosition.x, targetY));
    }
    private void StopElevatorIfActive()
    {
        if (_elevatorActive)
        {
            _elevatorPlayerTween?.Kill();
            _elevatorTileTween?.Kill();
            _elevatorActive = false;
        }
    }

    /// 특정 노트 위치로 이동합니다
    public void MoveToTile(Note targetNote, bool skipTileDestruction = false, bool startHoldSlide = false, bool forceMissMove = false)
    {
        if (_isMoving) return;

        StopElevatorIfActive();
        // Miss 이동이 아닐 때만 홀드 슬라이딩 체크
        if (!forceMissMove && _isHoldSliding) return; // 홀드 슬라이딩 중에는 새로운 이동 불가
        if (targetNote == null) return;
        if (targetNote.NoteType == ENoteType.HoldTap) return;

        // 이전 노트를 저장 (현재 있는 타일)
        _previousNote = _targetNote;
        _targetNote = targetNote;
        _skipTileDestruction = skipTileDestruction;

        Vector2 destination = targetNote.TilePosition;

        // 목적지가 현재 위치와 같다면 이동하지 않음
        if ((Vector2)transform.position == destination) return;

        _owner.GetAbility<PlayerVisualAbility>().SpawnMoveVfx();

        _isMoving = true;

        // 동적으로 이동 시간 계산
        float dynamicMoveDuration = CalculateDynamicMoveDuration(targetNote);

        Debug.Log($"다이나믹시간 :{dynamicMoveDuration}");
        // 홀드 노트인 경우 endPosition과 holdDuration 전달
        if (startHoldSlide && targetNote.NoteType == ENoteType.Hold)
        {
            JumpAnim(destination, dynamicMoveDuration);
        }
        else
        {
            JumpAnim(destination, dynamicMoveDuration);
        }
    }

    /// 현재 노트 위치로 이동합니다 (Miss 처리용)
    public void MissMoveToTile()
    {
        if (_isMoving) return;
        StopElevatorIfActive();
        // Miss 시에는 현재 노트 위치로 이동
        if (NoteManager.Instance.TryGetCurrentNote(out Note note))
        {
            if (note.NoteType == ENoteType.HoldTap) return;

            MoveToTile(note, skipTileDestruction: false, startHoldSlide: false, forceMissMove: true);
        }
    }

    /// 다음 노트까지의 시간을 고려하여 동적으로 이동 시간을 계산합니다
    private float CalculateDynamicMoveDuration(Note currentNote)
    {
        // 기본 이동 시간
        float calculatedDuration = _moveDuration;

        // NoteManager에서 현재 노트 정보 가져오기 (currentNote는 이미 Dequeue되었을 수 있음)
        if (NoteManager.Instance != null && NoteManager.Instance.TryGetCurrentNote(out Note actualCurrentNote))
        {
            // actualCurrentNote가 실제 다음에 쳐야 할 노트
            float timeBetweenNotes = (float)(actualCurrentNote.TargetTime - currentNote.TargetTime);

            Debug.Log($"[MoveDuration] 이동할 노트 시간: {currentNote.TargetTime:F3}, 다음 노트 시간: {actualCurrentNote.TargetTime:F3}");
            Debug.Log($"[MoveDuration] 노트 간격: {timeBetweenNotes:F3}초");

            // 다음 노트까지의 시간이 충분하지 않으면 이동 시간을 줄임
            if (timeBetweenNotes > 0)
            {
                // 다음 노트까지 시간의 일정 비율만 이동에 사용
                float adjustedDuration = timeBetweenNotes * _moveTimeRatio;

                Debug.Log($"[MoveDuration] 조정된 시간 (간격 * {_moveTimeRatio}): {adjustedDuration:F3}초");
                Debug.Log($"[MoveDuration] Min: {_minMoveDuration:F3}, Max: {_maxMoveDuration:F3}");

                // 최소/최대 범위 내로 제한
                calculatedDuration = Mathf.Clamp(adjustedDuration, _minMoveDuration, _maxMoveDuration);

                Debug.Log($"[MoveDuration] 최종 이동 시간: {calculatedDuration:F3}초");
            }
            else
            {
                // 다음 노트가 현재 노트보다 이전이거나 같은 시간이면 기본값 사용
                Debug.Log($"[MoveDuration] 노트 간격이 0 이하, 기본값 사용: {calculatedDuration:F3}초");
            }
        }
        else
        {
            Debug.Log($"[MoveDuration] 다음 노트 없음, 기본값 사용: {calculatedDuration:F3}초");
        }

        return calculatedDuration;
    }

    private void JumpAnim(Vector2 destination, float moveDuration = 0.1f)
    {

        // 카메라에게 목표 지점 알림 (점프 시작 시)
        OnPlayerTargetPositionChanged?.Invoke(destination);

        if (!_skipTileDestruction && _previousNote != null && NoteManager.Instance != null)
        {
            NoteManager.Instance.NotifyPlayerPassedTile(_previousNote);
        }
        _skipTileDestruction = false;

        // 커스텀 점프: X축과 Y축을 분리하여 다른 속도로 제어
        Vector3 startPos = _owner.transform.position;
        float ascentDuration = moveDuration * _ascentRatio; // 상승 시간
        float descentDuration = moveDuration * (1f - _ascentRatio); // 하강 시간

        // X축 이동 (전체 시간 동안 일정하게)
        _owner.transform.DOMoveX(destination.x, moveDuration).SetEase(Ease.Linear);

        // Y축 이동 (2단계: 빠른 상승 + 느린 하강)
        Sequence jumpSequence = DOTween.Sequence();

        // 1단계: 빠르게 상승 (InQuad - 가속)
        jumpSequence.Append(
            _owner.transform.DOMoveY(startPos.y + _jumpPower, ascentDuration)
            .SetEase(Ease.InQuad)
        );

        // 2단계: 느리게 하강 (OutQuad - 감속)
        jumpSequence.Append(
            _owner.transform.DOMoveY(destination.y, descentDuration)
            .SetEase(Ease.OutQuad)
        );

        jumpSequence.OnComplete(() =>
        {
            _isMoving = false;
            TryStartElevatorAssistAfterLanding();
            //_audio.PlayOneShot(_clip);
        });
    }

    private void OnMissMove()
    {

        MissMoveToTile();
    }

}
