using UnityEngine;

public enum EPlayerAnimState
{
    Idle,
    LeftJump,
    RightJump,
    HoldJump,
    Miss,
}

public class PlayerAnimAbility : PlayerAbility
{
    private Animator _animator;
    private SpriteRenderer _spriteRenderer;
    protected override void Awake()
    {
        base.Awake();
        _animator = GetComponentInParent<Animator>();
        _spriteRenderer = GetComponentInParent<SpriteRenderer>();
    }

    private void Start()
    {
        NoteManager.Instance.OnMiss += () => ChangeAnimState(EPlayerAnimState.Miss);

        ChangeAnimState(EPlayerAnimState.Idle);
    }

    public void ChangeAnimState(EPlayerAnimState state, EJudgement eJudgement = EJudgement.Bad)
    {
        switch (state)
        {
            case EPlayerAnimState.Idle:
                _animator.SetTrigger("Idle");
                break;
            case EPlayerAnimState.LeftJump:
                _spriteRenderer.flipX = true;
                _animator.SetTrigger("LeftJump");
                _animator.SetFloat("JudgeType", (float)eJudgement);
                break;
            case EPlayerAnimState.RightJump:
                _spriteRenderer.flipX = false;
                _animator.SetTrigger("RightJump");
                _animator.SetFloat("JudgeType", (float)eJudgement);
                break;
            case EPlayerAnimState.HoldJump:
                _animator.SetTrigger("HoldJump");
                break;
            case EPlayerAnimState.Miss:
                _animator.SetTrigger("Miss");
                break;
        }
    }

    private void AnimFinish()
    {
        ChangeAnimState(EPlayerAnimState.Idle);
    }
}
