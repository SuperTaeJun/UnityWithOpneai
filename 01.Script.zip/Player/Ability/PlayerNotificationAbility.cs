using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public enum EPlayerNotificationType
{
    MultiTap,
    BossDash,

}
public class PlayerNotificationAbility : PlayerAbility
{
    [SerializeField] private GameObject _dialogBox;
    [SerializeField] private TextMeshProUGUI _dialogText;
    private Vector3 _originalScale;
    private void Start()
    {
        _originalScale = _dialogBox.transform.localScale;
        _owner.GetAbility<PlayerInputAbility>().OnMultiTap += (int cnt) =>
        {
            _dialogText.text = $"Hit|n{cnt}";
            _dialogText.transform.DOKill(true);
            _dialogText.transform.DOPunchScale(Vector3.one * 0.6f, 0.1f, 10, 1);

            if (_dialogBox.activeSelf) return;

            _dialogBox.transform.DOKill();
            _dialogBox.SetActive(true);
            _dialogBox.transform.localScale = Vector3.zero;
            _dialogBox.transform.DOScale(_originalScale, 0.2f).SetEase(Ease.OutBack);
        };

        _owner.GetAbility<PlayerInputAbility>().OnMultiTapEnd += () =>
        {
            _dialogBox.transform.DOKill();
            _dialogBox.transform.DOScale(0, 0.2f).SetEase(Ease.InBack).OnComplete(() =>
            {
                _dialogBox.SetActive(false);
            });
        };
    }
}
