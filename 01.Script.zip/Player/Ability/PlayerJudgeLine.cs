using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerJudgeLine : PlayerAbility
{
    [SerializeField] private Transform _judgeLineTransform;
    [SerializeField] private float _yMoveSpeed = 2f; // 판정선이 위로 올라가는 일정한 속도
    [SerializeField] private float _firstNoteYOffset = 1f; // 첫 번째 노트가 플레이어보다 위에 생성될 오프셋

    public float YMoveSpeed => _yMoveSpeed; // 외부에서 판정선 속도를 참조할 수 있도록
    public float CurrentY => _judgeLineTransform != null ? _judgeLineTransform.position.y : 0f; // 현재 Y 위치
    private void Start()
    {
        // 판정선 초기 위치 설정
        InitializeJudgeLinePosition();
        
        // 초기 Y 위치 저장 (판정선 이동 계산의 기준점)
        _initialYPosition = _judgeLineTransform.position.y;
    }

    private void Update()
    {
        UpdateJudgeLinePosition();
    }

    /// 판정선의 초기 위치를 설정합니다 (첫 번째 노트의 타겟 타임에 플레이어 앞에 도착하도록)
    private void InitializeJudgeLinePosition()
    {
        if (_judgeLineTransform == null || NoteManager.Instance == null) return;

        // 첫 번째 노트를 가져옵니다 (아직 스폰되지 않은 노트 포함)
        if (NoteManager.Instance.TryGetFirstNote(out Note firstNote))
        {
            // 첫 번째 노트의 타겟 타임에 판정선이 플레이어 Y + offset 위치에 도착해야 함
            // 판정선 초기 Y = (플레이어 Y + offset) - (판정선 속도 × 첫 노트 타겟 타임)
            
            float targetY = _owner.transform.position.y + _firstNoteYOffset;
            float timeToTarget = firstNote.TargetTime;
            float distanceToTravel = _yMoveSpeed * timeToTarget;
            float initialJudgeLineY = targetY - distanceToTravel;
            
            // 판정선 위치 설정
            Vector3 judgeLinePos = _judgeLineTransform.position;
            judgeLinePos.y = initialJudgeLineY;
            _judgeLineTransform.position = judgeLinePos;
            
            Debug.Log($"판정선 초기화: 판정선Y={initialJudgeLineY:F2}, 목표Y={targetY:F2}, 이동거리={distanceToTravel:F2}, 타겟타임={timeToTarget:F2}초");
        }
        else
        {
            Debug.LogWarning("첫 번째 노트를 찾을 수 없습니다. 판정선 초기화 실패.");
        }
    }

    private float _initialYPosition;

    /// 판정 라인의 x값은 플레이어 위치로, y값은 SongPosition 기준으로 일정한 속도로 위로 이동합니다
    private void UpdateJudgeLinePosition()
    {
        if (_judgeLineTransform == null || NoteManager.Instance == null) return;

        // SongPosition 기반으로 절대 위치 계산 (노트 타이밍과 동기화)
        float currentSongPosition = (float)NoteManager.Instance.SongPosition;

        // 판정 라인의 x값은 플레이어 위치로 즉시 설정
        // y값은 초기 위치에서 SongPosition * 속도만큼 이동 (절대 위치 계산)
        Vector3 judgeLinePos = _judgeLineTransform.position;
        judgeLinePos.x = _owner.transform.position.x;
        judgeLinePos.y = _initialYPosition + (_yMoveSpeed * currentSongPosition);
        _judgeLineTransform.position = judgeLinePos;
    }
}
