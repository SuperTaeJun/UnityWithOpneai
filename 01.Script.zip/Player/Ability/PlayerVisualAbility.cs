using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerVisualAbility : PlayerAbility
{
    [SerializeField] GameObject _moveVfxPrefab;

    public void SpawnMoveVfx()
    {
        //Instantiate(_moveVfxPrefab).transform.position = _owner.transform.position;
    }

}
