using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class NoteRepository
{
    public Queue<Note> LoadChartAndSetupGame(string songName, bool useDiagonal)
    {
        var textAsset = Resources.Load<TextAsset>($"Charts/{songName}");
        if (textAsset == null)
        {
            Debug.LogError($"차트 파일을 찾을 수 없습니다: Charts/{songName}");

            return null;
        }

        Chart chart = JsonUtility.FromJson<Chart>(textAsset.text);
        Queue<Note> notes = new Queue<Note>();

        if (chart == null) return null;

        // 노트를 TargetTime 기준으로 정렬
        var sortedNotes = chart.notes.OrderBy(noteData => noteData.targetTime).ToList();

        var allDirections = System.Enum.GetValues(typeof(EDirectionType)).Cast<EDirectionType>().ToList();
        allDirections.Remove(EDirectionType.None);
        allDirections.Remove(EDirectionType.Up); // Up은 UpTap 노트에서만 사용, 랜덤 선택에서 제외
        
        EDirectionType lastDirection = EDirectionType.None;
        EDirectionType currentHoldDirection = EDirectionType.None; // ✨ 현재 홀드 노트의 방향
        EDirectionType lastMirrorDirection = EDirectionType.Left; // ✨ Mirror 노트의 마지막 방향 (Left로 시작)

        for (int i = 0; i < sortedNotes.Count; i++)
        {
            var noteData = sortedNotes[i];
            EDirectionType randomDir;

            // ✨ UpTap 노트 처리 - 위쪽으로 고정
            if (noteData.noteType == ENoteType.UpTap)
            {
                randomDir = EDirectionType.Up;
                lastDirection = randomDir;
            }
            // ✨ LeftTap 노트 처리 - 왼쪽으로 고정
            else if (noteData.noteType == ENoteType.LeftTap)
            {
                randomDir = EDirectionType.Left;
                lastDirection = randomDir;
            }
            // ✨ RightTap 노트 처리 - 오른쪽으로 고정
            else if (noteData.noteType == ENoteType.RightTap)
            {
                randomDir = EDirectionType.Right;
                lastDirection = randomDir;
            }
            // ✨ Mirror 노트 처리 - 연속된 Mirror는 좌우 반복
            else if (noteData.noteType == ENoteType.Mirro)
            {
                // 이전 Mirror의 반대 방향으로 설정
                randomDir = GetOppositeDirection(lastMirrorDirection);
                lastMirrorDirection = randomDir;
                lastDirection = randomDir;
            }
            // ✨ 홀드 노트 처리
            else if (noteData.noteType == ENoteType.Hold)
            {
                // 홀드 노트는 Left 또는 Right만 가능
                var holdDirections = new List<EDirectionType> { EDirectionType.Left, EDirectionType.Right };
                
                // 이전 방향의 반대 방향 제거
                if (lastDirection == EDirectionType.Left || lastDirection == EDirectionType.Right)
                {
                    holdDirections.Remove(lastDirection);
                }

                // 랜덤으로 Left 또는 Right 선택
                randomDir = holdDirections[UnityEngine.Random.Range(0, holdDirections.Count)];
                
                // 현재 홀드 정보 저장
                currentHoldDirection = randomDir;
                
                lastDirection = randomDir;
            }
            // ✨ HoldTap 노트 처리 (타입으로 확인)
            else if (noteData.noteType == ENoteType.HoldTap)
            {
                // HoldTap 노트는 현재 홀드의 반대 방향으로 설정
                if (currentHoldDirection != EDirectionType.None)
                {
                    randomDir = GetOppositeDirection(currentHoldDirection);
                }
                else
                {
                    // 홀드 방향이 없으면 일반 처리 (안전장치)
                    randomDir = EDirectionType.Right;
                }
                lastDirection = randomDir;
            }
            else
            {
                // ✨ 홀드가 아닌 다른 노트가 나오면 홀드 상태 초기화
                if (noteData.noteType != ENoteType.HoldTap)
                {
                    currentHoldDirection = EDirectionType.None;
                }

                // 일반 노트 처리 (기존 로직)
                var possibleDirections = new List<EDirectionType>(allDirections);
                if (i > 0)
                {
                    EDirectionType oppositeDirection = GetOppositeDirection(lastDirection);
                    if (oppositeDirection != EDirectionType.None)
                    {
                        possibleDirections.Remove(oppositeDirection);
                    }
                }

                if (possibleDirections.Count == 0)
                {
                    possibleDirections.AddRange(allDirections);
                }

                int randomIndex = UnityEngine.Random.Range(0, possibleDirections.Count);
                randomDir = possibleDirections[randomIndex];
                lastDirection = randomDir;

                if (!useDiagonal)
                {
                    switch (randomDir)
                    {
                        case EDirectionType.UpLeft:
                            randomDir = EDirectionType.Left;
                            break;
                        case EDirectionType.UpRight:
                            randomDir = EDirectionType.Right;
                            break;
                    }
                }
            }

            Note note = new Note
            (
                noteData.noteType,
                randomDir,
                noteData.targetTime,
                noteData.holdDurationTime
            );

            notes.Enqueue(note);

            // DoubleTap 노트 처리 - 같은 방향으로 0.05초 뒤에 노트 하나 더 추가
            if (noteData.noteType == ENoteType.DoubleTap)
            {
                Note secondNote = new Note
                (
                    noteData.noteType,
                    randomDir, // 같은 방향 사용
                    noteData.targetTime + 0.05f,
                    noteData.holdDurationTime
                );

                notes.Enqueue(secondNote);
            }
        }

        Debug.Log($"{songName} 차트 로딩 완료! 총 {sortedNotes.Count}개의 노트.");
        return notes;
    }
    private EDirectionType GetOppositeDirection(EDirectionType dir)
    {
        switch (dir)
        {
            case EDirectionType.Left:
                return EDirectionType.Right;
            case EDirectionType.Right:
                return EDirectionType.Left;
            default:
                return EDirectionType.None;
        }
    }
}
