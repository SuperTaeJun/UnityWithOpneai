using System;
using UnityEngine;

/// <summary>
/// 콤보 관리를 담당하는 시스템
/// </summary>
public class ComboSystem
{
    private int _comboCount = 0;

    public event Action<int> OnComboChanged;
    public event Action OnComboBreak;

    public int ComboCount => _comboCount;

    public void IncreaseCombo()
    {
        _comboCount++;
        OnComboChanged?.Invoke(_comboCount);
    }
    public void ResetCombo()
    {
        if (_comboCount > 0)
        {
            _comboCount = 0;
            OnComboBreak?.Invoke();
            OnComboChanged?.Invoke(_comboCount);
        }
    }
    public int GetCurrentCombo()
    {
        return _comboCount;
    }
}
