using System;
using UnityEngine;
public enum EJudgement
{
    Perfect,
    Good,
    Bad,
    Miss
}
/// 노트 판정을 담당하는 시스템
public class JudgementSystem
{
    private readonly float _perfectWindow;
    private readonly float _goodWindow;
    private readonly float _badWindow;

    public event Action<EJudgement> OnJudgement;

    public JudgementSystem(float perfectWindow, float goodWindow, float badWindow)
    {
        _perfectWindow = perfectWindow;
        _goodWindow = goodWindow;
        _badWindow = badWindow;
    }

    /// 시간 차이를 기반으로 판정을 계산합니다
    public EJudgement CalculateJudgement(float timeDifference)
    {
        timeDifference = Mathf.Abs(timeDifference);

        if (timeDifference <= _perfectWindow)
            return EJudgement.Perfect;
        else if (timeDifference <= _goodWindow)
            return EJudgement.Good;
        else if (timeDifference <= _badWindow)
            return EJudgement.Bad;
        else
            return EJudgement.Miss;
    }

    /// 입력이 판정 윈도우 내에 있는지 확인합니다
    public bool IsWithinJudgementWindow(float timeDifference)
    {
        return Mathf.Abs(timeDifference) <= _badWindow;
    }

    /// 판정 이벤트를 발생시킵니다
    public void TriggerJudgement(EJudgement judgement)
    {
        OnJudgement?.Invoke(judgement);
    }

    /// 홀드 노트 시작 판정 (일반 판정과 동일)
    public EJudgement CalculateHoldStartJudgement(float timeDifference)
    {
        return CalculateJudgement(timeDifference);
    }

    /// 홀드 노트 종료 판정 (일반 판정과 동일)
    public EJudgement CalculateHoldEndJudgement(float timeDifference)
    {
        return CalculateJudgement(timeDifference);
    }

    /// 홀드 노트 전체 판정 (시작과 종료 판정을 합산)
    /// 시작 판정과 종료 판정 중 더 낮은 등급을 반환
    public EJudgement CalculateHoldOverallJudgement(EJudgement startJudgement, EJudgement endJudgement)
    {
        // Miss가 하나라도 있으면 Miss
        if (startJudgement == EJudgement.Miss || endJudgement == EJudgement.Miss)
            return EJudgement.Miss;

        // Bad가 하나라도 있으면 Bad
        if (startJudgement == EJudgement.Bad || endJudgement == EJudgement.Bad)
            return EJudgement.Bad;

        // Good이 하나라도 있으면 Good
        if (startJudgement == EJudgement.Good || endJudgement == EJudgement.Good)
            return EJudgement.Good;

        // 둘 다 Perfect면 Perfect
        return EJudgement.Perfect;
    }

    public float PerfectWindow => _perfectWindow;
    public float GoodWindow => _goodWindow;
    public float BadWindow => _badWindow;
}
