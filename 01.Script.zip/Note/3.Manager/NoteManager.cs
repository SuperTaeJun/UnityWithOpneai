using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Unity.VisualScripting;
using UnityEngine;
using Cysharp.Threading.Tasks;


public class NoteManager : MonoBehaviour
{
    public static NoteManager Instance;

    [Header("음악")]
    [SerializeField] private bool _useDiagonal = false;
    [Header("리듬")]
    [SerializeField] private string _chartPath = ""; // MusicManager가 없을 때 사용할 차트 경로

    [Tooltip("음수면 타일이 더 느리게 양수면 타일이 더 빠르게 도착함 - 실제 노트의 타이밍보다")]
    [field: SerializeField] public float visualOffset { get; private set; }


    [Header("타이밍 윈도우")]
    [SerializeField] private float _perfectWindow = 0.1f;
    [SerializeField] private float _goodWindow = 0.2f;
    [SerializeField] private float _badWindow = 0.3f;

    [Header("나오는 타이밍 몇 초전")]
    [SerializeField] private float _tileSpawnLeadTime = 1.5f;
    public double SongPosition { get; private set; }

    private Queue<Note> _notes = new Queue<Note>();
    private Queue<Note> _activeNotes = new Queue<Note>();

    private JudgementSystem _judgementSystem;
    private ComboSystem _comboSystem;

    private NoteRepository _repository;


    // UniTask 최적화
    private CancellationTokenSource _cancellationTokenSource;

    // 외부 이벤트
    public event Action<int> OnHit;
    public event Action OnMiss;
    public event Action<Note> OnTileSpawn;
    public event Action<EJudgement> OnJudgement;
    public event Action<Note> OnPlayerPassedTile; // 플레이어가 타일을 지나갔을 때
    public event Action<Note> OnPlayerLandTile; // 플레이어가 타일에 착지했을 때

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);

        _repository = new NoteRepository();

        // 시스템 초기화
        _judgementSystem = new JudgementSystem(_perfectWindow, _goodWindow, _badWindow);
        _comboSystem = new ComboSystem();
        // 이벤트 연결
        _judgementSystem.OnJudgement += (judgement) => OnJudgement?.Invoke(judgement);
        _comboSystem.OnComboChanged += (combo) => OnHit?.Invoke(combo);
    }

    private void Start()
    {
        LoadSelectedMusic();

        // UniTask 기반 노트 처리 시작
        _cancellationTokenSource = new CancellationTokenSource();
        ProcessNotesAsync(_cancellationTokenSource.Token).Forget();
    }

    private void OnDestroy()
    {
        // UniTask 정리
        _cancellationTokenSource?.Cancel();
        _cancellationTokenSource?.Dispose();
    }

    /// MusicManager에서 선택된 곡 로드 (없으면 _chartPath 사용)
    private void LoadSelectedMusic()
    {
        // MusicManager가 있으면 선택된 곡 사용
        if (MusicManager.Instance != null && MusicManager.Instance.SelectedMusic != null)
        {
            Music selectedMusic = MusicManager.Instance.SelectedMusic;
            string chartPath = MusicManager.Instance.GetSelectedChartPath();

            if (string.IsNullOrEmpty(chartPath))
            {
                Debug.LogError($"선택된 난이도({MusicManager.Instance.SelectedDifficulty})의 차트가 없습니다!");
                return;
            }

            // 차트 로드
            _notes = _repository.LoadChartAndSetupGame(chartPath, _useDiagonal);

            // 선택된 곡의 AudioClip 경로로 BGM 재생 (2초 후)
            if (!string.IsNullOrEmpty(selectedMusic.AudioClipPath))
            {
                SoundManager.Instance.PlayBGM(selectedMusic.AudioClipPath, 2.0);
            }
            else
            {
                Debug.LogWarning("선택된 곡의 AudioClip 경로가 비어있습니다!");
            }

            Debug.Log($"곡 로드 완료: {selectedMusic.SongName} - {MusicManager.Instance.SelectedDifficulty}");
        }
        // MusicManager가 없으면 Inspector에 설정된 _chartPath 사용
        else
        {
            if (string.IsNullOrEmpty(_chartPath))
            {
                Debug.LogError("MusicManager가 없고 _chartPath도 설정되지 않았습니다!");
                return;
            }

            Debug.LogWarning("MusicManager를 찾을 수 없습니다. Inspector에 설정된 차트 경로를 사용합니다.");

            // 차트 로드
            _notes = _repository.LoadChartAndSetupGame(_chartPath, _useDiagonal);

            // BGM 재생 (기본 방식)
            SoundManager.Instance.PlayBGM(2.0);

            Debug.Log($"차트 로드 완료: {_chartPath}");
        }
    }

    private void Update()
    {
        UpdateSongPosition();
        CheckNoteLandTiming();
    }

    /// 액티브 노트들의 타겟 타임을 체크하여 착지 이벤트 발생
    private void CheckNoteLandTiming()
    {
        if (_activeNotes.Count == 0) return;

        Note[] notesArray = _activeNotes.ToArray();
        foreach (Note note in notesArray)
        {
            // 타겟 타임이 되었고, 아직 착지 이벤트가 발생하지 않았으면
            if (!note.IsJudged && !note.IsLandEventTriggered && SongPosition >= note.TargetTime)
            {
                note.TriggerLandEvent();
                OnPlayerLandTile?.Invoke(note);
            }
        }
    }

    /// <summary>
    /// UniTask 기반 노트 처리 메인 루프
    /// </summary>
    private async UniTaskVoid ProcessNotesAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && _notes.Count > 0)
        {
            try
            {
                // 다음 노트 스폰 처리
                await ProcessTileSpawningAsync(ct);

                // 타임아웃 처리 (매 프레임)
                ProcessNoteTimeout();

                // 다음 프레임까지 대기
                await UniTask.Yield(ct);
            }
            catch (OperationCanceledException)
            {
                // 정상적인 취소
                break;
            }
        }
    }

    /// <summary>
    /// UniTask 기반 타일 스폰 처리 - 정확한 타이밍에 노트 생성
    /// </summary>
    private UniTask ProcessTileSpawningAsync(CancellationToken ct)
    {
        // 한 번에 하나의 노트만 처리 (무한 루프 방지)
        if (_notes.Count == 0 || ct.IsCancellationRequested)
            return UniTask.CompletedTask;

        if (!_notes.TryPeek(out Note nextNote))
            return UniTask.CompletedTask;

        // 멀티탭 노트는 즉시 생성
        if (nextNote.NoteType == ENoteType.MultiTapNote)
        {
            _activeNotes.Enqueue(nextNote);
            OnTileSpawn?.Invoke(nextNote);
            nextNote.Activate();
            _notes.Dequeue();
            return UniTask.CompletedTask;
        }

        // 이미 활성화된 노트는 스킵
        if (nextNote.IsActivated)
            return UniTask.CompletedTask;

        // 스폰 시간이 되었는지 확인
        if (SongPosition >= nextNote.TargetTime - _tileSpawnLeadTime)
        {
            _activeNotes.Enqueue(nextNote);
            OnTileSpawn?.Invoke(nextNote);
            nextNote.Activate();
            _notes.Dequeue();
        }

        return UniTask.CompletedTask;
    }

    private void UpdateSongPosition()
    {
        if (SoundManager.Instance != null)
        {
            // SoundManager에서 BGM 재생 시간을 가져옴
            double bgmTime = SoundManager.Instance.GetCurrentBGMTime();
            // BGM이 아직 시작되지 않았으면 0으로 설정
            SongPosition = (float)Mathf.Max(0, (float)bgmTime);
        }
    }

    private void ProcessNoteTimeout()
    {
        if (_activeNotes.TryPeek(out Note oldestNote))
        {
            // 멀티탭 노트는 별도로 처리되므로 타임아웃 체크 제외
            if (oldestNote.NoteType == ENoteType.MultiTapNote)
            {
                return;
            }

            if (SongPosition > oldestNote.TargetTime + _judgementSystem.BadWindow)
            {
                ProcessMiss(oldestNote, _activeNotes);
            }
        }
    }
    /// 노트 Miss 처리
    private void ProcessMiss(Note note, Queue<Note> queue)
    {
        _comboSystem.ResetCombo();
        OnMiss?.Invoke();
        _judgementSystem.TriggerJudgement(EJudgement.Miss);
        note.Judge();

        queue.Dequeue();
    }

    /// 일반 노트 판정을 처리
    public bool CheckTapNote(EDirectionType direction, out EJudgement judgement)
    {
        if (_activeNotes.Count == 0)
        {
            judgement = EJudgement.Miss;
            return false;
        }
        Note noteToJudge = _activeNotes.Peek();

        double timeDifference = SongPosition - noteToJudge.TargetTime;

        // 판정 윈도우를 벗어난 입력은 무시
        if (!_judgementSystem.IsWithinJudgementWindow((float)timeDifference))
        {
            judgement = EJudgement.Miss;
            return false;
        }

        // 방향이 틀렸을 경우 Miss 처리
        if (noteToJudge.TargetDir != direction)
        {
            ProcessMiss(noteToJudge, _activeNotes);
            judgement = EJudgement.Miss;
            return false;
        }

        // 정확한 입력 처리
        judgement = _judgementSystem.CalculateJudgement((float)timeDifference);

        _comboSystem.IncreaseCombo();
        _judgementSystem.TriggerJudgement(judgement);
        noteToJudge.Judge();
        _activeNotes.Dequeue();

        return true;
    }

    public bool CheckMultiTapNote()
    {
        if (_activeNotes.Count == 0) return false;

        Note noteToJudge = _activeNotes.Peek();
        if (noteToJudge.NoteType != ENoteType.MultiTapNote) return false;

        // 멀티탭 종료 시점이 지났는지 확인 (다음 노트의 타겟 타임 - 배드 윈도우)
        double multiTapEndTime = GetMultiTapEndTime();

        if (SongPosition >= multiTapEndTime)
        {
            // 종료 시점이 지나면 멀티탭 종료 (성공 처리)
            _comboSystem.IncreaseCombo();
            _judgementSystem.TriggerJudgement(EJudgement.Perfect);
            noteToJudge.Judge();
            _activeNotes.Dequeue();

            return true;
        }

        return false;
    }

    public bool TryGetCurrentNote(out Note note)
    {
        if (_activeNotes.TryPeek(out var comp))
        {
            note = comp;
            return true;
        }
        note = null;
        return false;
    }

    /// 첫 번째 노트를 가져옵니다 (아직 스폰되지 않은 노트 포함)
    public bool TryGetFirstNote(out Note note)
    {
        if (_notes.TryPeek(out var comp))
        {
            note = comp;
            return true;
        }
        note = null;
        return false;
    }

    /// 다음 노트를 가져옵니다 (현재 노트 다음)
    public bool TryGetNextNote(out Note nextNote)
    {
        nextNote = null;

        if (_activeNotes.Count < 2)
            return false;

        Note[] notesArray = _activeNotes.ToArray();
        nextNote = notesArray[1];
        return true;
    }

    /// 멀티탭 노트의 종료 시점을 계산합니다 (다음 노트의 타겟 타임 - 배드 윈도우 * 2)
    public double GetMultiTapEndTime()
    {
        if (!TryGetCurrentNote(out Note currentNote))
            return double.MaxValue;

        if (currentNote.NoteType != ENoteType.MultiTapNote)
            return double.MaxValue;

        // 다음 노트가 있으면 다음 노트의 타겟 타임 - 배드 윈도우 * 2 (다음 노트 준비 시간 확보)
        if (TryGetNextNote(out Note nextNote))
        {
            return nextNote.TargetTime - (_judgementSystem.BadWindow * 2);
        }

        // 다음 노트가 없으면 현재 노트의 타겟 타임 + 배드 윈도우
        return currentNote.TargetTime + _judgementSystem.BadWindow;
    }

    /// 플레이어가 타일을 지나갔음을 알립니다
    public void NotifyPlayerPassedTile(Note note)
    {
        OnPlayerPassedTile?.Invoke(note);
    }
}
