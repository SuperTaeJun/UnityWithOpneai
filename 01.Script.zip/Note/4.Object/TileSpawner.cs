using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;


/// 타일 생성 및 관리를 담당하는 클래스
public class TileSpawner : MonoBehaviour
{
    [Header("타일 설정")]
    [SerializeField] private Vector2 _tileSize = Vector2.one;
    [SerializeField] private GameObject _tileSpawnVfxPrefab;

    [Header("타일 효과 설정")]
    [SerializeField] private Vector3 _punchScaleAmount = new Vector3(0.5f, 0.5f, 0);
    [SerializeField] private float _punchDuration = 0.5f;

    private Vector2 _lastTilePosition;
    private float _lastNoteTime = 0f;
    private Transform _player;
    private PlayerJudgeLine _playerJudgeLine;

    // Note와 TileNote 매핑을 관리
    private Dictionary<Note, TileNoteBase> _noteTileMap = new Dictionary<Note, TileNoteBase>();



    // Hold 노트의 위치를 저장 (HoldTap 이후 다른 노트가 나올 때 X 좌표 참조용)
    private Vector2 _lastHoldPosition;
    private Vector2 _lastHoldEndPosition;
    private bool _hasHoldPosition = false;

    // Hold 노트의 시간 정보 저장
    private float _lastHoldStartTime;
    private float _lastHoldEndTime;

    private void Awake()
    {
        _lastTilePosition = new Vector2(0, -3f);
    }

    private void Start()
    {
        _player = GameObject.FindGameObjectWithTag("Player").transform;
        _playerJudgeLine = FindObjectOfType<PlayerJudgeLine>();

        // NoteManager 이벤트 구독
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnTileSpawn += OnTileSpawn;
            NoteManager.Instance.OnPlayerPassedTile += OnPlayerPassedTile;
        }
    }

    /// 노트에 대한 타일을 생성합니다
    private void OnTileSpawn(Note note)
    {
        Vector2 nextPosition = CalculateTilePosition(note);

        TileNoteBase newTile = SpawnTileForNote(note, nextPosition);

        //홀드탭 타일은 이동하는게 아니라 이동할 위치가 필요없음
        if (note.NoteType != ENoteType.HoldTap)
            // Note 도메인에 위치 저장
            note.SetTilePosition(newTile.LandingPosition);

        if (newTile == null)
        {
            Debug.LogError($"타일을 생성할 수 없습니다: {note.NoteType}");
            return;
        }

        _lastTilePosition = nextPosition;
        _lastNoteTime = note.TargetTime;

        // Hold 노트의 위치와 시간 정보 저장
        if (note.NoteType == ENoteType.Hold)
        {
            _lastHoldPosition = nextPosition;
            _lastHoldEndPosition = note.HoldEndPosition;
            _lastHoldStartTime = note.TargetTime;
            _lastHoldEndTime = note.TargetTime + note.HoldDurationTime;
            _hasHoldPosition = true;
        }

        // HoldTap이 아닌 다른 노트가 나오면 Hold 위치 초기화
        if (note.NoteType != ENoteType.HoldTap && note.NoteType != ENoteType.Hold)
        {
            _hasHoldPosition = false;
        }

        // Note-TileNote 매핑 저장
        _noteTileMap[note] = newTile;

        // 타일 생성 효과
        newTile.transform.DOPunchScale(_punchScaleAmount, _punchDuration, 1, 0.5f);
    }

    /// 플레이어가 타일을 지나갔을 때 호출되는 이벤트 핸들러
    private void OnPlayerPassedTile(Note note)
    {
        if (_noteTileMap.TryGetValue(note, out TileNoteBase tile))
        {
            tile.DestroyTile();
            _noteTileMap.Remove(note);
        }
    }

    /// 특정 노트에 해당하는 타일을 가져옵니다
    public TileNoteBase GetTileForNote(Note note)
    {
        if (_noteTileMap.TryGetValue(note, out TileNoteBase tile))
        {
            return tile;
        }
        return null;
    }
    /// 타일의 위치를 계산합니다 (첫 번째 타일은 플레이어 앞, 나머지는 판정선 기준)
    private Vector2 CalculateTilePosition(Note note)
    {
        if (_player == null || _playerJudgeLine == null || NoteManager.Instance == null)
        {
            Debug.LogWarning("Player, PlayerJudgeLine 또는 NoteManager가 없습니다!");
            return _lastTilePosition;
        }

        Vector2 directionVector = GetDirectionVector(note.TargetDir);

        float tileY;
        
        // 첫 번째 타일인 경우: 플레이어 앞 고정 위치에 생성
        if (_lastNoteTime == 0f)
        {
            tileY = _player.position.y + 1f; // 플레이어 Y + 1 고정
            Debug.Log($"첫 번째 타일 생성: Y={tileY:F2} (플레이어 앞 고정)");
        }
        else
        {
            // 이후 타일들: 판정선 기준으로 계산
            float judgeLineY = _playerJudgeLine.CurrentY;
            float timeUntilTarget = note.TargetTime - (float)(NoteManager.Instance.SongPosition + NoteManager.Instance.visualOffset);
            float judgeLineDistance = _playerJudgeLine.YMoveSpeed * timeUntilTarget;
            tileY = judgeLineY + judgeLineDistance;
        }

        // X 위치 계산
        float tileX;
        if (_hasHoldPosition)
        {
            // Hold 노트 이후: Hold EndPosition 기준
            tileX = _lastHoldEndPosition.x + (directionVector.x * _tileSize.x);
        }
        else
        {
            // 일반: 이전 타일 기준
            tileX = _lastTilePosition.x + (directionVector.x * _tileSize.x);
        }

        Vector2 nextPosition = new Vector2(tileX, tileY);
        return nextPosition;
    }

    /// 노트 타입에 맞는 타일을 생성합니다
    private TileNoteBase SpawnTileForNote(Note note, Vector2 position)
    {
        TileNoteBase newTile = null;

        switch (note.NoteType)
        {
            case ENoteType.Tap:
            case ENoteType.LeftTap:
            case ENoteType.RightTap:
            case ENoteType.UpTap:

                newTile = ObjectPool.Instance.Get<TileNoteBase>(EPoolType.TapTile);
                break;
            case ENoteType.Mirro:
                newTile = ObjectPool.Instance.Get<TileNoteBase>(EPoolType.MirroTile);
                break;
            case ENoteType.MultiTapNote:
                newTile = ObjectPool.Instance.Get<TileNoteBase>(EPoolType.MultiTapTile);
                break;
            case ENoteType.Hold:
                newTile = ObjectPool.Instance.Get<TileNoteBase>(EPoolType.HoldTile);
                break;
            case ENoteType.HoldTap:
                newTile = ObjectPool.Instance.Get<TileNoteBase>(EPoolType.HoldTapTile);
                break;
            case ENoteType.GhostTap:
                newTile = ObjectPool.Instance.Get<TileNoteBase>(EPoolType.GhostTapTile);
                break;
            case ENoteType.DoubleTap:
                newTile = ObjectPool.Instance.Get<TileNoteBase>(EPoolType.DoubleTapTile);
                break;
        }

        if (newTile != null)
        {
            newTile.transform.position = position;
            newTile.transform.rotation = Quaternion.identity;

            // 이 값은 타일이 접근을 시작하는 시점을 결정합니다
            double approachDuration = NoteManager.Instance != null ?
                (note.TargetTime - NoteManager.Instance.SongPosition) : 1f;
            newTile.Initialize(note, approachDuration, _player);

            // HoldTileNote인 경우 EndPosition을 Note에 저장
            if (note.NoteType == ENoteType.Hold && newTile is HoldTileNote holdTile)
            {
                if (holdTile.EndPosition != null)
                {
                    note.SetHoldEndPosition(holdTile.EndPosition.position);
                }
            }
        }

        return newTile;
    }

    /// 방향에 따른 벡터를 반환합니다
    private Vector2 GetDirectionVector(EDirectionType direction)
    {
        switch (direction)
        {
            case EDirectionType.Up:
                return Vector2.up;
            case EDirectionType.Left:
                return new Vector2(-1, 1).normalized;
            case EDirectionType.Right:
                return new Vector2(1, 1).normalized;
            case EDirectionType.UpLeft:
                return new Vector2(-1, 1).normalized;
            case EDirectionType.UpRight:
                return new Vector2(1, 1).normalized;
            default:
                return Vector2.zero;
        }
    }

    private void OnDestroy()
    {
        // 이벤트 구독 해제
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnTileSpawn -= OnTileSpawn;
            NoteManager.Instance.OnPlayerPassedTile -= OnPlayerPassedTile;
        }
    }
}
