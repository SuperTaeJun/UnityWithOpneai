using UnityEngine;
using DG.Tweening;

public class HoldTileNote : TileNoteBase
{
    [Header("홀드 노트 설정")]
    [Tooltip("1초당 Y축 스케일 증가량")]
    [SerializeField] private float _scalePerSecond = 2.0f;
    [SerializeField] private Transform _endPosition;
    public Transform EndPosition => _endPosition;
    [SerializeField] private GameObject Mask;

    private Vector3 _originalScale;

    protected override void Awake()
    {
        base.Awake();
        _originalScale = transform.localScale;
    }

    public override void Initialize(Note noteData, double approachDuration, Transform player)
    {
        base.Initialize(noteData, approachDuration, player);

        // 홀드 시간에 따라 Y축 스케일 조정
        if (noteData.HoldDurationTime > 0)
        {
            float yScale = 1f + (noteData.HoldDurationTime * _scalePerSecond);
            Vector3 newScale = new Vector3(_originalScale.x, _originalScale.y * yScale, _originalScale.z);
            transform.localScale = newScale;
        }
    }

    protected override void OnEnable()
    {
        base.OnEnable();
        Mask.SetActive(false);
    }

    /// 기본 타일의 파괴 연출
    public override void DestroyTile()
    {
        if (_isDestroying) return;
        _isDestroying = true;
        ObjectPool.Instance.Return(gameObject);
    }

    protected override void SetupStartPosition()
    {
        base.SetupStartPosition();

        // 더 위에서 시작하도록 y 위치 조정 (빠른 낙하 효과)
        _startPosition = new Vector3(_startPosition.x, _startPosition.y + 5.0f, _startPosition.z);
        _approachingTile.position = _startPosition;
    }
}
