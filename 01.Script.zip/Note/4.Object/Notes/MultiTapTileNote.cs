using UnityEngine;
using DG.Tweening;

public class MultiTapTileNote : TileNoteBase
{
    public override void DestroyTile()
    {
        if (_isDestroying) return;
        _isDestroying = true;

        ObjectPool.Instance.Get(EPoolType.NoteHitVfx).transform.position = transform.position;

        // 간단한 축소 및 페이드아웃 연출
        Sequence seq = DOTween.Sequence();

        seq.Append(transform.DOScale(Vector3.zero, 0.5f).SetEase(Ease.InBack));
        seq.Join(GetComponent<SpriteRenderer>().DOFade(0f, 0.5f));
        seq.OnComplete(() =>
        {
            ObjectPool.Instance.Return(gameObject);
        });
    }

    private void OnHited()
    {
        var nextNote = NoteManager.Instance.TryGetNextNote(out Note note) ? note : null;

        

    }
}
