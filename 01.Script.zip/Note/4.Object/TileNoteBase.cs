using UnityEngine;
using DG.Tweening;

public abstract class TileNoteBase : MonoBehaviour
{
    [Header("타일 기본 설정")]
    [SerializeField] protected Transform _landingPosition;
    [SerializeField] protected Transform _approachingTile;
    [SerializeField] protected SpriteRenderer _renderer;
    [SerializeField] protected GameObject _light;

    [Header("타일 이동 설정")]
    [SerializeField] protected float flyInDistance = 5.0f;

    [Header("VFX 설정")]
    [SerializeField] protected GameObject _tilePerpectVfxPrefab;

    [Header("디버그")]
    [SerializeField] protected bool _useSoundTest;

    // 공통 프로퍼티
    public Vector2 LandingPosition => _landingPosition.position;
    public Note NoteData => _noteData;

    // 공통 필드
    protected Note _noteData;
    protected double _spawnTime;
    protected double _approachDuration;
    protected bool _isStartingApproach = false;
    protected Vector3 _startPosition;
    protected bool _useFlyIn = false;
    protected bool _isDestroying = false;
    protected Vector3 _originScale;
    protected bool _debugsoundComplete;

    protected virtual void Awake()
    {
        _originScale = transform.localScale;
    }

    protected virtual void OnEnable()
    {
        // DOTween 정리
        transform.DOKill(this);
        _renderer.DOKill(this);

        // 상태 초기화
        _isDestroying = false;
        _isStartingApproach = false;

        // 트랜스폼 리셋
        transform.position = Vector3.one;
        transform.rotation = Quaternion.identity;
        transform.localScale = _originScale;

        // 비주얼 요소 리셋
        if (_light)
            _light.SetActive(false);
            
        // 데이터 리셋
        _noteData = null;
        _approachDuration = 0f;
        _spawnTime = 0f;

        // 렌더러 알파 리셋
        Color color = _renderer.color;
        color.a = 1f;
        _renderer.color = color;

        _debugsoundComplete = false;

        NoteManager.Instance.OnPlayerLandTile += OnPlayerLandTile;
    }
    protected virtual void OnDisable()
    {
        NoteManager.Instance.OnPlayerLandTile -= OnPlayerLandTile;
    }


    protected virtual void OnPlayerLandTile(Note note)
    {
        if (note != _noteData) return;

        OnApproachComplete();
    }


    public virtual void Initialize(Note noteData, double approachDuration, Transform player)
    {
        _noteData = noteData;
        _approachDuration = approachDuration;
        _spawnTime = _noteData.TargetTime - _approachDuration;
    }

    /// 타일의 시작 위치를 설정합니다. 오버라이드하여 커스터마이징 가능
    protected virtual void SetupStartPosition()
    {
        _useFlyIn = false;
        Vector3 targetPos = transform.position;

        if (_noteData.NoteType == ENoteType.HoldTap)
        {
            if (_noteData.TargetDir == EDirectionType.Left)
            {
                _startPosition = new Vector3(targetPos.x - flyInDistance, targetPos.y, targetPos.z);
                _approachingTile.position = _startPosition;
                _approachingTile.localScale = Vector3.one;
                _useFlyIn = true;
            }
            else if (_noteData.TargetDir == EDirectionType.Right)
            {
                _startPosition = new Vector3(targetPos.x + flyInDistance, targetPos.y, targetPos.z);
                _approachingTile.position = _startPosition;
                _approachingTile.localScale = Vector3.one;
                _useFlyIn = true;
            }
            else
            {
                float randomDirection = Random.Range(0, 2) == 0 ? -1f : 1f;
                _startPosition = new Vector3(targetPos.x + (flyInDistance * randomDirection), targetPos.y, targetPos.z);
                _approachingTile.position = _startPosition;
                _approachingTile.localScale = Vector3.one;
                _useFlyIn = true;
            }
        }
        else
        {
            if (_noteData.TargetDir == EDirectionType.Left)
            {
                _startPosition = new Vector3(targetPos.x, targetPos.y + flyInDistance, targetPos.z);
                _approachingTile.position = _startPosition;
                _approachingTile.localScale = Vector3.one;
                _useFlyIn = true;
            }
            else if (_noteData.TargetDir == EDirectionType.Right)
            {
                _startPosition = new Vector3(targetPos.x, targetPos.y + flyInDistance, targetPos.z);
                _approachingTile.position = _startPosition;
                _approachingTile.localScale = Vector3.one;
                _useFlyIn = true;
            }
            else
            {
                float randomDirection = Random.Range(0, 2) == 0 ? -1f : 1f;
                _startPosition = new Vector3(targetPos.x, targetPos.y + flyInDistance, targetPos.z);
                _approachingTile.position = _startPosition;
                _approachingTile.localScale = Vector3.one;
                _useFlyIn = true;
            }
        }


    }

    /// 접근 애니메이션이 완료되었을 때 호출됩니다. 오버라이드하여 커스터마이징 가능
    protected virtual void OnApproachComplete()
    {
        ObjectPool.Instance.Get(EPoolType.NoteApprochVfx).transform.position = transform.position;
    }


    public virtual void StartApproach()
    {
        _isStartingApproach = true;
    }

    // 타일을 파괴합니다 ** 반드시구현
    public abstract void DestroyTile();


}
