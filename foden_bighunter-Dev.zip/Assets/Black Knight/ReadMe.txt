Thank you for your purchase！
For any question, please feel free to contact us: mic-art@outlook.com

The AnimationEvent Scripts are used to implement event notifications: 1.AttackStartEffectObject (Shooting objects, such as fireballs).
2.AttackStart (When the attack hits the opponent).
The animation event has been added to the animation according to the specific action, you can modify or delete it in the animation window.