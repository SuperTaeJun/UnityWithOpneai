using System.Collections;
using UnityEngine;
using DG.Tweening;
using TMPro;

public enum EDamgeType
{
    Normal,     // 일반: 팍 뜨고 흐려지며 사라짐
    Accumulate  // 누적: 합산되다가 반갈죽 
}

public class UI_Damage : MonoBehaviour
{
    [Header("텍스트 참조")]
    [SerializeField] private TextMeshProUGUI _mainText;      // 메인 데미지 텍스트
    [SerializeField] private GameObject _sliceContainer;     // 자르기 연출 부모 오브젝트
    [SerializeField] private RectTransform _topTextContainer;
    [SerializeField] private RectTransform _bottomTextContainer;
    [SerializeField] private TextMeshProUGUI _topText;       // 위쪽 절반 텍스트
    [SerializeField] private TextMeshProUGUI _bottomText;    // 아래쪽 절반 텍스트

    [Header("설정")]
    [SerializeField] private float _comboTime = 1f;        // 이 시간 안에 때리면 콤보 유지
    [SerializeField] private float _maxScale = 3.0f;         // 텍스트가 커지는 최대 배율
    [SerializeField] private float _scalePerHit = 0.15f;     // 히트당 증가하는 스케일
    [SerializeField] private float _numberCountDuration = 0.6f;  // 숫자 카운팅 애니메이션 시간

    private int _currentDamageSum = 0;
    private int _displayedDamage = 0;  // 현재 화면에 표시된 데미지
    private int _hitCount = 0;  // 히트 횟수 추적
    private float _lastHitTime;
    private bool _isSlicing = false;
    private Vector3 _originScale;
    private RectTransform _rectTransform;
    private Tweener _numberCountTween;  // 숫자 카운팅 트윈 참조

    private EDamgeType _damageType;

    // 외부에서 위치 비교를 위해 사용
    public Vector3 WorldPosition { get; private set; }
    public bool IsActive => gameObject.activeSelf && !_isSlicing; // 슬라이싱 중이 아닐 때만 재사용 가능

    private void Awake()
    {
        _rectTransform = GetComponent<RectTransform>();
        _originScale = transform.localScale;
        // 안전장치: 시작할 때 슬라이스 관련은 꺼둠
        if (_sliceContainer) _sliceContainer.SetActive(false);
    }

    private void Update()
    {
        // 누적 타입일 때만 콤보 시간 체크해서 자르기 연출 (히트 카운트 2 이상일 때만)
        if (_damageType == EDamgeType.Accumulate && !_isSlicing && Time.time > _lastHitTime + _comboTime)
        {
            StartSliceEffect();
        }
    }

    // 초기화 및 첫 데미지 (Manager에서 호출)
    public void Initialize(Vector3 worldPos, int damage, EDamgeType type)
    {
        _damageType = type;
        WorldPosition = worldPos;
        _currentDamageSum = 0;
        _displayedDamage = 0;
        _hitCount = 0;  // 히트 카운트 초기화
        _isSlicing = false;
        _sliceContainer.SetActive(false);
        _mainText.gameObject.SetActive(true);
        _mainText.alpha = 1f; // 투명도 초기화

        transform.localScale = _originScale; // 스케일 초기화

        // 숫자 카운팅 트윈 중지
        _numberCountTween?.Kill();

        if (_damageType == EDamgeType.Normal)
        {
            // 일반 데미지는 텍스트 갱신하고 바로 FadeOut 코루틴 실행
            _mainText.text = damage.ToString();
            //기울임 제거
            _mainText.fontStyle &= ~FontStyles.Italic;
            PlayPopAnimation(); // 튀어오르는 애니메이션
        }
        else
        {
            // 누적 데미지는 AddDamage 로직을 탈 것이므로 대기
            AddDamage(damage, worldPos);
        }
    }

    private void PlayPopAnimation()
    {
        // 위로 떠오르면서 페이드 아웃
        Sequence seq = DOTween.Sequence();

        // 위로 50 유닛 이동 (0.8초 동안)
        seq.Join(_rectTransform.DOAnchorPosY(_rectTransform.anchoredPosition.y + 50f, 0.8f));

        // 동시에 페이드 아웃 (0.8초 동안)
        seq.Join(_mainText.DOFade(0f, 0.8f));

        // 애니메이션 완료 후 풀로 반환
        seq.OnComplete(ReturnToPool);
    }

    // 데미지 누적 (Manager에서 호출)
    public void AddDamage(int damage, Vector3 newWorldPosition)
    {
        //기울임 추가
        _mainText.fontStyle |= FontStyles.Italic;
        _lastHitTime = Time.time; // 타이머 리셋
        int previousDamage = _currentDamageSum;
        _currentDamageSum += damage;
        _hitCount++; // 히트 횟수 증가

        // 위치 업데이트
        UpdatePosition(newWorldPosition);

        // 숫자 카운팅 애니메이션 (이전 트윈 중지)
        _numberCountTween?.Kill();
        _numberCountTween = DOTween.To(
            () => _displayedDamage,
            x =>
            {
                _displayedDamage = x;
                _mainText.text = _displayedDamage.ToString();
            },
            _currentDamageSum,
            _numberCountDuration
        ).SetEase(Ease.OutQuad);

        // 히트 횟수에 따라 점점 커지는 연출 (최대치 제한)
        float scaleIncrease = _hitCount * _scalePerHit;
        float currentScale = Mathf.Min(1f + scaleIncrease, _maxScale);
        Vector3 targetScale = _originScale * currentScale;

        // 쾅! 튕기는 효과 (기존 스케일 트윈 제거 후 실행)
        transform.DOKill();

        // 부드럽게 크기 증가
        transform.DOScale(targetScale, 0.1f).SetEase(Ease.OutBack);

        // 펀치 효과 추가
        transform.DOPunchScale(Vector3.one * 0.3f, 0.2f, 10, 1).SetDelay(0.2f);
    }

    // 위치 업데이트
    private void UpdatePosition(Vector3 newWorldPosition)
    {
        WorldPosition = newWorldPosition;

        // 월드 포지션을 스크린 포지션으로 변환
        Vector3 screenPos = Camera.main.WorldToScreenPoint(newWorldPosition);

        // Y 오프셋 적용 (Manager와 동일한 방식)
        screenPos.y += -0.8f * 100f;

        // UI 포지션 설정
        transform.position = screenPos;
    }

    // 텍스트 반으로 가르기 연출
    private void StartSliceEffect()
    {
        _isSlicing = true;

        // 메인 텍스트 숨기기
        _mainText.gameObject.SetActive(false);

        // 슬라이스 파트 활성화 및 값 동기화
        _sliceContainer.SetActive(true);
        _topText.text = _currentDamageSum.ToString();
        _bottomText.text = _currentDamageSum.ToString();

        // 색상/알파값 초기화
        _topText.alpha = 1f;
        _bottomText.alpha = 1f;

        // 위치 초기화 (컨테이너 기준)
        _topTextContainer.anchoredPosition = Vector2.zero;
        _bottomTextContainer.anchoredPosition = Vector2.zero;

        // 3. DOTween 연출 (위아래로 벌어지며 사라짐)
        Sequence seq = DOTween.Sequence();

        // 위쪽 파트: 오른쪽 위로 이동 + 텍스트 투명화
        seq.Join(_topTextContainer.DOAnchorPos(new Vector2(20f, 50f), 0.5f));
        seq.Join(_topText.DOFade(0, 0.5f));

        // 아래쪽 파트: 왼쪽 아래로 이동 + 텍스트 투명화
        seq.Join(_bottomTextContainer.DOAnchorPos(new Vector2(-20f, -50f), 0.5f));
        seq.Join(_bottomText.DOFade(0, 0.5f));

        seq.OnComplete(ReturnToPool);
    }

    private void ReturnToPool()
    {
        // DOTween 중지
        transform.DOKill();
        _numberCountTween?.Kill();

        // 상태 초기화
        transform.localScale = _originScale;
        _currentDamageSum = 0;
        _displayedDamage = 0;
        _hitCount = 0;
        _isSlicing = false;

        // 풀로 반환
        UI_DamageManager.Instance.ReturnToPool(this);
    }
}
