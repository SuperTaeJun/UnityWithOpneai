using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_DamageManager : Singleton<UI_DamageManager>
{
    [Header("프리팹 설정")]
    [SerializeField] private GameObject _damageTextPrefab;

    [Header("스폰 위치 설정")]
    [SerializeField] private float _spawnOffsetY = -0.8f;

    [Header("풀링 설정")]
    [SerializeField] private int _initialPoolSize = 20;

    private Queue<UI_Damage> _damageTextPool = new Queue<UI_Damage>();
    private Dictionary<GameObject, UI_Damage> _activeDamageByTarget = new Dictionary<GameObject, UI_Damage>();

    private void Start()
    {
        InitializePool();
    }

    // 데미지 텍스트 풀 초기화
    private void InitializePool()
    {
        for (int i = 0; i < _initialPoolSize; i++)
        {
            CreateNewDamageText();
        }
    }

    // 새로운 데미지 텍스트 생성 및 풀에 추가
    private UI_Damage CreateNewDamageText()
    {
        GameObject damageTextObj = Instantiate(_damageTextPrefab, transform);
        UI_Damage damageText = damageTextObj.GetComponent<UI_Damage>();
        damageTextObj.SetActive(false);
        _damageTextPool.Enqueue(damageText);
        return damageText;
    }

    // 풀에서 데미지 텍스트 가져오기
    private UI_Damage GetDamageTextFromPool()
    {
        if (_damageTextPool.Count == 0)
        {
            return CreateNewDamageText();
        }

        UI_Damage damageText = _damageTextPool.Dequeue();
        damageText.gameObject.SetActive(true);
        return damageText;
    }

    // 데미지 텍스트를 풀로 반환
    public void ReturnToPool(UI_Damage damageText)
    {
        if (damageText == null) return;

        // Dictionary에서 제거
        RemoveActiveTarget(damageText);

        damageText.gameObject.SetActive(false);
        damageText.transform.SetParent(transform);
        _damageTextPool.Enqueue(damageText);
    }

    // 활성 타겟에서 제거
    private void RemoveActiveTarget(UI_Damage damageText)
    {
        GameObject targetToRemove = null;
        foreach (var kvp in _activeDamageByTarget)
        {
            if (kvp.Value == damageText)
            {
                targetToRemove = kvp.Key;
                break;
            }
        }

        if (targetToRemove != null)
        {
            _activeDamageByTarget.Remove(targetToRemove);
        }
    }


    // 데미지 텍스트 생성
    public void SpawnDamageText(GameObject target, Vector3 worldPosition, int damage, EDamgeType damageType)
    {
        // Accumulate 타입이고 해당 타겟에 활성 데미지가 있으면 누적
        if (damageType == EDamgeType.Accumulate && target != null && _activeDamageByTarget.ContainsKey(target))
        {
            UI_Damage existingDamage = _activeDamageByTarget[target];
            if (existingDamage != null && existingDamage.IsActive)
            {
                existingDamage.AddDamage(damage, target.transform.position);
                return;
            }
            else
            {
                // 유효하지 않은 데미지 텍스트면 제거
                _activeDamageByTarget.Remove(target);
            }
        }

        // 새로운 데미지 텍스트 생성
        UI_Damage damageText = GetDamageTextFromPool();

        // Accumulate 타입이 아닐 때만 여기서 위치 설정
        // (Accumulate는 Initialize -> AddDamage -> UpdatePosition에서 위치 설정)
        if (damageType != EDamgeType.Accumulate)
        {
            // 월드 포지션을 스크린 포지션으로 변환
            Vector3 screenPos = Camera.main.WorldToScreenPoint(worldPosition);

            // Y 오프셋 적용 (스크린 좌표계에서)
            screenPos.y += _spawnOffsetY * 100f; // 스크린 좌표는 픽셀 단위이므로 스케일 조정

            // UI 포지션 설정
            damageText.transform.position = screenPos;
        }

        // 데미지 텍스트 설정 및 애니메이션 시작
        damageText.Initialize(worldPosition, damage, damageType);

        // Accumulate 타입이면 Dictionary에 등록
        if (damageType == EDamgeType.Accumulate && target != null)
        {
            _activeDamageByTarget[target] = damageText;
        }
    }
}
