using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_Upgrade : UI_Popup
{
    [Header("Weapon Slot Configuration")]
    [SerializeField] private List<UI_ProjectileSlot> weaponSlots = new List<UI_ProjectileSlot>();

    [SerializeField] private Button _exitButton;
    [Header("UI")]
    [SerializeField] private Transform slotContainer;
    [SerializeField] private GameObject slotPrefab;

    protected override void Awake()
    {
        base.Awake();
        InitializeWeaponSlots();
        //gameObject.SetActive(false);
    }
    private void Start()
    {
        //처음에 자블린으로 자동 선택
        if (weaponSlots.Count > 0)
        {
            GameSessionData.Instance.SetGameData(weaponSlots[0].GetWeaponStat());
            Debug.Log(weaponSlots[0].GetWeaponStat().Damage);
        }
    }

    private void OnEnable()
    {
        // 버튼 이벤트 등록
        if (_exitButton != null)
        {
            _exitButton.onClick.RemoveAllListeners(); // 중복 방지
            _exitButton.onClick.AddListener(Close);
        }
    }

    private void OnDisable()
    {
        // 버튼 이벤트 제거
        if (_exitButton != null)
        {
            _exitButton.onClick.RemoveAllListeners();
        }
    }

    private void InitializeWeaponSlots()
    {
        weaponSlots.Clear();

        // Null 체크
        if (slotPrefab == null)
        {
            Debug.LogError("[UI_Upgrade] slotPrefab이 null입니다. Unity Inspector에서 UI_ProjectileSlot 프리팹을 할당해주세요.");
            return;
        }

        if (slotContainer == null)
        {
            Debug.LogError("[UI_Upgrade] slotContainer가 null입니다. Unity Inspector에서 슬롯 컨테이너 Transform을 할당해주세요.");
            return;
        }

        // 5개의 무기 타입에 대한 슬롯 생성
        EProjectileType[] weaponTypes = new EProjectileType[]
        {
            EProjectileType.Javelin,
            EProjectileType.Boomerang,
            EProjectileType.Laser,
            EProjectileType.SplitBall,
            EProjectileType.BounceBall
        };

        for (int i = 0; i < weaponTypes.Length; i++)
        {
            EProjectileType weaponType = weaponTypes[i];

            // PlayerWeaponStat 생성 (임의의 데이터)
            // 첫 번째 무기(Javelin)만 잠금 해제, 나머지는 잠금 상태
            bool isLocked = i > 4;
            int level = isLocked ? 1 : 1;
            int damage = GetInitialDamage(weaponType);
            float speed = GetInitialSpeed(weaponType);

            PlayerWeaponStat weaponStat = new PlayerWeaponStat(
                type: weaponType,
                lev: level,
                damage: damage,
                isLocked: isLocked
            );

            // UI_ProjectileSlot 생성 (프리팹으로 생성)
            GameObject slotObj = Instantiate(slotPrefab, slotContainer);
            UI_ProjectileSlot slot = slotObj.GetComponent<UI_ProjectileSlot>();

            if (slot == null)
            {
                Debug.LogError($"[UI_Upgrade] slotPrefab에 UI_ProjectileSlot 컴포넌트가 없습니다. 프리팹에 UI_ProjectileSlot 컴포넌트를 추가해주세요.");
                Destroy(slotObj);
                continue;
            }

            // 슬롯 초기화
            slot.Initialize(weaponStat, OnWeaponSlotClicked);
            weaponSlots.Add(slot);
        }
        Debug.Log($"무기 슬롯 초기화 완료: {weaponSlots.Count}개의 슬롯 생성");
    }

    private int GetInitialDamage(EProjectileType type)
    {
        // 무기 타입별 초기 데미지 설정
        return type switch
        {
            EProjectileType.Javelin => 10,
            EProjectileType.Boomerang => 8,
            EProjectileType.Laser => 15,
            EProjectileType.SplitBall => 6,
            EProjectileType.BounceBall => 12,
            _ => 10
        };
    }

    private float GetInitialSpeed(EProjectileType type)
    {
        // 무기 타입별 초기 속도 설정
        return type switch
        {
            EProjectileType.Javelin => 10.0f,
            EProjectileType.Boomerang => 8.0f,
            EProjectileType.Laser => 20.0f,
            EProjectileType.SplitBall => 12.0f,
            EProjectileType.BounceBall => 9.0f,
            _ => 10.0f
        };
    }

    private void OnWeaponSlotClicked(PlayerWeaponStat weaponStat)
    {
        Debug.Log($"무기 선택됨 - Type: {weaponStat.SelectedType}, Level: {weaponStat.Level}, Damage: {weaponStat.Damage}");

        GameSessionData.Instance.SetGameData(weaponStat);
        // 여기에 무기 업그레이드 또는 선택 로직 추가
        // 예: ShowUpgradePanel(weaponStat);
    }

    // 특정 무기 타입의 슬롯 가져오기
    public UI_ProjectileSlot GetWeaponSlot(EProjectileType type)
    {
        return weaponSlots.Find(slot => slot.GetWeaponType() == type);
    }

    // 특정 무기 스탯 가져오기
    public PlayerWeaponStat GetWeaponStat(EProjectileType type)
    {
        UI_ProjectileSlot slot = GetWeaponSlot(type);
        return slot != null ? slot.GetWeaponStat() : default;
    }

    // 모든 무기 스탯 가져오기
    public List<PlayerWeaponStat> GetAllWeaponStats()
    {
        List<PlayerWeaponStat> stats = new List<PlayerWeaponStat>();
        foreach (var slot in weaponSlots)
        {
            stats.Add(slot.GetWeaponStat());
        }
        return stats;
    }

    // 무기 잠금 해제
    public void UnlockWeapon(EProjectileType type)
    {
        UI_ProjectileSlot slot = GetWeaponSlot(type);
        if (slot != null)
        {
            PlayerWeaponStat currentStat = slot.GetWeaponStat();
            PlayerWeaponStat newStat = new PlayerWeaponStat(
                type: currentStat.SelectedType,
                lev: currentStat.Level,
                damage: currentStat.Damage,
                isLocked: false
            );
            slot.UpdateWeaponStat(newStat);
            Debug.Log($"무기 잠금 해제: {type}");
        }
    }

    // 무기 업그레이드
    public void UpgradeWeapon(EProjectileType type)
    {
        UI_ProjectileSlot slot = GetWeaponSlot(type);
        if (slot != null && !slot.IsLocked())
        {
            PlayerWeaponStat currentStat = slot.GetWeaponStat();

            // 레벨업 시 스탯 증가
            int newLevel = currentStat.Level + 1;
            int newDamage = currentStat.Damage + 5;


            PlayerWeaponStat newStat = new PlayerWeaponStat(
                type: currentStat.SelectedType,
                lev: newLevel,
                damage: newDamage,
                isLocked: false
            );

            slot.UpdateWeaponStat(newStat);
            Debug.Log($"무기 업그레이드: {type} -> Lv.{newLevel}");
        }
    }

    // 무기 정보 출력 (디버그용)
    public void PrintWeaponInfo()
    {
        Debug.Log("=== 무기 슬롯 정보 ===");
        foreach (var slot in weaponSlots)
        {
            PlayerWeaponStat stat = slot.GetWeaponStat();
            string lockStatus = stat.IsLocked ? "[잠김]" : "[해제]";
            Debug.Log($"{lockStatus} {stat.SelectedType}: Lv.{stat.Level}, DMG={stat.Damage}");
        }
    }
}
