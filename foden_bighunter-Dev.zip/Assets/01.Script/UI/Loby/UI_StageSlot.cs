using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UI_StageSlot : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private Button stageButton;
    [SerializeField] private TextMeshProUGUI levelText;
    private GameRunConfig stageConfig;
    private Action<GameRunConfig> onSlotClicked;

    public void Initialize(GameRunConfig config, Action<GameRunConfig> clickCallback)
    {
        stageConfig = config;
        onSlotClicked = clickCallback;

        // 버튼이 없으면 자동으로 추가
        if (stageButton == null)
        {
            stageButton = GetComponent<Button>();
            if (stageButton == null)
            {
                stageButton = gameObject.AddComponent<Button>();
            }
        }

        // 버튼 클릭 이벤트 등록
        stageButton.onClick.RemoveAllListeners();
        stageButton.onClick.AddListener(OnButtonClicked);

        UpdateUI();
    }

    private void UpdateUI()
    {
        // 레벨 텍스트 업데이트
        if (levelText != null)
        {
            levelText.text = $"Level {stageConfig.StageLev}";
        }
    }

    private void OnButtonClicked()
    {
        Debug.Log($"스테이지 슬롯 클릭 - Level: {stageConfig.StageLev}, StageID: {stageConfig.StageId}");
        onSlotClicked?.Invoke(stageConfig);
    }

    public void SetInteractable(bool interactable)
    {
        if (stageButton != null)
        {
            stageButton.interactable = interactable;
        }
    }

    public GameRunConfig GetConfig()
    {
        return stageConfig;
    }

    public int GetLevel()
    {
        return stageConfig.StageLev;
    }
}
