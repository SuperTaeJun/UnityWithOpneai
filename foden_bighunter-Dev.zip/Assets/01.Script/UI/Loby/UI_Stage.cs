using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UI_Stage : UI_Popup
{
    [Header("Stage Slot Configuration")]
    [SerializeField] private List<UI_StageSlot> _stageSlots = new List<UI_StageSlot>();
    [SerializeField] private Button _exitButton;

    [Header("UI")]
    [SerializeField] private Transform _slotContainer;
    [SerializeField] private GameObject _slotPrefab;

    protected override void Awake()
    {
        base.Awake();
        InitializeStageSlots();
    }

    private void OnEnable()
    {
        // 버튼 이벤트 등록
        if (_exitButton != null)
        {
            _exitButton.onClick.RemoveAllListeners(); // 중복 방지
            _exitButton.onClick.AddListener(Close);
        }
    }

    private void OnDisable()
    {
        // 버튼 이벤트 제거
        if (_exitButton != null)
        {
            _exitButton.onClick.RemoveAllListeners();
        }
    }

    private void InitializeStageSlots()
    {
        _stageSlots.Clear();

        // 10개의 스테이지 슬롯 생성 (레벨 1~10)
        for (int i = 1; i <= 10; i++)
        {
            // GameRunConfig 생성 (모든 슬롯은 같은 스테이지 ID "Stage_01" 사용)
            float hpMultiplier = 1.0f + (i - 1) * 0.3f;
            GameRunConfig config = new GameRunConfig(
                id: "Stage_01",
                stageLev: i,
                enemyHpMultiplier: hpMultiplier
            );

            // UI_StageSlot 생성 (프리팹으로 생성)
            GameObject slotObj = Instantiate(_slotPrefab, _slotContainer);
            UI_StageSlot slot = slotObj.GetComponent<UI_StageSlot>();

            // 슬롯 초기화
            slot.Initialize(config, OnStageSlotClicked);
            _stageSlots.Add(slot);
        }

        Debug.Log($"스테이지 슬롯 초기화 완료: {_stageSlots.Count}개의 슬롯 생성");
    }

    private void OnStageSlotClicked(GameRunConfig config)
    {
        Debug.Log($"스테이지 선택됨 - StageID: {config.StageId}, Level: {config.StageLev}, HP배율: {config.EnemyHpMultiplier:F1}x");

        GameSessionData.Instance.SetGameData(config);
        SceneManager.LoadSceneAsync(config.StageId);
        // 여기에 스테이지 시작 로직 추가
        // 예: GameManager.Instance.StartStage(config);
    }

    // 특정 레벨의 스테이지 설정 가져오기
    public GameRunConfig GetStageConfig(int level)
    {
        if (level < 1 || level > _stageSlots.Count)
        {
            Debug.LogWarning($"잘못된 레벨: {level}. 기본값(레벨 1) 반환");
            return _stageSlots[0].GetConfig();
        }

        return _stageSlots[level - 1].GetConfig();
    }

    // 모든 스테이지 설정 가져오기
    public List<GameRunConfig> GetAllStageConfigs()
    {
        List<GameRunConfig> configs = new List<GameRunConfig>();
        foreach (var slot in _stageSlots)
        {
            configs.Add(slot.GetConfig());
        }
        return configs;
    }

    // 특정 슬롯 활성화/비활성화
    public void SetSlotInteractable(int level, bool interactable)
    {
        if (level < 1 || level > _stageSlots.Count)
        {
            Debug.LogWarning($"잘못된 레벨: {level}");
            return;
        }

        _stageSlots[level - 1].SetInteractable(interactable);
    }

    // 특정 슬롯 가져오기
    public UI_StageSlot GetSlot(int level)
    {
        if (level < 1 || level > _stageSlots.Count)
        {
            Debug.LogWarning($"잘못된 레벨: {level}");
            return null;
        }

        return _stageSlots[level - 1];
    }

    // 스테이지 정보 출력 (디버그용)
    public void PrintStageInfo()
    {
        Debug.Log("=== 스테이지 슬롯 정보 ===");
        for (int i = 0; i < _stageSlots.Count; i++)
        {
            GameRunConfig config = _stageSlots[i].GetConfig();
            Debug.Log($"슬롯 {i + 1}: StageID={config.StageId}, Level={config.StageLev}, HP배율={config.EnemyHpMultiplier:F1}x");
        }
    }
}
