using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UI_ProjectileSlot : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private Button weaponButton;
    [SerializeField] private TextMeshProUGUI weaponNameText;
    [SerializeField] private TextMeshProUGUI levelText;
    [SerializeField] private TextMeshProUGUI damageText;
    [SerializeField] private TextMeshProUGUI speedText;
    [SerializeField] private GameObject lockedOverlay;

    private PlayerWeaponStat weaponStat;
    private Action<PlayerWeaponStat> onSlotClicked;

    public void Initialize(PlayerWeaponStat stat, Action<PlayerWeaponStat> clickCallback)
    {
        EProjectileType currentType = GameSessionData.Instance.PlayerWeaponStat.SelectedType;
        if(stat.SelectedType == currentType)
        {
            weaponButton.Select();
        }

        weaponStat = stat;
        onSlotClicked = clickCallback;

        // 버튼이 없으면 자동으로 추가
        if (weaponButton == null)
        {
            weaponButton = GetComponent<Button>();
            if (weaponButton == null)
            {
                weaponButton = gameObject.AddComponent<Button>();
            }
        }

        // 버튼 클릭 이벤트 등록
        weaponButton.onClick.RemoveAllListeners();
        weaponButton.onClick.AddListener(OnButtonClicked);

        UpdateUI();
    }

    private void UpdateUI()
    {
        // 무기 이름 텍스트 업데이트
        if (weaponNameText != null)
        {
            weaponNameText.text = GetWeaponName(weaponStat.SelectedType);
        }

        // 레벨 텍스트 업데이트
        if (levelText != null)
        {
            levelText.text = $"Lv.{weaponStat.Level}";
        }

        // 데미지 텍스트 업데이트
        if (damageText != null)
        {
            damageText.text = $"DMG: {weaponStat.Damage}";
        }
        // 잠금 상태 업데이트
        if (lockedOverlay != null)
        {
            lockedOverlay.SetActive(weaponStat.IsLocked);
        }

        // 잠긴 무기는 버튼 비활성화
        if (weaponButton != null)
        {
            weaponButton.interactable = !weaponStat.IsLocked;
        }
    }

    private string GetWeaponName(EProjectileType type)
    {
        // 한글 폰트가 없는 경우를 대비해 영문 이름 사용
        return type switch
        {
            EProjectileType.Javelin => "Javelin",
            EProjectileType.Boomerang => "Boomerang",
            EProjectileType.Laser => "Laser",
            EProjectileType.SplitBall => "Split Ball",
            EProjectileType.BounceBall => "Bounce Ball",
            _ => "Unknown"
        };
    }

    private void OnButtonClicked()
    {
        if (weaponStat.IsLocked)
        {
            Debug.Log($"잠긴 무기: {weaponStat.SelectedType}");
            return;
        }

        Debug.Log($"무기 슬롯 클릭 - Type: {weaponStat.SelectedType}, Level: {weaponStat.Level}");
        onSlotClicked?.Invoke(weaponStat);
    }

    public void SetInteractable(bool interactable)
    {
        if (weaponButton != null)
        {
            weaponButton.interactable = interactable && !weaponStat.IsLocked;
        }
    }

    public PlayerWeaponStat GetWeaponStat()
    {
        return weaponStat;
    }

    public EProjectileType GetWeaponType()
    {
        return weaponStat.SelectedType;
    }

    public bool IsLocked()
    {
        return weaponStat.IsLocked;
    }

    // 무기 스탯 업데이트 (업그레이드 시 사용)
    public void UpdateWeaponStat(PlayerWeaponStat newStat)
    {
        weaponStat = newStat;
        UpdateUI();
    }
}
