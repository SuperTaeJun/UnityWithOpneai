using UnityEngine;

public struct GameRunConfig
{
    readonly public string StageId;
    readonly public int StageLev;
    readonly public float EnemyHpMultiplier;

    public GameRunConfig(string id, int stageLev, float enemyHpMultiplier)
    {
        StageId = id;
        StageLev = stageLev;
        EnemyHpMultiplier = enemyHpMultiplier;
    }
}
