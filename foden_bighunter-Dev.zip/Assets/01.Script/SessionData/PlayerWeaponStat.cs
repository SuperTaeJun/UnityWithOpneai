public struct PlayerWeaponStat
{
    readonly public EProjectileType SelectedType;
    readonly public int Level;
    readonly public int Damage;
    readonly public bool IsLocked;

    public PlayerWeaponStat(EProjectileType type, int lev, int damage , bool isLocked)
    {
        SelectedType = type;
        Level = lev;
        Damage = damage;
        IsLocked = isLocked;
    }
}
