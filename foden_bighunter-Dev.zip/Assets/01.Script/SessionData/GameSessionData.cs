using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameSessionData : PersistentSingleton<GameSessionData>
{
    private GameRunConfig _gameRunConfig;
    private PlayerWeaponStat _playerWeaponStat;

    //공개 프로퍼티
    public GameRunConfig GameRunConfig => _gameRunConfig;
    public PlayerWeaponStat PlayerWeaponStat => _playerWeaponStat;

    protected override void Awake()
    {
        base.Awake();

        _gameRunConfig = new GameRunConfig();
        _playerWeaponStat = new PlayerWeaponStat(EProjectileType.Javelin, 1, 10, false);

    }

    public void SetGameData(GameRunConfig gameRunConfig)
    {
        _gameRunConfig = gameRunConfig;
    }
    public void SetGameData(PlayerWeaponStat playerWeaponStat)
    {
        _playerWeaponStat = playerWeaponStat;
    }






}
