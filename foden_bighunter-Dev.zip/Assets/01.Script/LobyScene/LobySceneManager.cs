using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LobySceneManager : Singleton<LobySceneManager>
{
    [SerializeField] private Button _upgradeButton;
    [SerializeField] private Button _stageButton;

    protected override void Awake()
    {
        base.Awake();
        _upgradeButton.onClick.AddListener(OnClickedUpgradeButton);
        _stageButton.onClick.AddListener(OnClickedStageButton);
    }

    private void OnDisable()
    {
        _upgradeButton.onClick.RemoveAllListeners();
        _stageButton.onClick.RemoveAllListeners();
    }
    private void OnClickedUpgradeButton()
    {
        PopupManager.Instance.Open(EPopupType.UI_Upgrade);

    }
    private void OnClickedStageButton()
    {
        PopupManager.Instance.Open(EPopupType.UI_Stage);

    }

}
