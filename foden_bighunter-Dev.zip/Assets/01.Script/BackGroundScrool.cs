using UnityEngine;

public class BackgroundScrolling : MonoBehaviour
{
    [Header("배경 3개 - 왼/가운데/오른쪽")]
    [SerializeField] private Transform[] backgrounds;  // 길이 3 추천
    private Transform player;

    private float _spriteWidth;

    private void Awake()
    {
        if (backgrounds == null || backgrounds.Length == 0)
        {
            Debug.LogError("backgrounds 가 비어있어요!");
            return;
        }

        // 첫 번째 배경의 스프라이트 가로 길이 자동 계산
        var sr = backgrounds[0].GetComponent<SpriteRenderer>();
        if (sr == null)
        {
            Debug.LogError("배경에 SpriteRenderer가 필요합니다.");
            return;
        }

        _spriteWidth = sr.bounds.size.x;

        player = GameObject.FindWithTag("Player").transform;
    }

    private void LateUpdate()
    {
        if (player == null || backgrounds == null || backgrounds.Length == 0)
            return;

        // 가장 왼쪽, 가장 오른쪽 배경 찾기
        Transform leftMost = backgrounds[0];
        Transform rightMost = backgrounds[0];

        foreach (var bg in backgrounds)
        {
            if (bg.position.x < leftMost.position.x)
                leftMost = bg;

            if (bg.position.x > rightMost.position.x)
                rightMost = bg;
        }

        // 플레이어가 가장 왼쪽 배경보다 더 왼쪽으로 넘어가려 할 때
        if (player.position.x < leftMost.position.x)
        {
            // 제일 오른쪽 배경을 제일 왼쪽 배경의 왼쪽으로 한 칸 이동
            rightMost.position = new Vector3(
                leftMost.position.x - _spriteWidth,
                rightMost.position.y,
                rightMost.position.z
            );
        }
    }
}
