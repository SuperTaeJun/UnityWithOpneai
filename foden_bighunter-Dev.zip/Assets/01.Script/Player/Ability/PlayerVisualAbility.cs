using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerVisualAbility : PlayerAbility
{
    [SerializeField] private GameObject _chargeEffect;


    private void Start()
    {
        _chargeEffect.SetActive(false);
        _owner.GetAbility<PlayerAttackAbility>().OnCharged += OnCharged;
        _owner.GetAbility<PlayerAttackAbility>().OnEndCharged += OnEndCharged;
    }
    private void OnDisable()
    {
        _owner.GetAbility<PlayerAttackAbility>().OnCharged -= OnCharged;
        _owner.GetAbility<PlayerAttackAbility>().OnEndCharged -= OnEndCharged;
    }
    private void OnCharged()
    {
        _chargeEffect.SetActive(true);
    }
    private void OnEndCharged()
    {
        _chargeEffect.SetActive(false);
    }
}
