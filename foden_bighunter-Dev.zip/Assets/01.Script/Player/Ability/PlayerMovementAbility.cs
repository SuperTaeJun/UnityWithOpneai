using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using DG.Tweening;

public class PlayerMovementAbility : PlayerAbility
{
    [Header("이동 설정")]
    [SerializeField] private float _moveSpeed = 5f;

    [Header("회피 설정")]
    [SerializeField] private float _dodgeDistance = 3f;
    [SerializeField] private float _dodgeDuration = 0.3f;
    [SerializeField] private float _dodgeCooldown = 2f;
    [SerializeField] private float _dodgeCheckRadius = 5f;
    [SerializeField] private LayerMask _enemyLayer;
    [SerializeField] private float _slowMotionScale = 0.3f;
    [SerializeField] private float _slowMotionDuration = 0.5f;

    [Header("이동 버튼")]
    [SerializeField] private Button _moveButton;
    [SerializeField] private Button _dodgeButton;

    private bool _isInputActive = false;
    private bool _isDodging = false;
    public bool IsDodging => _isDodging;
    private float _dodgeCooldownTimer = 0f;

    private void Start()
    {
        // 이동 버튼 EventTrigger 설정
        EventTrigger moveTrigger = _moveButton.gameObject.GetComponent<EventTrigger>();
        if (moveTrigger == null)
        {
            moveTrigger = _moveButton.gameObject.AddComponent<EventTrigger>();
        }

        // PointerDown 이벤트 등록 (버튼 누를 때)
        EventTrigger.Entry pointerDown = new EventTrigger.Entry();
        pointerDown.eventID = EventTriggerType.PointerDown;
        pointerDown.callback.AddListener((data) => { OnMoveButtonDown(); });
        moveTrigger.triggers.Add(pointerDown);

        // PointerUp 이벤트 등록 (버튼 뗄 때)
        EventTrigger.Entry pointerUp = new EventTrigger.Entry();
        pointerUp.eventID = EventTriggerType.PointerUp;
        pointerUp.callback.AddListener((data) => { OnMoveButtonUp(); });
        moveTrigger.triggers.Add(pointerUp);

        // 회피 버튼 클릭 이벤트 등록
        _dodgeButton.onClick.AddListener(OnDodgeButtonClick);
    }

    private void Update()
    {
        if (GameManager.Instance.CurrentState != EGameState.Playing) return;


        HandleInput();

        // 쿨타임 감소
        if (_dodgeCooldownTimer > 0)
        {
            _dodgeCooldownTimer -= Time.deltaTime;
        }

        // 회피 중이 아닐 때만 이동
        if (_isInputActive && !_isDodging)
        {
            MoveBackward();
        }
    }

    private void HandleInput()
    {
        // PC: 스페이스바 입력 (유지)
        if (Input.GetKey(KeyCode.Space))
        {
            _isInputActive = true;
        }
        else if (Input.GetKeyUp(KeyCode.Space))
        {
            _isInputActive = false;
        }

        // PC: Shift 키로 회피
        if (Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift))
        {
            PerformDodge();
        }
    }

    // UI 버튼용 public 메서드
    public void OnMoveButtonDown()
    {
        _isInputActive = true;
    }

    public void OnMoveButtonUp()
    {
        _isInputActive = false;
    }

    public void OnDodgeButtonClick()
    {
        PerformDodge();
    }

    private void MoveBackward()
    {
        // 매 프레임마다 왼쪽으로 이동
        _owner.transform.position += Vector3.left * _moveSpeed * Time.deltaTime;
    }

    private void PerformDodge()
    {
        // 쿨타임 중이거나 이미 회피 중이면 실행 안 함
        if (_dodgeCooldownTimer > 0 || _isDodging)
        {
            return;
        }

        _owner.GetAbility<PlayerTrajectoryAbility>()?.HideDots();
        _isDodging = true;
        _dodgeCooldownTimer = _dodgeCooldown;

        // 주변에 적이 있는지 체크
        bool enemyNearby = CheckEnemyNearby();

        // 적이 주변에 있으면 슬로우 모션 효과
        if (enemyNearby)
        {
            StartSlowMotion();
        }

        Vector3 currentPos = _owner.transform.position;
        Vector3 dodgeTargetPos = new Vector3(
            currentPos.x - _dodgeDistance,
            currentPos.y,
            currentPos.z
        );

        // 한 바퀴 회전하면서 뒤로 점프
        Sequence dodgeSequence = DOTween.Sequence();

        // 360도 회전
        dodgeSequence.Append(_owner.transform.DORotate(new Vector3(0f, 0f, 360f), _dodgeDuration, RotateMode.FastBeyond360));

        // 동시에 뒤로 점프
        dodgeSequence.Join(_owner.transform.DOJump(dodgeTargetPos, 3f, 1, _dodgeDuration).SetEase(Ease.OutQuad));

        dodgeSequence.OnComplete(() =>
        {
            // 회전 값을 0으로 리셋
            _owner.transform.rotation = Quaternion.identity;
            _isDodging = false;
        });
    }

    private bool CheckEnemyNearby()
    {
        // 플레이어 주변에 적이 있는지 체크
        Collider2D[] enemies = Physics2D.OverlapCircleAll(_owner.transform.position, _dodgeCheckRadius, _enemyLayer);
        return enemies.Length > 0;
    }

    private void StartSlowMotion()
    {
        // 슬로우 모션 시작
        Time.timeScale = _slowMotionScale;
        Time.fixedDeltaTime = 0.02f * Time.timeScale;

        // 일정 시간 후 원래 속도로 복귀
        DOVirtual.DelayedCall(_slowMotionDuration * _slowMotionScale, () =>
        {
            Time.timeScale = 1f;
            Time.fixedDeltaTime = 0.02f;
        });
    }

    private void OnDrawGizmos()
    {
        if (_owner == null) return;

        // 회피 시 적 감지 범위 표시 (파란색)
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(_owner.transform.position, _dodgeCheckRadius);
    }
}
