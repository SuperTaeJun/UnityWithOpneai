using UnityEngine;

/// <summary>
/// 플레이어의 무기 스탯을 관리하는 어빌리티
/// GameSessionData에서 데이터를 받아와 초기화하고, 다른 어빌리티에서 참조 가능
/// </summary>
public class PlayerStatAbility : PlayerAbility
{
    [Header("Current Weapon Stats")]
    [SerializeField] private EProjectileType _currentWeaponType = EProjectileType.Javelin;
    [SerializeField] private int _weaponLevel = 1;
    [SerializeField] private int _weaponDamage = 10;
    [SerializeField] private float _weaponSpeed = 10f;

    // 공개 프로퍼티
    public EProjectileType CurrentWeaponType => _currentWeaponType;
    public int WeaponLevel => _weaponLevel;
    public int WeaponDamage => _weaponDamage;
    public float WeaponSpeed => _weaponSpeed;

    protected override void Awake()
    {
        base.Awake();
    }

    private void Start()
    {
        // GameSessionData에서 무기 스탯 로드
        LoadWeaponStatsFromSession();
    }

    /// <summary>
    /// GameSessionData에서 무기 스탯을 불러와 초기화
    /// </summary>
    public void LoadWeaponStatsFromSession()
    {
        if (GameSessionData.Instance != null)
        {
            PlayerWeaponStat weaponStat = GameSessionData.Instance.PlayerWeaponStat;
            InitializeStats(weaponStat);
        }
        else
        {
            Debug.LogWarning("[PlayerStatAbility] GameSessionData가 없습니다. 기본값 사용.");
        }
    }

    /// <summary>
    /// 무기 스탯 초기화
    /// </summary>
    public void InitializeStats(PlayerWeaponStat weaponStat)
    {
        _currentWeaponType = weaponStat.SelectedType;
        _weaponLevel = weaponStat.Level;
        _weaponDamage = weaponStat.Damage;

        // Player의 CurrentProjectileType도 업데이트
        if (_owner != null)
        {
            _owner.CurrentProjectileType = _currentWeaponType;
        }

        Debug.Log($"[PlayerStatAbility] 무기 스탯 초기화 완료 - Type: {_currentWeaponType}, Lv: {_weaponLevel}, DMG: {_weaponDamage}, SPD: {_weaponSpeed}");
    }

    /// <summary>
    /// 무기 타입 변경
    /// </summary>
    public void ChangeWeaponType(EProjectileType newType)
    {
        _currentWeaponType = newType;
        if (_owner != null)
        {
            _owner.CurrentProjectileType = newType;
        }
        Debug.Log($"[PlayerStatAbility] 무기 변경: {newType}");
    }

    /// <summary>
    /// 무기 레벨업 (런타임 중 업그레이드)
    /// </summary>
    public void LevelUpWeapon(int damageIncrease = 5, float speedIncrease = 1f)
    {
        _weaponLevel++;
        _weaponDamage += damageIncrease;
        _weaponSpeed += speedIncrease;

        Debug.Log($"[PlayerStatAbility] 무기 레벨업! Lv.{_weaponLevel} - DMG: {_weaponDamage}, SPD: {_weaponSpeed}");
    }

    /// <summary>
    /// 데미지 배율 적용 (버프/디버프 등)
    /// </summary>
    public int GetModifiedDamage(float multiplier = 1f)
    {
        return Mathf.RoundToInt(_weaponDamage * multiplier);
    }

    /// <summary>
    /// 속도 배율 적용 (버프/디버프 등)
    /// </summary>
    public float GetModifiedSpeed(float multiplier = 1f)
    {
        return _weaponSpeed * multiplier;
    }

    /// <summary>
    /// 현재 스탯 정보 출력 (디버그용)
    /// </summary>
    public void PrintStats()
    {
        Debug.Log($"=== Player Weapon Stats ===\n" +
                  $"Type: {_currentWeaponType}\n" +
                  $"Level: {_weaponLevel}\n" +
                  $"Damage: {_weaponDamage}\n" +
                  $"Speed: {_weaponSpeed}\n");
    }

#if UNITY_EDITOR
    // 에디터에서 테스트용
    [ContextMenu("Print Current Stats")]
    private void DebugPrintStats()
    {
        PrintStats();
    }

    [ContextMenu("Level Up Weapon")]
    private void DebugLevelUp()
    {
        LevelUpWeapon();
    }

    [ContextMenu("Reload From Session")]
    private void DebugReloadFromSession()
    {
        LoadWeaponStatsFromSession();
    }
#endif
}
