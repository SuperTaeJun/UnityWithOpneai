using System.Collections.Generic;
using UnityEngine;

public class PlayerTrajectoryAbility : PlayerAbility
{
    [Header("경로 프리뷰(점) 설정")]
    [SerializeField] private GameObject _aimDotPrefab;     // 작은 점 프리팹
    [SerializeField] private int _dotCount = 10;           // 점 개수
    [SerializeField] private float _dotDistanceStep = 1f;  // 점 사이 거리 간격 (월드 유닛)
    [SerializeField] private float _animationSpeed = 2f;   // 점 애니메이션 속도
    [SerializeField] private float _fadeStartRatio = 0.6f; // 페이드 시작 비율 (0.6 = 60%부터 페이드)

    [Header("부메랑 궤적 설정")]
    [SerializeField] private float _boomerangCurveHeight = 4f;

    [Header("레이저 궤적 설정")]
    [SerializeField] private float _laserPeakHeight = 2.5f;

    [Header("바운스볼 궤적 설정")]
    [SerializeField] private float _bounceBallGroundLevel = 0f;

    private readonly List<Transform> _dots = new List<Transform>();
    private readonly List<SpriteRenderer> _dotRenderers = new List<SpriteRenderer>();
    private readonly List<Vector3> _targetDotPositions = new List<Vector3>(); // 목표 위치
    private bool _dotsInitialized = false;
    private float _animationOffset = 0f;
    private bool _isAnimating = false;

    // 궤적 경로 캐시
    private readonly List<Vector3> _cachedTrajectoryPoints = new List<Vector3>();
    private readonly List<float> _cachedSegmentLengths = new List<float>();
    private float _cachedTotalPathLength = 0f;
    private float _cachedPowerScale = 1f;

    [Header("부드러운 전환")]
    [SerializeField] private float _trajectoryLerpSpeed = 20f; // 궤적 변경 시 보간 속도

    [Header("Javelin 궤적 파라미터")]
    [SerializeField] private float _javelinFallGravity = 15f;
    [SerializeField] private float _javelinMaxFallSpeed = 150f;

    private Dictionary<EProjectileType, ITrajectoryStrategy> _trajectoryStrategies;

    private void Start()
    {
        InitializeDots();
        InitializeStrategies();
    }

    private void Update()
    {
        if (_isAnimating)
        {
            AnimateTrail();
        }
    }
    private void InitializeStrategies()
    {
        _trajectoryStrategies = new Dictionary<EProjectileType, ITrajectoryStrategy>
        {
            {
                EProjectileType.Javelin,
                new JavelinTrajectoryStrategy(_javelinFallGravity, _javelinMaxFallSpeed)
            },
            {
                EProjectileType.Boomerang,
                new BoomerangTrajectoryStrategy(_boomerangCurveHeight)
            },
            {
                EProjectileType.Laser,
                new LaserTrajectoryStrategy(_laserPeakHeight)
            },
            {
                EProjectileType.BounceBall,
                new BounceBallTrajectory(_bounceBallGroundLevel)
            }
        };
    }
    private void InitializeDots()
    {
        if (_aimDotPrefab == null || _dotsInitialized)
            return;

        for (int i = 0; i < _dotCount; i++)
        {
            GameObject dot = Instantiate(_aimDotPrefab, Vector3.zero, Quaternion.identity, _owner.transform);
            dot.SetActive(false);
            _dots.Add(dot.transform);
            _targetDotPositions.Add(Vector3.zero);

            SpriteRenderer sr = dot.GetComponent<SpriteRenderer>();
            if (sr == null)
            {
                sr = dot.AddComponent<SpriteRenderer>();
            }
            _dotRenderers.Add(sr);
        }

        _dotsInitialized = true;
    }

    public void ShowDots()
    {
        if (!_dotsInitialized) return;

        foreach (var t in _dots)
            t.gameObject.SetActive(true);

        _isAnimating = true;
        _animationOffset = 0f;
    }

    public void HideDots()
    {
        if (!_dotsInitialized) return;

        foreach (var t in _dots)
            t.gameObject.SetActive(false);

        _isAnimating = false;
    }

    /// <summary>
    /// 현재 파워/각도에 해당하는 포물선 경로를 점들로 표시
    /// </summary>
    public void UpdateDots(EProjectileType projectileType, float powerScale, float angleDeg, Vector3 startPos, float throwForce, float gravity)
    {
        if (!_dotsInitialized || _trajectoryStrategies == null) return;

        if (!_trajectoryStrategies.TryGetValue(projectileType, out var strategy))
        {
            // 등록 안 된 타입은 기본으로 Javelin 사용 (원하면 변경 가능)
            if (!_trajectoryStrategies.TryGetValue(EProjectileType.Javelin, out strategy))
                return;
        }

        strategy.CacheTrajectory(
            powerScale,
            angleDeg,
            startPos,
            throwForce,
            gravity,
            _cachedTrajectoryPoints,
            _cachedSegmentLengths,
            out _cachedTotalPathLength,
            out _cachedPowerScale
        );

        UpdateDotsWithAnimation();
    }

    /// <summary>
    /// 애니메이션 트레일 효과
    /// </summary>
    private void AnimateTrail()
    {
        _animationOffset += Time.deltaTime * _animationSpeed;

        // 궤적 경로가 캐시되어 있으면 애니메이션만 적용
        if (_cachedTrajectoryPoints.Count > 0)
        {
            UpdateDotsWithAnimation();
        }
    }

    private void UpdateDotsWithAnimation()
    {
        if (_cachedTrajectoryPoints.Count == 0) return;

        float adjustedDotDistance = _dotDistanceStep * _cachedPowerScale;
        float totalDotsDistance = adjustedDotDistance * _dots.Count;
        float lerpFactor = _trajectoryLerpSpeed * Time.deltaTime;

        for (int i = 0; i < _dots.Count; i++)
        {
            float targetDistance = (_animationOffset + adjustedDotDistance * i) % totalDotsDistance;

            // 캐시된 세그먼트 길이를 사용하여 경로상의 목표 위치 찾기
            float accumulatedDistance = 0f;
            Vector3 targetPosition = _cachedTrajectoryPoints[0];
            bool foundPosition = false;

            for (int j = 0; j < _cachedSegmentLengths.Count; j++)
            {
                if (accumulatedDistance + _cachedSegmentLengths[j] >= targetDistance)
                {
                    float t = (targetDistance - accumulatedDistance) / _cachedSegmentLengths[j];
                    targetPosition = Vector3.Lerp(_cachedTrajectoryPoints[j], _cachedTrajectoryPoints[j + 1], t);
                    foundPosition = true;
                    break;
                }

                accumulatedDistance += _cachedSegmentLengths[j];
            }

            // 경로를 벗어나면 비활성화
            if (!foundPosition || targetDistance > _cachedTotalPathLength)
            {
                _dots[i].gameObject.SetActive(false);
                continue;
            }

            // 루프 시작점으로 돌아오는지 확인 (거리가 크게 변했는지 체크)
            bool isLooping = Vector3.Distance(_targetDotPositions[i], targetPosition) > adjustedDotDistance * 2f;

            // 목표 위치 저장
            _targetDotPositions[i] = targetPosition;

            // 루프 시작점으로 돌아올 때는 즉시 이동, 아니면 부드럽게 보간
            if (isLooping)
            {
                _dots[i].position = targetPosition;
            }
            else
            {
                _dots[i].position = Vector3.Lerp(_dots[i].position, _targetDotPositions[i], lerpFactor);
            }

            _dots[i].gameObject.SetActive(true);

            // 페이드 효과 적용
            float pathProgress = targetDistance / totalDotsDistance;
            float alpha = 1f;

            if (pathProgress > _fadeStartRatio)
            {
                float fadeProgress = (pathProgress - _fadeStartRatio) / (1f - _fadeStartRatio);
                alpha = 1f - fadeProgress;
            }

            if (_dotRenderers[i] != null)
            {
                Color color = _dotRenderers[i].color;
                color.a = alpha;
                _dotRenderers[i].color = color;
            }
        }
    }

}
