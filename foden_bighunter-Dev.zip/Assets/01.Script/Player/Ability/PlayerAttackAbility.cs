using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerAttackAbility : PlayerAbility
{
    [SerializeField] private Button _weaponChangeButton;

    [Header("투사체 설정")]
    [SerializeField] private Transform _throwPoint;
    [SerializeField] private float _throwForce = 15f;
    [SerializeField] private float _gravity = 30f; // 빅헌터 느낌을 위해 높게 설정 추천

    [Header("각도 조절 설정")]
    [SerializeField] private float _minThrowAngle = 0f;    
    [SerializeField] private float _maxThrowAngle = 85f;   

    [Header("파워 차지 설정")]
    [SerializeField] private float _minDragDistance = 50f;
    [SerializeField] private float _maxDragDistance = 300f;
    [SerializeField] private float _maxPowerMultiplier = 2f;

    [Header("입력 범위 설정 (반응 영역)")]
    [Range(0.05f, 0.5f)] 
    [SerializeField] private float _inputRadiusRatio = 0.15f;

    // =========================================================
    // [추가] 조작감(부드러움/민감도) 설정
    // =========================================================
    [Header("조작감 설정 (낮을수록 묵직함)")]
    [Range(1f, 50f)]
    [SerializeField] private float _aimSmoothSpeed = 10f; // 추천값: 10 ~ 15

    // 현재 실제로 조준하고 있는 값 (보간된 값)
    private float _currentAimAngle;
    private float _currentPowerScale;
    // =========================================================

    [Header("부메랑 설정")]
    [SerializeField] private Transform _boomerangDirectionRef;

    private bool _isAiming = false;
    private Vector2 _startPos;
    private int _fireStack = 0;

    public event Action OnCharged;
    public event Action OnEndCharged;

    private List<EProjectileType> _availableWeapons = new List<EProjectileType>
    {
        EProjectileType.Javelin,
        EProjectileType.Boomerang,
        EProjectileType.Laser,
        EProjectileType.BounceBall
    };
    private int _currentWeaponIndex = 0;

    private void Start()
    {
        if (_weaponChangeButton != null)
            _weaponChangeButton.onClick.AddListener(WeaponChange);

        _currentWeaponIndex = _availableWeapons.IndexOf(_owner.CurrentProjectileType);
        if (_currentWeaponIndex < 0)
        {
            _currentWeaponIndex = 0;
            _owner.CurrentProjectileType = _availableWeapons[_currentWeaponIndex];
        }
    }

    private void WeaponChange()
    {
        _currentWeaponIndex = (_currentWeaponIndex + 1) % _availableWeapons.Count;
        _owner.CurrentProjectileType = _availableWeapons[_currentWeaponIndex];
    }

    private void Update()
    {
        if (GameManager.Instance.CurrentState != EGameState.Playing) return;

        HandleTouchInput();

        // 디버그용 키 입력 생략...
    }

    private void HandleTouchInput()
    {
        if (_owner.GetAbility<PlayerMovementAbility>().IsDodging) return;

        bool isDown = Input.GetMouseButtonDown(0) || (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began);
        bool isPress = Input.GetMouseButton(0) || (Input.touchCount > 0 && (Input.GetTouch(0).phase == TouchPhase.Moved || Input.GetTouch(0).phase == TouchPhase.Stationary));
        bool isUp = Input.GetMouseButtonUp(0) || (Input.touchCount > 0 && (Input.GetTouch(0).phase == TouchPhase.Ended || Input.GetTouch(0).phase == TouchPhase.Canceled));

        Vector2 currentInputPos = Input.touchCount > 0 ? Input.GetTouch(0).position : (Vector2)Input.mousePosition;
        Vector3 startPos = _throwPoint != null ? _throwPoint.position : _owner.transform.position;

        // 1. 입력 시작
        if (isDown)
        {
            Vector3 playerScreenPos = Camera.main.WorldToScreenPoint(_owner.transform.position);
            float dynamicRadius = Screen.height * _inputRadiusRatio;
            float distanceToPlayer = Vector2.Distance(currentInputPos, (Vector2)playerScreenPos);

            if (distanceToPlayer <= dynamicRadius)
            {
                _isAiming = true;
                _startPos = currentInputPos;

                _owner.GetAbility<PlayerTrajectoryAbility>()?.ShowDots();

                // [중요] 터치 시작 시점에는 '목표값'으로 즉시 초기화 (튀는 현상 방지)
                _currentAimAngle = CalculateAngle(_startPos, currentInputPos);
                _currentPowerScale = CalculatePowerScale(_startPos, currentInputPos);

                // 초기화된 값으로 궤적 표시
                _owner.GetAbility<PlayerTrajectoryAbility>()?.UpdateDots(_owner.CurrentProjectileType, _currentPowerScale, _currentAimAngle, startPos, _throwForce, _gravity);
            }
        }

        // 2. 드래그 중 (조준)
        if (isPress && _isAiming)
        {
            // A. 내 손가락이 가리키는 '순수 목표값' 계산
            float targetPower = CalculatePowerScale(_startPos, currentInputPos);
            float targetAngle = CalculateAngle(_startPos, currentInputPos);

            // B. [핵심] 현재값 -> 목표값으로 부드럽게 이동 (Lerp)
            // Time.deltaTime * Speed를 통해 프레임 드랍에도 일정한 속도로 따라감
            _currentPowerScale = Mathf.Lerp(_currentPowerScale, targetPower, Time.deltaTime * _aimSmoothSpeed);
            
            // LerpAngle을 써야 360도 회전 문제 없이 자연스럽게 각도 보간
            _currentAimAngle = Mathf.LerpAngle(_currentAimAngle, targetAngle, Time.deltaTime * _aimSmoothSpeed);

            // C. 보간된 값(_current...)을 이용해 궤적 업데이트
            // 이렇게 해야 궤적과 실제 발사 각도가 일치하게 보임
            _owner.GetAbility<PlayerTrajectoryAbility>()?.UpdateDots(_owner.CurrentProjectileType, _currentPowerScale, _currentAimAngle, startPos, _throwForce, _gravity);
        }

        // 3. 입력 종료 (발사)
        if (isUp && _isAiming)
        {
            _owner.GetAbility<PlayerTrajectoryAbility>()?.HideDots();
            
            // [중요] 손을 뗄 때도 '보간된 값(Current)'으로 발사해야 
            // 화면에 보이던 궤적 그대로 날아감 (손맛 유지)
            ThrowProjectile(_currentPowerScale, _currentAimAngle);
            
            _isAiming = false;
        }
    }

    // 순수 계산 로직 (민감도 로직 제거 -> Lerp로 대체했기 때문)
    private float CalculatePowerScale(Vector2 start, Vector2 end)
    {
        float distance = Vector2.Distance(start, end);
        if (distance <= _minDragDistance) return 1f;
        float t = Mathf.InverseLerp(_minDragDistance, _maxDragDistance, distance);
        return Mathf.Lerp(1f, _maxPowerMultiplier, t);
    }

    // 순수 계산 로직 (민감도 로직 제거 -> Lerp로 대체했기 때문)
    private float CalculateAngle(Vector2 start, Vector2 end)
    {
        Vector2 aimVector = start - end;
        
        // 너무 조금 당겼을 때 방지
        if (aimVector.magnitude < 10f) 
            return (_minThrowAngle + _maxThrowAngle) * 0.5f;

        float angleDeg = Mathf.Atan2(aimVector.y, aimVector.x) * Mathf.Rad2Deg;
        return Mathf.Clamp(angleDeg, _minThrowAngle, _maxThrowAngle);
    }

    private void ThrowProjectile(float powerScale, float angleDeg)
    {
        // ... (기존 발사 로직 동일) ...
        Vector3 spawnPosition = _throwPoint != null ? _throwPoint.position : _owner.transform.position;
        GameObject projectileObj = ObjectPoolManager.Instance.GetProjectile(_owner.CurrentProjectileType, spawnPosition, Quaternion.identity);

        if (projectileObj != null)
        {
            IProjectileLauncher launcher = projectileObj.GetComponent<IProjectileLauncher>();
            if (launcher != null)
            {
                _fireStack++;
                if (_fireStack == 3) OnCharged?.Invoke();
                bool isCharged = _fireStack > 3;
                DamageInfo damageInfo = new DamageInfo(_owner.Damage);

                launcher.Launch(damageInfo, spawnPosition, powerScale, angleDeg, _throwForce, _gravity, isCharged);

                if (isCharged)
                {
                    _fireStack = 0;
                    OnEndCharged?.Invoke();
                }
            }
        }
    }
}