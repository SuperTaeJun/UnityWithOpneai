using System;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
public class Player : MonoBehaviour, IDamageable
{
    [field: Header("플레이어 컴포넌트")]
    [field: SerializeField] public SpriteRenderer SpriteRenderer { get; private set; }
    [field: SerializeField] public Rigidbody2D Rigidbody2D { get; private set; }
    [field: SerializeField] public Animator Animator { get; private set; }
    [field: SerializeField] public CapsuleCollider2D CapsuleCollider2D { get; private set; }

    private Dictionary<Type, PlayerAbility> _abilitiesCache = new();

    [SerializeField] public EProjectileType CurrentProjectileType; // 현재 사용 중인 투사체 타입
    [SerializeField] public float Speed;
    [SerializeField] public int Level;
    [SerializeField] public int Damage;


    [SerializeField] private float _moveTime = 1.0f;
    [SerializeField] private Ease _easeType = Ease.OutBack; // 살짝 튕기며 도착하는 느낌

    private Vector3 _targetPos;
    private void Awake()
    {
        if (GameSessionData.Instance != null)
        {
            PlayerWeaponStat currentWeapon = GameSessionData.Instance.PlayerWeaponStat;

            CurrentProjectileType = currentWeapon.SelectedType;
            Level = currentWeapon.Level;
            Damage = currentWeapon.Damage;
        }

        _targetPos = transform.position; // 에디터에 배치해둔 원래 위치 저장

        // 시작할 땐 왼쪽 화면 밖으로 보내두기
        transform.position = _targetPos + new Vector3(-20f, 0, 0);
    }
    public Tween MoveIn()
    {
        // 목표 지점으로 이동하는 트윈을 생성하고 리턴
        return transform.DOMove(_targetPos, _moveTime).SetEase(_easeType);
    }
    public T GetAbility<T>() where T : PlayerAbility
    {
        var type = typeof(T);

        if (_abilitiesCache.TryGetValue(type, out PlayerAbility ability))
        {
            return ability as T;
        }

        ability = GetComponentInChildren<T>();

        if (ability != null)
        {
            _abilitiesCache[ability.GetType()] = ability;

            return ability as T;
        }

        throw new Exception($"어빌리티 {type.Name}을(를) {gameObject.name}에서 찾을 수 없습니다.");
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.K))
        {
            DamageInfo damageInfo = new DamageInfo(10);
            TakeDamage(damageInfo);
        }
    }
    public void TakeDamage(DamageInfo damageInfo)
    {
        PopupManager.Instance.Open(EPopupType.UI_Defeat);
    }
}
