using System.Collections.Generic;
using UnityEngine;
public class LaserTrajectoryStrategy : ITrajectoryStrategy
{
    public EProjectileType ProjectileType => EProjectileType.Laser;

    private readonly float _peakHeight;
    private const float RANGE_RATIO = 0.3f;

    public LaserTrajectoryStrategy(float peakHeight)
    {
        _peakHeight = peakHeight;
    }

    public void CacheTrajectory(
        float powerScale,
        float angleDeg,
        Vector3 startPos,
        float throwForce,
        float gravity,
        List<Vector3> cachedPoints,
        List<float> cachedSegmentLengths,
        out float totalPathLength,
        out float cachedPowerScale
    )
    {
        cachedPowerScale = powerScale;
        cachedPoints.Clear();
        cachedSegmentLengths.Clear();
        totalPathLength = 0f;

        float rad = (angleDeg - 40f) * Mathf.Deg2Rad;
        Vector2 forwardDir = new Vector2(Mathf.Cos(rad), Mathf.Sin(rad)).normalized;

        float dist = throwForce * powerScale * RANGE_RATIO;
        float height = _peakHeight * powerScale;

        Vector3 p0 = startPos;
        Vector3 p2 = startPos + new Vector3(forwardDir.x * dist, forwardDir.y * dist, 0);

        Vector2 perpDir = new Vector2(-forwardDir.y, forwardDir.x);
        Vector3 midPoint = (p0 + p2) / 2f;
        Vector3 p1 = midPoint + new Vector3(perpDir.x * height, perpDir.y * height, 0);

        int segmentsPerHalf = 15;
        Vector3 prevPos = p0;

        cachedPoints.Add(p0);

        // 시작 → 정점
        for (int i = 1; i <= segmentsPerHalf; i++)
        {
            float t = i / (float)segmentsPerHalf;
            Vector3 currentPos = Vector3.Lerp(p0, p1, t);

            cachedPoints.Add(currentPos);

            float segLen = Vector3.Distance(prevPos, currentPos);
            cachedSegmentLengths.Add(segLen);
            totalPathLength += segLen;

            prevPos = currentPos;
        }

        // 정점 → 끝
        for (int i = 1; i <= segmentsPerHalf; i++)
        {
            float t = i / (float)segmentsPerHalf;
            Vector3 currentPos = Vector3.Lerp(p1, p2, t);

            cachedPoints.Add(currentPos);

            float segLen = Vector3.Distance(prevPos, currentPos);
            cachedSegmentLengths.Add(segLen);
            totalPathLength += segLen;

            prevPos = currentPos;
        }
    }
}
