using System.Collections.Generic;
using UnityEngine;

public class JavelinTrajectoryStrategy : ITrajectoryStrategy
{
    public EProjectileType ProjectileType => EProjectileType.Javelin;

    // 이제 불필요해진 변수들 (생성자에서도 제거하거나 무시해도 됩니다)
    private readonly float _fallGravity;
    private readonly float _maxFallSpeed;

    public JavelinTrajectoryStrategy(float fallGravity, float maxFallSpeed)
    {
        _fallGravity = fallGravity;
        _maxFallSpeed = maxFallSpeed;
    }

    public void CacheTrajectory(
        float powerScale,
        float angleDeg,
        Vector3 startPos,
        float throwForce,
        float gravity,
        List<Vector3> cachedPoints,
        List<float> cachedSegmentLengths,
        out float totalPathLength,
        out float cachedPowerScale
    )
    {
        cachedPowerScale = powerScale;
        cachedPoints.Clear();
        cachedSegmentLengths.Clear();
        totalPathLength = 0f;

        float angleRad = angleDeg * Mathf.Deg2Rad;
        float v0 = throwForce * powerScale;

        // 초기 속도 벡터
        Vector2 currentVelocity = new Vector2(
            v0 * Mathf.Cos(angleRad),
            v0 * Mathf.Sin(angleRad)
        );

        Vector3 currentPos = startPos;

        // 시뮬레이션 설정
        float timeStep = 0.02f; // 간격을 조금 넓혀서 연산 최적화 (0.01 -> 0.02)
        float currentTime = 0f;
        float maxTime = 3.0f;   // 빅헌터 스타일은 빠르기 때문에 3초면 충분히 바닥에 닿음

        while (currentTime < maxTime)
        {
            Vector3 prevPos = currentPos;
            cachedPoints.Add(currentPos);

            // [수정됨] 물리 공식 단순화: 등가속도 운동 (Standard Projectile Motion)
            // 위치 = 현재위치 + 속도*시간 + 0.5*가속도*시간^2 등의 적분 방식 대신
            // 오일러 적분법(Euler Integration)으로 간단하게 처리해도 충분히 정확합니다.

            // 1. 위치 이동
            currentPos += (Vector3)currentVelocity * timeStep;

            // 2. 중력 적용 (일정한 중력만 적용)
            // ProjectileMove에서 _fallGravity 로직을 뺐으므로 여기서도 뺍니다.
            currentVelocity.y -= gravity * timeStep;

            // [옵션] 공기 저항(Linear Drag)이 있다면 여기에 적용
            currentVelocity *= (1f - 0.5f * timeStep);

            // 3. 거리 계산 및 저장
            if (cachedPoints.Count > 1)
            {
                float segLen = Vector3.Distance(prevPos, currentPos);
                cachedSegmentLengths.Add(segLen);
                totalPathLength += segLen;
            }

            // 바닥(y < -10 등)에 닿으면 그만 그리기 (최적화)
            // 필요하다면 조건 추가: if (currentPos.y < -10f) break;

            currentTime += timeStep;
        }
    }
}