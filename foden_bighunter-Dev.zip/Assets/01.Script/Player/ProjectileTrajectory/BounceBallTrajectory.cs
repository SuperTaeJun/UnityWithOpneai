using System.Collections.Generic;
using UnityEngine;

public class BounceBallTrajectory : ITrajectoryStrategy
{
    public EProjectileType ProjectileType => EProjectileType.BounceBall;

    private readonly float _groundLevel = 0f;
    private readonly float _bounceHeight = 5f;
    private readonly float _bounceHeightDecay = 0.7f;
    private readonly int _maxBounceCount = 3;
    private readonly float _horizontalSpeed = 4f;

    public BounceBallTrajectory(float groundLevel = 0f)
    {
        _groundLevel = groundLevel;
    }

    public void CacheTrajectory(
        float powerScale,
        float angleDeg,
        Vector3 startPos,
        float throwForce,
        float gravity,
        List<Vector3> cachedPoints,
        List<float> cachedSegmentLengths,
        out float totalPathLength,
        out float cachedPowerScale
    )
    {
        cachedPowerScale = powerScale;
        cachedPoints.Clear();
        cachedSegmentLengths.Clear();
        totalPathLength = 0f;

        // 파워에 따라 높이 설정
        float currentBounceHeight = _bounceHeight * powerScale;
        float phaseDuration = 0.5f; // 한 단계 시간
        int pointsPerPhase = 10; // 각 단계당 점 개수

        Vector3 currentPos = startPos;
        Vector3 prevPos = startPos;
        cachedPoints.Add(startPos);

        // 바운스 시뮬레이션
        for (int bounce = 0; bounce <= _maxBounceCount; bounce++)
        {
            // 1. 떨어지는 단계 (현재 위치 → 바닥)
            float startY = currentPos.y;
            float targetY = _groundLevel;

            for (int i = 1; i <= pointsPerPhase; i++)
            {
                float t = i / (float)pointsPerPhase;
                t = t * t; // EaseIn

                Vector3 newPos = new Vector3(
                    currentPos.x + (_horizontalSpeed * powerScale * phaseDuration * t),
                    Mathf.Lerp(startY, targetY, t),
                    startPos.z
                );

                cachedPoints.Add(newPos);

                float segLen = Vector3.Distance(prevPos, newPos);
                cachedSegmentLengths.Add(segLen);
                totalPathLength += segLen;

                prevPos = newPos;
            }

            // 바닥 위치 업데이트
            currentPos = new Vector3(
                currentPos.x + (_horizontalSpeed * powerScale * phaseDuration),
                _groundLevel,
                startPos.z
            );

            // 마지막 바운스면 종료
            if (bounce >= _maxBounceCount)
                break;

            // 2. 올라가는 단계 (바닥 → 목표 높이)
            startY = _groundLevel;
            targetY = _groundLevel + currentBounceHeight;

            for (int i = 1; i <= pointsPerPhase; i++)
            {
                float t = i / (float)pointsPerPhase;
                t = 1f - (1f - t) * (1f - t); // EaseOut

                Vector3 newPos = new Vector3(
                    currentPos.x + (_horizontalSpeed * powerScale * phaseDuration * t),
                    Mathf.Lerp(startY, targetY, t),
                    startPos.z
                );

                cachedPoints.Add(newPos);

                float segLen = Vector3.Distance(prevPos, newPos);
                cachedSegmentLengths.Add(segLen);
                totalPathLength += segLen;

                prevPos = newPos;
            }

            // 최고점 위치 업데이트
            currentPos = new Vector3(
                currentPos.x + (_horizontalSpeed * powerScale * phaseDuration),
                _groundLevel + currentBounceHeight,
                startPos.z
            );

            // 다음 바운스 높이 감소
            currentBounceHeight *= _bounceHeightDecay;
        }
    }
}
