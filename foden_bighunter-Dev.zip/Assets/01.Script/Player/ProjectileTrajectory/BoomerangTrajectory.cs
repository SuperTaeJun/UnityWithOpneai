using System.Collections.Generic;
using UnityEngine;
public class BoomerangTrajectoryStrategy : ITrajectoryStrategy
{
    public EProjectileType ProjectileType => EProjectileType.Boomerang;

    private readonly float _curveHeight;
    private const float RANGE_RATIO = 0.4f;

    public BoomerangTrajectoryStrategy(float curveHeight)
    {
        _curveHeight = curveHeight;
    }

    public void CacheTrajectory(
        float powerScale,
        float angleDeg,
        Vector3 startPos,
        float throwForce,
        float gravity,
        List<Vector3> cachedPoints,
        List<float> cachedSegmentLengths,
        out float totalPathLength,
        out float cachedPowerScale
    )
    {
        cachedPowerScale = powerScale;
        cachedPoints.Clear();
        cachedSegmentLengths.Clear();
        totalPathLength = 0f;

        float rad = angleDeg * Mathf.Deg2Rad;
        Vector3 forwardDir = new Vector3(Mathf.Cos(rad), Mathf.Sin(rad), 0).normalized;

        Vector3 perpDir = new Vector3(-forwardDir.y, forwardDir.x, 0);
        if (forwardDir.x < 0) perpDir *= -1;
        
        float dist = (throwForce * RANGE_RATIO) * powerScale;
        float width = _curveHeight * powerScale;

        Vector3 p0 = startPos;
        Vector3 p3 = startPos;

        Vector3 p1, p2;
        if (angleDeg <= 20f)
        {
            p1 = startPos + (forwardDir * dist) - (perpDir * width);
            p2 = startPos + (forwardDir * dist) + (perpDir * width);
        }
        else
        {
            p1 = startPos + (forwardDir * dist) + (perpDir * width);
            p2 = startPos + (forwardDir * dist) - (perpDir * width);
        }

        int segments = 30;
        Vector3 prevPos = p0;

        cachedPoints.Add(p0);

        for (int i = 1; i <= segments; i++)
        {
            float t = i / (float)segments;
            Vector3 currentPos = GetCubicBezierPoint(t, p0, p1, p2, p3);

            cachedPoints.Add(currentPos);

            float segLen = Vector3.Distance(prevPos, currentPos);
            cachedSegmentLengths.Add(segLen);
            totalPathLength += segLen;

            prevPos = currentPos;
        }
    }

    private Vector3 GetCubicBezierPoint(float t, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3)
    {
        float u = 1 - t;
        float tt = t * t;
        float uu = u * u;
        float uuu = uu * u;
        float ttt = tt * t;

        Vector3 p = uuu * p0;
        p += 3 * uu * t * p1;
        p += 3 * u * tt * p2;
        p += ttt * p3;

        return p;
    }
}
