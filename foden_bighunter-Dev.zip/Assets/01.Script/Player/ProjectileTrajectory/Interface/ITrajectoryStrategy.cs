using System.Collections.Generic;
using UnityEngine;

public interface ITrajectoryStrategy
{
    EProjectileType ProjectileType { get; }

    void CacheTrajectory(
        float powerScale,
        float angleDeg,
        Vector3 startPos,
        float throwForce,
        float gravity,
        List<Vector3> cachedPoints,
        List<float> cachedSegmentLengths,
        out float totalPathLength,
        out float cachedPowerScale
    );
}