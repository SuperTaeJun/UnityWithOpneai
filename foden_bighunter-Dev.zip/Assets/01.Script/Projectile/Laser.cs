using UnityEngine;
using DG.Tweening;
using System.Collections.Generic;

public class Laser : ProjectileBase
{
    [Header("레이저 궤적 설정")]
    [SerializeField] private float _forwardDistance = 20f;      // 앞으로 나아갈 최대 거리
    [SerializeField] private float _peakHeight = 5f;            // 뒤집은 V자의 정점 높이
    [SerializeField] private float _travelDuration = 1.5f;      // 전체 이동 시간
    [SerializeField] private float _rotationSpeed = 360f;       // 회전 속도 (도/초)
    [SerializeField] private float _continueSpeed = 15f;        // 종료점 이후 계속 전진하는 속도

    [Header("타격 설정")]
    [SerializeField] private float _damageInterval = 0.2f;      // 같은 적에게 데미지를 주는 간격
    [Header("거리 조절 설정")]
    [Range(0.1f, 1.0f)]
    [SerializeField] private float _rangeRatio = 0.4f; // 들어오는 힘의 40%만 거리로 사용

    // 내부 상태
    private bool _isCharged = false;
    private Vector3 _startPosition;                             // 시작 위치
    private Vector3 _endPosition;                               // 종료 위치
    private Vector3 _peakPosition;                              // 정점 위치
    private float _elapsedTime;                                 // 경과 시간
    private float _powerScale = 1f;
    private float _angleDeg = 45f;
    private bool _isInitialized = false;
    private bool _isContinuing = false;                         // 종료점 이후 계속 전진 중인지
    private Vector2 _continueDirection;                         // 계속 전진할 방향

    // 적 데미지 쿨다운 관리
    private Dictionary<Collider2D, float> _lastDamageTime = new Dictionary<Collider2D, float>();

    public void SetPowerScale(float scale) => _powerScale = Mathf.Max(0.1f, scale);
    public void SetAngle(float angle) => _angleDeg = angle;
    public void SetForwardDistance(float distance) => _forwardDistance = distance;

    public void SetLaserPath()
    {
        _startPosition = transform.position;
        _elapsedTime = 0f;
        _lastDamageTime.Clear();
        _isInitialized = false;

        CalculateInvertedVPath();
    }

    /// 뒤집은 V자 경로 계산 (∧ 모양)
    /// 시작점 -> 정점(위) -> 종료점 순서로 이동
    private void CalculateInvertedVPath()
    {
        // 방향 벡터 계산
        float rad = _angleDeg * Mathf.Deg2Rad;
        Vector2 forwardDir = new Vector2(Mathf.Cos(rad), Mathf.Sin(rad)).normalized;

        // 거리 및 높이 계산 (파워 스케일 적용)
        float dist = _forwardDistance * _powerScale;
        float height = _peakHeight * _powerScale;

        // 시작점
        _startPosition = transform.position;

        // 종료점 (시작점에서 forwardDir 방향으로 dist만큼 이동)
        _endPosition = _startPosition + new Vector3(forwardDir.x * dist, forwardDir.y * dist, 0);

        // 정점 (시작점과 종료점의 중간 지점에서 수직 방향으로 height만큼)
        // 2D에서 수직 방향 = forwardDir의 수직 벡터
        Vector2 perpDir = new Vector2(-forwardDir.y, forwardDir.x); // 왼쪽으로 90도 회전
        Vector3 midPoint = (_startPosition + _endPosition) / 2f;
        _peakPosition = midPoint + new Vector3(perpDir.x * height, perpDir.y * height, 0);

        _isInitialized = true;
    }

    protected override void OnEnable()
    {
        base.OnEnable();

        if (Rigidbody2D != null)
        {
            Rigidbody2D.gravityScale = 0f;
            Rigidbody2D.velocity = Vector2.zero;
        }

        _elapsedTime = 0f;
        _lastDamageTime.Clear();
        _isInitialized = false;
        _isContinuing = false;
    }

    protected override void ProjectileMove()
    {
        if (!_isInitialized) return;

        Vector3 newPosition;

        // 1. 종료점 이후 계속 전진 모드
        if (_isContinuing)
        {
            // _continueSpeed는 아래(t >= 1f)에서 계산된 '기존 속도'가 적용됩니다.
            newPosition = transform.position + (Vector3)_continueDirection * _continueSpeed * Time.deltaTime;

            if (Rigidbody2D != null) Rigidbody2D.MovePosition(newPosition);
            else transform.position = newPosition;

            transform.Rotate(0, 0, _rotationSpeed * Time.deltaTime);
            return;
        }

        // 2. 궤적 이동 모드
        _elapsedTime += Time.deltaTime;

        // 전체 경로를 0~1로 정규화
        float t = Mathf.Clamp01(_elapsedTime / _travelDuration);

        if (t <= 0.5f)
        {
            // 1구간: 시작점 -> 정점
            float localT = t / 0.5f;
            newPosition = Vector3.Lerp(_startPosition, _peakPosition, localT);
        }
        else
        {
            // 2구간: 정점 -> 종료점
            float localT = (t - 0.5f) / 0.5f;
            newPosition = Vector3.Lerp(_peakPosition, _endPosition, localT);
        }

        // 위치 업데이트
        if (Rigidbody2D != null) Rigidbody2D.MovePosition(newPosition);
        else transform.position = newPosition;

        // 회전
        transform.Rotate(0, 0, _rotationSpeed * Time.deltaTime);

        // 3. [핵심 수정] 종료점 도달 시 -> 속도 계산 후 전진 모드 전환
        if (t >= 1f)
        {
            _isContinuing = true;

            // 마지막 구간(정점 -> 끝점) 벡터
            Vector3 lastSegmentVector = _endPosition - _peakPosition;

            // 방향 설정
            _continueDirection = lastSegmentVector.normalized;

            // [속도 동기화]
            // "Lerp로 이동하던 속도" = "이동 거리" / "걸린 시간"
            // 이동 거리: 정점~끝점 거리
            // 걸린 시간: 전체 시간의 절반 (_travelDuration * 0.5f)
            float segmentDistance = lastSegmentVector.magnitude;
            float segmentDuration = _travelDuration * 0.5f;

            if (segmentDuration > 0)
            {
                // 여기서 계산된 속도를 대입하면, 
                // 궤적이 끝나는 순간 위화감 없이 똑같은 속도로 쭉 날아갑니다.
                _continueSpeed = segmentDistance / segmentDuration;
            }
        }
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

        // 바닥과 충돌하면 소멸
        if (collision.CompareTag("BackGround"))
        {
            ObjectPoolManager.Instance.Retrun(gameObject);
            return;
        }

        if (collision.CompareTag("Enemy"))
        {
            if (collision.gameObject.layer == LayerMask.NameToLayer("EnemyDefense"))
            {
                // 방어막에 맞으면 즉시 소멸
                ObjectPoolManager.Instance.Retrun(gameObject);
                return;
            }

            TryDamageEnemy(collision);
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (!_isCharged) return;

        if (collision.CompareTag("Enemy"))
        {
            TryDamageEnemy(collision);
        }
    }

    private void TryDamageEnemy(Collider2D enemyCollider)
    {
        // 마지막 데미지 시간 확인
        if (_lastDamageTime.TryGetValue(enemyCollider, out float lastTime))
        {
            if (Time.time - lastTime < _damageInterval)
            {
                return; // 아직 쿨다운 중
            }
        }

        if (enemyCollider.TryGetComponent<IDamageable>(out var damageable))
        {
            damageable.TakeDamage(Damage);

            //차지 상태가 아닌 탄환일때
            if (!_isCharged)
            {
                UI_DamageManager.Instance.SpawnDamageText(enemyCollider.gameObject, enemyCollider.transform.position, Damage.DamageAmount, EDamgeType.Normal);
                ObjectPoolManager.Instance.Retrun(gameObject);
                //todo 이펙트추가
                return;
            }
            //차지상태면 데미지 시간 갱신
            UI_DamageManager.Instance.SpawnDamageText(enemyCollider.gameObject, enemyCollider.transform.position, Damage.DamageAmount, EDamgeType.Accumulate);
            // 마지막 데미지 시간 갱신
            _lastDamageTime[enemyCollider] = Time.time;
        }
    }

    private void OnDisable()
    {
        _lastDamageTime.Clear();

        // DOTween 트윈 정리
        DOTween.Kill(this);
    }

    public override void OnProjectileDeactivate()
    {
        // 레이저는 관통형이므로 적에게 맞아도 계속 진행
        // 필요시 여기에 특수 효과 추가 가능
    }

    public override void Launch(DamageInfo damageInfo, Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity, bool isCharged)
    {
        _isCharged = isCharged;
        Damage = damageInfo;
        // 위치 세팅
        transform.position = spawnPosition;
        float adjustedDistance = throwForce * _rangeRatio;
        // 기존 ThrowLaser 내용
        SetForwardDistance(adjustedDistance); // throwForce를 기본 거리로 사용
        SetPowerScale(powerScale);
        SetAngle(angleDeg - 40f);
        SetLaserPath();                 // ∧ 궤적 계산 시작

        // 차지샷일 경우 추가로 ±5도 각도로 2개 더 발사
        if (isCharged)
        {
            // 위쪽으로 +5도
            LaunchAdditionalLaser(spawnPosition, powerScale, angleDeg + 5f, throwForce, gravity);

            // 아래쪽으로 -5도
            LaunchAdditionalLaser(spawnPosition, powerScale, angleDeg - 5f, throwForce, gravity);
        }
    }

    private void LaunchAdditionalLaser(Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity)
    {
        GameObject additionalLaser = ObjectPoolManager.Instance.GetProjectile(
            EProjectileType.Laser,
            spawnPosition,
            Quaternion.identity
        );

        if (additionalLaser != null)
        {
            Laser laserComponent = additionalLaser.GetComponent<Laser>();
            if (laserComponent != null)
            {
                // 추가 레이저는 차지샷이 아니므로 isCharged = false
                laserComponent.Launch(Damage, spawnPosition, powerScale, angleDeg, throwForce, gravity, false);
            }
        }
    }
}
