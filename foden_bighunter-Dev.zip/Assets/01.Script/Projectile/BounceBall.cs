using UnityEngine;
using System.Collections.Generic;
using DG.Tweening;
public class BounceBall : ProjectileBase
{
    [Header("바운스 설정")]
    [SerializeField] private float _groundLevel = 0f;           // 바닥 높이 (Y 좌표)
    [SerializeField] private float _bounceHeight = 5f;          // 기본 튀어오르는 높이
    [SerializeField] private float _bounceHeightDecay = 0.7f;   // 튀어오를 때마다 높이 감소 비율
    [SerializeField] private int _maxBounceCount = 3;           // 최대 바운스 횟수
    [SerializeField] private float _horizontalSpeed = 10f;      // 가로 이동 속도
    [SerializeField] private float _rotationSpeed = 360f;       // 회전 속도

    [Header("적 붙기 & 폭발 설정")]
    [SerializeField] private float _explosionDelay = 1.5f;      // 폭발까지 걸리는 시간
    [SerializeField] private float _explosionRadius = 2f;       // 폭발 범위
    [SerializeField] private float _penetrationDistance = 0.3f; // 충돌 후 추가로 이동할 거리

    // 내부 상태
    private Vector3 _startPosition;
    private float _currentBounceHeight;
    private int _bounceCount = 0;
    private float _elapsedTime = 0f;
    private float _powerScale = 1f;
    private float _direction = 1f; // 1 = 오른쪽, -1 = 왼쪽
    private bool _isInitialized = false;

    private bool _isDeactivated = false;
    private bool _isStuckToEnemy = false;                       // 적에 붙어있는지
    private Transform _stuckTarget;                             // 붙은 적
    private bool _isCharged = false;                            // 차지샷 여부
    private bool _hasSplit = false;                             // 이미 분리되었는지

    [Header("차지샷 분리 설정")]
    [SerializeField] private int _splitCount = 5;               // 분리되는 개수
    [SerializeField] private float _splitAngleRange = 40f;      // 분리 각도 범위
    [Header("페이드 아웃 설정")]
    [SerializeField] private float _fadeOutDuration = 0.5f;   // 사라지는 데 걸리는 시간

    // 현재 바운스 단계
    private enum BouncePhase
    {
        Falling,    // 떨어지는 중
        Rising      // 올라가는 중
    }
    private BouncePhase _currentPhase = BouncePhase.Falling;
    private float _phaseStartTime = 0f;
    private Vector3 _phaseStartPosition;
    private float _phaseDuration = 0.5f; // 한 단계(올라가거나 내려가는) 시간

    // 적 데미지 쿨다운 관리
    private Dictionary<Collider2D, float> _lastDamageTime = new Dictionary<Collider2D, float>();

    protected override void OnEnable()
    {
        base.OnEnable();

        if (Rigidbody2D != null)
        {
            Rigidbody2D.gravityScale = 0f;
            Rigidbody2D.velocity = Vector2.zero;
        }

        _isDeactivated = false;

        _elapsedTime = 0f;
        _bounceCount = 0;
        _isInitialized = false;
        _lastDamageTime.Clear();
        _currentPhase = BouncePhase.Falling;
    }

    protected override void ProjectileMove()
    {
        if (!_isInitialized) return;
        if (_isDeactivated) return;
        if (_isStuckToEnemy) return; // 적에 붙어있으면 이동 안 함

        _elapsedTime += Time.deltaTime;

        // 가로 이동
        float horizontalMove = _direction * _horizontalSpeed * _powerScale * Time.deltaTime;
        Vector3 newPosition = transform.position;
        newPosition.x += horizontalMove;

        // 세로 이동 (포물선)
        float phaseProgress = (_elapsedTime - _phaseStartTime) / _phaseDuration;

        if (_currentPhase == BouncePhase.Falling)
        {
            // 떨어지는 중: 시작 위치에서 바닥까지
            float startY = _phaseStartPosition.y;
            float targetY = _groundLevel;

            // 포물선 느낌으로 떨어지기 (EaseIn)
            float t = Mathf.Clamp01(phaseProgress);
            t = t * t; // EaseIn
            newPosition.y = Mathf.Lerp(startY, targetY, t);

            // 바닥에 도달하면 튀어오르기
            if (newPosition.y <= _groundLevel + 0.1f && phaseProgress >= 1f)
            {
                newPosition.y = _groundLevel;
                OnBounce(newPosition);
            }
        }
        else if (_currentPhase == BouncePhase.Rising)
        {
            // 올라가는 중: 바닥에서 목표 높이까지
            float startY = _groundLevel;
            float targetY = _groundLevel + _currentBounceHeight;

            // 포물선 느낌으로 올라가기 (EaseOut)
            float t = Mathf.Clamp01(phaseProgress);
            t = 1f - (1f - t) * (1f - t); // EaseOut
            newPosition.y = Mathf.Lerp(startY, targetY, t);

            // 최고점 도달하면 다시 떨어지기
            if (phaseProgress >= 1f)
            {
                // 차지샷이고 첫 바운스 후 최고점이고 아직 분리 안 했으면 분리
                if (_isCharged && _bounceCount == 1 && !_hasSplit)
                {
                    SpawnSplitBalls(newPosition);
                    _hasSplit = true;

                    // 원본 볼은 소멸
                    ObjectPoolManager.Instance.Retrun(gameObject);
                    return;
                }

                _currentPhase = BouncePhase.Falling;
                _phaseStartTime = _elapsedTime;
                _phaseStartPosition = newPosition;
            }
        }

        // 위치 업데이트
        if (Rigidbody2D != null)
        {
            Rigidbody2D.MovePosition(newPosition);
        }
        else
        {
            transform.position = newPosition;
        }

        // 회전
        transform.Rotate(0, 0, _rotationSpeed * Time.deltaTime);

        // 최대 바운스 횟수 초과 시 비활성화
        if (_bounceCount > _maxBounceCount)
        {
            ObjectPoolManager.Instance.Retrun(gameObject);
        }
    }

    private void OnBounce(Vector3 bouncePosition)
    {
        _bounceCount++;

        // 바운스 높이 감소
        _currentBounceHeight *= _bounceHeightDecay;

        // 다음 단계로 전환
        _currentPhase = BouncePhase.Rising;
        _phaseStartTime = _elapsedTime;
        _phaseStartPosition = bouncePosition;
    }

    // 분리된 볼들 생성
    private void SpawnSplitBalls(Vector3 spawnPosition)
    {
        float angleStep = _splitAngleRange / (_splitCount - 1);
        float startAngle = -_splitAngleRange / 2f;

        for (int i = 0; i < _splitCount; i++)
        {
            float angle = startAngle + (angleStep * i);

            // SplitBall 생성
            GameObject splitBall = ObjectPoolManager.Instance.GetProjectile(
                EProjectileType.SplitBall,
                spawnPosition,
                Quaternion.identity
            );

            if (splitBall != null && splitBall.TryGetComponent<SplitBall>(out var splitComponent))
            {
                // 각도를 방향 벡터로 변환 (왼쪽 아래 방향 기준)
                // -90도(아래) + 각도 오프셋 - 30도(왼쪽으로 기울임)
                float angleRad = (angle - 90f + 60f) * Mathf.Deg2Rad;
                Vector2 direction = new Vector2(Mathf.Cos(angleRad), Mathf.Sin(angleRad));

                DamageInfo splitDamageInfo = new DamageInfo(Damage.DamageAmount / 2);
                // SplitBall 초기화 (떨어지기만 하고 적 만나면 폭발)
                splitComponent.InitializeForBounceBall(direction, splitDamageInfo);
            }
        }
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

        if (_isStuckToEnemy) return; // 이미 붙어있으면 무시

        if (collision.CompareTag("Enemy"))
        {
            if (collision.gameObject.layer == LayerMask.NameToLayer("EnemyDefense"))
            {
                OnDefensed(collision.ClosestPoint(transform.position));
                return;
            }

            // 적에게 데미지 주고 붙기
            //TryDamageEnemy(collision);
            StickToEnemy(collision);
        }
    }

    private void OnDisable()
    {
        _lastDamageTime.Clear();
        _isStuckToEnemy = false;
        _stuckTarget = null;

        // DOTween 정리
        DOTween.Kill(this);
    }

    // 적에게 붙기
    private void StickToEnemy(Collider2D enemyCollider)
    {
        _isStuckToEnemy = true;
        _isDeactivated = true;

        // 콜라이더 비활성화
        if (Collider != null)
            Collider.enabled = false;

        // 현재 바라보는 방향으로 살짝 더 전진
        if (_penetrationDistance > 0f)
        {
            Vector3 forward = transform.right; // 바운스볼은 오른쪽으로 이동
            transform.position += forward * _penetrationDistance;
        }

        // 물리 비활성화
        Rigidbody2D.velocity = Vector2.zero;
        Rigidbody2D.angularVelocity = 0f;
        Rigidbody2D.isKinematic = true;
        Rigidbody2D.gravityScale = 0f;

        // Enemy에 자식으로 붙이기
        _stuckTarget = enemyCollider.transform;
        transform.SetParent(_stuckTarget);

        // 일정 시간 후 폭발
        DOVirtual.DelayedCall(_explosionDelay, () =>
        {
            Explode();
        });

        // 폭발 전 깜빡임 효과 
        if (SpriteRenderer != null)
        {
            SpriteRenderer.DOFade(0.3f, 0.2f).SetLoops(-1, LoopType.Yoyo);
        }
    }

    // 폭발
    private void Explode()
    {
        // 폭발 범위 내의 모든 적에게 데미지
        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, _explosionRadius);

        foreach (var hit in hits)
        {
            if (hit.CompareTag("Enemy"))
            {
                if (hit.TryGetComponent<IDamageable>(out var damageable))
                {
                    damageable.TakeDamage(Damage);


                    UI_DamageManager.Instance.SpawnDamageText(
                        hit.gameObject,
                        hit.transform.position,
                        Damage.DamageAmount,
                        EDamgeType.Normal
                    );
                }
            }
        }

        // 풀로 반환
        transform.SetParent(null);
        ObjectPoolManager.Instance.Retrun(gameObject);
    }
    private void OnDefensed(Vector2 hitPoint)
    {
        // 비활성화 플래그 설정 (기존 움직임 중단)
        _isDeactivated = true;

        Collider.isTrigger = false;
        Collider.excludeLayers |= LayerMask.GetMask("Enemy", "EnemyDefense");

        if (Rigidbody2D != null)
        {
            // 충돌 지점에서 부메랑으로의 방향 벡터 계산 (반사 방향)
            Vector2 reflectDirection = ((Vector2)transform.position - hitPoint).normalized;

            // 반사 힘 설정
            float reflectForce = 15f;

            Rigidbody2D.isKinematic = false;
            Rigidbody2D.gravityScale = 1f; // 중력 적용
            Rigidbody2D.velocity = Vector2.zero; // 기존 속도 초기화

            // 반사 방향으로 힘 가하기
            Rigidbody2D.AddForce(reflectDirection * reflectForce, ForceMode2D.Impulse);

            // 회전 속도 증가
            Rigidbody2D.angularVelocity = 720f;
        }
        DOVirtual.DelayedCall(5f, () =>
{
    // 페이드 아웃 연출
    SpriteRenderer.DOFade(0f, _fadeOutDuration)
        .OnComplete(() =>
        {
            // 몸통 스프라이트도 페이드 아웃
            if (SpriteRenderer != null)
            {
                Color bodyColor = SpriteRenderer.color;
                bodyColor.a = 1f;
                SpriteRenderer.color = bodyColor;
            }

            // 풀로 리턴
            ObjectPoolManager.Instance.Retrun(gameObject);
        });
});
    }
    public override void OnProjectileDeactivate()
    {

    }

    public override void Launch(DamageInfo damageInfo, Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity, bool isCharged)
    {
        Damage = damageInfo;
        // 위치 세팅
        transform.position = spawnPosition;
        _startPosition = spawnPosition;
        _powerScale = powerScale;
        _isCharged = isCharged;
        _hasSplit = false;

        // 방향 설정
        _direction = 1f; // 항상 오른쪽으로

        // 파워에 따라 높이 설정 (파워가 높을수록 높이 증가)
        _currentBounceHeight = _bounceHeight * powerScale;

        // 초기 단계 설정 (처음엔 떨어지는 중)
        _currentPhase = BouncePhase.Falling;
        _phaseStartTime = 0f;
        _phaseStartPosition = spawnPosition;
        _elapsedTime = 0f;

        _isInitialized = true;

        _maxBounceCount = 3;
        _bounceHeightDecay = 0.7f;
    }
}
