using UnityEngine;
using DG.Tweening;

public class SplitBall : ProjectileBase
{
    [Header("이동 설정")]
    [SerializeField] private float _initialSpeed = 10f;        // 초기 속도

    [Header("충돌 설정")]
    [SerializeField] private float _fadeOutDuration = 0.3f;    // 사라지는 시간

    private Vector2 _moveDirection;                            // 이동 방향
    private float _currentSpeed;                               // 현재 속도
    private bool _hasCollided = false;                         // 충돌 여부

    private float _explosionDelay = 1.5f;                      // 폭발 지연 시간
    private DamageInfo _damageInfo;                        // 폭발 데미지
    private float _explosionRadius = 2f;                       // 폭발 범위

    protected override void OnEnable()
    {
        base.OnEnable();

        _hasCollided = false;
        _currentSpeed = _initialSpeed;
        _moveDirection = Vector2.up; // 기본 방향

    }

    /// <summary>
    /// 바운스볼에서 생성될 때 초기화
    /// </summary>
    public void InitializeForBounceBall(Vector2 direction, DamageInfo damageInfo)
    {
        _damageInfo = damageInfo;
        _moveDirection = direction.normalized;
        _currentSpeed = _initialSpeed;

        // 중력 적용하여 떨어지도록
        if (Rigidbody2D != null)
        {
            Rigidbody2D.gravityScale = 2f;
            Rigidbody2D.velocity = direction * _currentSpeed;
        }

        // 이동 방향으로 회전
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0, 0, angle + rotationOffset);
    }

    protected override void ProjectileMove()
    {
        // if (_hasCollided) return;

        // // 현재 방향으로 이동
        // Vector2 velocity = _moveDirection * _currentSpeed;

        // // 중력 적용
        // if (_useGravity && Rigidbody2D.velocity.y < 0)
        // {
        //     velocity.y -= _fallGravity * Time.fixedDeltaTime;
        //     velocity.y = Mathf.Max(velocity.y, -_maxFallSpeed);
        // }

        // Rigidbody2D.velocity = velocity;

        // // 이동 방향으로 회전
        // if (velocity.sqrMagnitude > 0.0001f)
        // {
        //     float angle = Mathf.Atan2(velocity.y, velocity.x) * Mathf.Rad2Deg;
        //     Rigidbody2D.MoveRotation(Quaternion.Euler(0, 0, angle + rotationOffset));
        // }
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

        if (_hasCollided) return;

        // 적과 충돌
        if (collision.CompareTag("Enemy"))
        {
            _hasCollided = true;


            StickToEnemyAndExplode(collision);


        }
        // 배경과 충돌
        else if (collision.CompareTag("BackGround"))
        {
            _hasCollided = true;
            DeactivateProjectile();
        }
    }

    /// <summary>
    /// 적에 붙어서 폭발 (바운스볼 모드 전용)
    /// </summary>
    private void StickToEnemyAndExplode(Collider2D enemyCollider)
    {
        // 물리 정지
        Rigidbody2D.velocity = Vector2.zero;
        Rigidbody2D.angularVelocity = 0f;
        Rigidbody2D.isKinematic = true;
        Rigidbody2D.gravityScale = 0f;

        // 콜라이더 비활성화
        if (Collider != null)
            Collider.enabled = false;

        // Enemy에 자식으로 붙이기
        transform.SetParent(enemyCollider.transform);

        // 일정 시간 후 폭발
        DOVirtual.DelayedCall(_explosionDelay, () =>
        {
            ExplodeOnEnemy();
        });

        // 폭발 전 깜빡임 효과
        if (SpriteRenderer != null)
        {
            SpriteRenderer.DOFade(0.3f, 0.2f).SetLoops(-1, LoopType.Yoyo);
        }
    }

    /// <summary>
    /// 폭발 (바운스볼 모드 전용)
    /// </summary>
    private void ExplodeOnEnemy()
    {
        // 폭발 범위 내의 모든 적에게 데미지
        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, _explosionRadius);

        foreach (var hit in hits)
        {
            if (hit.CompareTag("Enemy"))
            {
                if (hit.TryGetComponent<IDamageable>(out var damageable))
                {
                    damageable.TakeDamage(_damageInfo);

                    UI_DamageManager.Instance.SpawnDamageText(
                        hit.gameObject,
                        transform.position,
                        _damageInfo.DamageAmount,
                        EDamgeType.Normal
                    );
                }
            }
        }

        // 풀로 반환
        transform.SetParent(null);
        ObjectPoolManager.Instance.Retrun(gameObject);
    }

    /// <summary>
    /// 발사체 비활성화
    /// </summary>
    private void DeactivateProjectile()
    {
        // 물리 정지
        Rigidbody2D.velocity = Vector2.zero;
        Rigidbody2D.isKinematic = true;

        // 콜라이더 비활성화
        if (Collider != null)
            Collider.enabled = false;

        // 페이드 아웃 후 풀로 반환
        SpriteRenderer.DOFade(0f, _fadeOutDuration)
            .OnComplete(() =>
            {
                ObjectPoolManager.Instance.Retrun(gameObject);
            });
    }

    public override void OnProjectileDeactivate()
    {
        // 적이 죽었을 때 호출되는 메서드
        // SplitBall은 적에 박히지 않고 즉시 분열하므로 특별한 처리 불필요
        DeactivateProjectile();
    }

    public override void Launch(DamageInfo damageInfo, Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity, bool isCharged)
    {
    }
}
