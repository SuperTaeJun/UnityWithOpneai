using UnityEngine;
using DG.Tweening;
public abstract class ProjectileBase : MonoBehaviour, IProjectileLauncher
{
    [field: Header("기본 설정")]
    [field: SerializeField] public DamageInfo Damage { get; protected set; }
    [field: Header("투사체 컴포넌트")]
    [field: SerializeField] public SpriteRenderer SpriteRenderer { get; private set; }
    [field: SerializeField] public Rigidbody2D Rigidbody2D { get; private set; }
    [field: SerializeField] public Collider2D Collider { get; private set; }
    [Header("회전 설정")]
    [SerializeField] protected float rotationOffset = -90f; // 스프라이트 기본 방향에 맞게 조정
    [Header("레이어 마스크 설정")]
    [SerializeField] protected LayerMask _initialColliderIncludeLayers;
    [SerializeField] protected LayerMask _initialColliderExcludeLayers;

    protected bool _stuck = false; // 이미 박혔는지 여부

    private void FixedUpdate()
    {
        if (_stuck) return;
        if (Rigidbody2D == null) return;

        ProjectileMove();
    }
    protected virtual void OnEnable()
    {
        _stuck = false;

        // 부모 관계 초기화 (이전에 Enemy 등에 붙어있었을 수 있음)
        //transform.SetParent(null);

        // 콜라이더 활성화
        if (Collider != null)
        {
            Collider.isTrigger = true;
            Collider.enabled = true;
            Collider.includeLayers = _initialColliderIncludeLayers;
            Collider.excludeLayers = _initialColliderExcludeLayers;
        }

        // DOTween 정리
        transform.DOKill();
        if (SpriteRenderer != null)
            SpriteRenderer.DOKill();

        // SpriteRenderer 알파값 초기화
        if (SpriteRenderer != null)
        {
            Color color = SpriteRenderer.color;
            color.a = 1f;
            SpriteRenderer.color = color;
        }

        // Rigidbody2D 초기화
        if (Rigidbody2D != null)
        {
            Rigidbody2D.isKinematic = false;
            Rigidbody2D.gravityScale = 1f;
            Rigidbody2D.velocity = Vector2.zero;
            Rigidbody2D.angularVelocity = 0f;
        }
    }


    protected abstract void ProjectileMove();

    protected virtual void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Prop")) return;
    }

    public abstract void OnProjectileDeactivate();

    public abstract void Launch(DamageInfo damageInfo, Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity, bool isCharged);
}
