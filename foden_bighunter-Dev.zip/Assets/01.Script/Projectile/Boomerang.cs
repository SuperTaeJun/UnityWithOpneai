using UnityEngine;
using DG.Tweening;
using System.Collections.Generic;

public class Boomerang : ProjectileBase
{
    [Header("부메랑 궤적 설정")]
    [SerializeField] private float _forwardDistance = 20f;      // 앞으로 나아갈 최대 거리 (파워스케일에 따라 배수 적용됨)
    [SerializeField] private float _curveHeight = 3f;          // U자 곡선의 높이 (위아래 편차)
    [SerializeField] private float _travelDuration = 2f;       // 전체 이동 시간
    [SerializeField] private float _slowDuration = 0.5f;       // 최대 거리 근처에서 천천히 움직이는 시간
    [SerializeField] private float _slowSpeedMultiplier = 0.2f; // 느린 구간의 속도 배수
    [SerializeField] private float _rotationSpeed = 720f;      // 회전 속도 (도/초)
    [Header("거리 조절 설정")]
    [Range(0.1f, 1.0f)]
    [SerializeField] private float _rangeRatio = 0.4f; // 들어오는 힘의 40%만 거리로 사용

    [Header("타격 설정")]
    [SerializeField] private float _hitStopDuration = 0.05f;   // 히트스톱 지속 시간
    [SerializeField] private float _hitStopSlowMultiplier = 0.1f; // 히트스톱 중 속도 배수 (0 = 완전 정지, 0.1 = 매우 느림)
    [SerializeField] private float _damageInterval = 0.3f;     // 같은 적에게 데미지를 주는 간격

    [Header("차지샷 설정")]
    [SerializeField] private float _chargedMaxScale = 2f;      // 차지샷 시 최대 크기 배율
    [Header("페이드 아웃 설정")]
    [SerializeField] private float _fadeOutDuration = 0.5f;   // 사라지는 데 걸리는 시간
    // 내부 상태
    private Vector3 _startPosition;                            // 시작 위치
    private float _elapsedTime;                                // 경과 시간
    private float _powerScale = 1f;
    private float _angleDeg = 45f;

    // 히트스톱 상태
    private bool _isHitStopped = false;
    private float _hitStopMultiplier = 1f;

    // 베지에 제어점
    private Vector3 _p0, _p1, _p2, _p3;
    private bool _isInitialized = false;

    // 적 데미지 쿨다운 관리
    private Dictionary<Collider2D, float> _lastDamageTime = new Dictionary<Collider2D, float>();

    // 타격 카운터
    private int _hitCount = 0;

    private bool _isDeactivated = false; // 비활성화 상태 플래그
    private bool _isCharged = false;     // 차지샷 여부
    private Vector3 _initialScale;       // 초기 스케일

    protected override void OnEnable()
    {
        base.OnEnable();

        if (Rigidbody2D != null)
        {
            Rigidbody2D.gravityScale = 0f;
            Rigidbody2D.velocity = Vector2.zero;
        }

        _elapsedTime = 0f;
        _lastDamageTime.Clear();
        _isInitialized = false;
        _hitCount = 0; // 타격 카운터 초기화
        _isDeactivated = false; // 비활성화 상태 초기화

        // 초기 스케일 저장 및 리셋
        transform.localScale = _initialScale;
    }

    private void Awake()
    {
        _initialScale = transform.localScale;
    }

    public void SetPowerScale(float scale) => _powerScale = Mathf.Max(0.1f, scale);
    public void SetAngle(float angle) => _angleDeg = angle;
    public void SetForwardDistance(float distance) => _forwardDistance = distance;
    public void SetPlayerTransform()
    {
        _startPosition = transform.position;
        _elapsedTime = 0f;
        _lastDamageTime.Clear();
        _isInitialized = false;

        CalculateBezierPoints();
    }

    private void CalculateBezierPoints()
    {
        // 방향 벡터 계산
        float rad = _angleDeg * Mathf.Deg2Rad;
        Vector3 forwardDir = new Vector3(Mathf.Cos(rad), Mathf.Sin(rad), 0).normalized;

        // 수직 벡터 계산
        Vector3 perpDir = new Vector3(-forwardDir.y, forwardDir.x, 0);
        if (forwardDir.x < 0) perpDir *= -1;

        // 거리 및 폭 계산
        float dist = _forwardDistance * _powerScale;
        float width = _curveHeight * _powerScale;

        // 베지에 제어점 설정
        _p0 = _startPosition;
        _p3 = _startPosition;

        // 각도에 따라 궤적 방향 결정
        if (_angleDeg <= 20f)
        {
            // 아래쪽에서 시작해서 위로 돌아오는 궤적
            _p1 = _startPosition + (forwardDir * dist) - (perpDir * width);
            _p2 = _startPosition + (forwardDir * dist) + (perpDir * width);
        }
        else
        {
            // 위쪽에서 시작해서 아래로 돌아오는 궤적
            _p1 = _startPosition + (forwardDir * dist) + (perpDir * width);
            _p2 = _startPosition + (forwardDir * dist) - (perpDir * width);
        }

        _isInitialized = true;
    }


    protected override void ProjectileMove()
    {
        if (!_isInitialized || _isDeactivated) return; // 비활성화 상태면 기존 움직임 중단

        // 속도 조절: 최대 거리 근처에서만 느려짐
        float speedMultiplier = 1f * _hitStopMultiplier; // 히트스톱 배수 적용

        float normalizedTime = _elapsedTime / (_travelDuration + _slowDuration);

        // 0.4 ~ 0.6 구간에서만 속도 감소 - 공기저항
        if (normalizedTime >= 0.4f && normalizedTime <= 0.6f)
        {
            float localProgress = (normalizedTime - 0.4f) / 0.2f; // 0~1

            if (localProgress < 0.5f)
            {
                // 0.4 ~ 0.5: 1.0 → _slowSpeedMultiplier
                float slowProgress = localProgress / 0.5f; // 0~1
                speedMultiplier = Mathf.Lerp(1f, _slowSpeedMultiplier, slowProgress);
            }
            else
            {
                // 0.5 ~ 0.6: _slowSpeedMultiplier → 1.0
                float fastProgress = (localProgress - 0.5f) / 0.5f; // 0~1
                speedMultiplier = Mathf.Lerp(_slowSpeedMultiplier, 1f, fastProgress);
            }
        }

        _elapsedTime += Time.deltaTime * speedMultiplier;

        // Bezier 곡선을 따라 이동
        float t = Mathf.Clamp01(_elapsedTime / (_travelDuration + _slowDuration));
        Vector3 newPosition = GetCubicBezierPoint(t, _p0, _p1, _p2, _p3);

        if (Rigidbody2D != null)
        {
            Rigidbody2D.MovePosition(newPosition);
        }
        else
        {
            transform.position = newPosition;
        }

        // 회전
        transform.Rotate(0, 0, _rotationSpeed * Time.deltaTime);

        // 차지샷일 경우 크기 증가
        if (_isCharged)
        {
            // 시간에 따라 1.0 -> _chargedMaxScale로 점점 커짐
            float currentScale = Mathf.Lerp(1f, _chargedMaxScale, t);
            transform.localScale = _initialScale * currentScale;
        }

        // 시간 초과 시 비활성화
        if (t >= 1f)
        {
            ObjectPoolManager.Instance.Retrun(gameObject);
        }
    }

    /// 3차 베지에 곡선 공식
    private Vector3 GetCubicBezierPoint(float t, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3)
    {
        float u = 1 - t;
        float tt = t * t;
        float uu = u * u;
        float uuu = uu * u;
        float ttt = tt * t;

        Vector3 p = uuu * p0;
        p += 3 * uu * t * p1;
        p += 3 * u * tt * p2;
        p += ttt * p3;

        return p;
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy"))
        {
            if (collision.gameObject.layer == LayerMask.NameToLayer("EnemyDefense"))
            {
                OnDefensed(collision.ClosestPoint(transform.position));
                return;
            }

            TryDamageEnemy(collision);
            _hitCount++;
            if (_hitCount >= 2)
            {
                OnProjectileDeactivate();
            }
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy"))
        {
            TryDamageEnemy(collision);

        }
    }

    private void TryDamageEnemy(Collider2D enemyCollider)
    {
        // 마지막 데미지 시간 확인
        if (_lastDamageTime.TryGetValue(enemyCollider, out float lastTime))
        {
            if (Time.time - lastTime < _damageInterval)
            {
                return; // 아직 쿨다운 중
            }
        }


        if (enemyCollider.TryGetComponent<IDamageable>(out var damageable))
        {
            damageable.TakeDamage(Damage);

            UI_DamageManager.Instance.SpawnDamageText(enemyCollider.gameObject, enemyCollider.transform.position, Damage.DamageAmount, EDamgeType.Accumulate);

            // 히트스톱 효과 적용
            ApplyHitStop();
        }
        // 마지막 데미지 시간 갱신
        _lastDamageTime[enemyCollider] = Time.time;
    }


    /// <summary>
    /// 히트스톱 효과를 적용합니다.
    /// </summary>
    private void ApplyHitStop()
    {
        if (_isHitStopped) return; // 이미 히트스톱 중이면 무시

        _isHitStopped = true;
        _hitStopMultiplier = _hitStopSlowMultiplier;

        // DOTween을 사용하여 일정 시간 후 원래 속도로 복귀
        DOVirtual.DelayedCall(_hitStopDuration, () => { _isHitStopped = false; _hitStopMultiplier = 1f; }).SetUpdate(true); // Time.timeScale에 영향받지 않도록 설정
    }

    private void OnDisable()
    {
        _lastDamageTime.Clear();

        // 비활성화 시 히트스톱 상태 초기화
        _isHitStopped = false;
        _hitStopMultiplier = 1f;

        // DOTween 트윈 정리
        DOTween.Kill(this);
    }

    private void OnDefensed(Vector2 hitPoint)
    {
        // 비활성화 플래그 설정 (기존 움직임 중단)
        _isDeactivated = true;

        Collider.isTrigger = false;
        Collider.excludeLayers |= LayerMask.GetMask("Enemy", "EnemyDefense");

        if (Rigidbody2D != null)
        {
            // 충돌 지점에서 부메랑으로의 방향 벡터 계산 (반사 방향)
            Vector2 reflectDirection = ((Vector2)transform.position - hitPoint).normalized;

            // 반사 힘 설정
            float reflectForce = 15f;

            Rigidbody2D.gravityScale = 1f; // 중력 적용
            Rigidbody2D.velocity = Vector2.zero; // 기존 속도 초기화

            // 반사 방향으로 힘 가하기
            Rigidbody2D.AddForce(reflectDirection * reflectForce, ForceMode2D.Impulse);

            // 회전 속도 증가
            Rigidbody2D.angularVelocity = 720f;
        }
        DOVirtual.DelayedCall(5f, () =>
{
    // 페이드 아웃 연출
    SpriteRenderer.DOFade(0f, _fadeOutDuration)
        .OnComplete(() =>
        {
            // 몸통 스프라이트도 페이드 아웃
            if (SpriteRenderer != null)
            {
                Color bodyColor = SpriteRenderer.color;
                bodyColor.a = 1f;
                SpriteRenderer.color = bodyColor;
            }

            // 풀로 리턴
            ObjectPoolManager.Instance.Retrun(gameObject);
        });
});
    }
    public override void OnProjectileDeactivate()
    {
        // 비활성화 플래그 설정 (기존 움직임 중단)
        _isDeactivated = true;

        Collider.isTrigger = false;
        Collider.excludeLayers |= LayerMask.GetMask("Enemy", "EnemyDefense");

        // 아래로 힘을 가하는 효과
        if (Rigidbody2D != null)
        {
            float downwardForce = 10f;
            Rigidbody2D.gravityScale = 1f; // 중력 적용
            Rigidbody2D.velocity = Vector2.zero; // 기존 속도 초기화
            Rigidbody2D.AddForce(Vector2.right * downwardForce, ForceMode2D.Impulse);

            // 회전 속도 증가
            Rigidbody2D.angularVelocity = 720f;
        }
        // 5초 후 페이드 아웃 후 풀로 리턴
        DOVirtual.DelayedCall(5f, () =>
        {
            // 페이드 아웃 연출
            SpriteRenderer.DOFade(0f, _fadeOutDuration)
                .OnComplete(() =>
                {
                    // 몸통 스프라이트도 페이드 아웃
                    if (SpriteRenderer != null)
                    {
                        Color bodyColor = SpriteRenderer.color;
                        bodyColor.a = 1f;
                        SpriteRenderer.color = bodyColor;
                    }

                    // 풀로 리턴
                    ObjectPoolManager.Instance.Retrun(gameObject);
                });
        });
    }

    public override void Launch(DamageInfo damageInfo, Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity, bool isCharged)
    {
        Damage = damageInfo;
        // 차지샷 여부 저장
        _isCharged = isCharged;

        float adjustedDistance = throwForce * _rangeRatio;
        // 기존 ThrowBoomerang 에서 하던 세팅
        SetForwardDistance(adjustedDistance);   // 기본 거리는 throwForce
        SetPowerScale(powerScale);
        SetAngle(angleDeg);
        SetPlayerTransform();             // 내부에서 베지에 궤적 계산
    }
}
