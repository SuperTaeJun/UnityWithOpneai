using UnityEngine;

public interface IProjectileLauncher
{
    // 발사체를 초기 위치/파워/각도/힘/중력에 맞게 발사 설정
    void Launch(DamageInfo damageInfo,Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity,bool isCharged);
}
