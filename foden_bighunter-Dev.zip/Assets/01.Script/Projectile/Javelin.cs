using UnityEngine;
using DG.Tweening;

public class Javelin : ProjectileBase
{
    [Header("몸통 콜라이더")]
    [SerializeField] private SpriteRenderer _bodySpriteRenderer; // 몸통 스프라이트 렌더러
    [SerializeField] private Collider2D _bodyCollider;    // 몸통 콜라이더

    [Header("박히는 연출 설정")]
    [SerializeField] private float _penetrationDistance = 0.3f; // 충돌 후 추가로 이동할 거리

    [Header("박히고 난 후 첫 펀치 흔들림 설정")]
    [SerializeField] private float _punchAngle = 15f;         // 흔들릴 각도
    [SerializeField] private float _punchDuration = 0.6f;     // 지속 시간
    [SerializeField] private int _punchVibrato = 12;          // 떨림 횟수
    [SerializeField, Range(0f, 1f)] private float _punchElasticity = 0.5f; // 탄성

    [Header("계속 박혀있을 때 스프링 설정 (Enemy 전용)")]
    [SerializeField] private float _maxTiltAngle = 10f;       // 최대 기울어지는 각도
    [SerializeField] private float _velocityToAngle = 3f;     // 속도 -> 각도 변환 계수
    [SerializeField] private float _springStiffness = 40f;    // 스프링 강도 (커질수록 딱딱)
    [SerializeField] private float _springDamping = 8f;       // 감쇠 계수 (커질수록 빨리 식음)

    [Header("사라지는 연출 설정 (배경 등에 박혔을 때)")]
    [SerializeField] private float _fadeOutDuration = 0.5f;   // 사라지는 데 걸리는 시간

    [Header("떨어지는 연출 설정 (Enemy에서 떨어질 때)")]
    [SerializeField] private float _dropForce = 15f;          // 떨어질 때 가해지는 힘
    [SerializeField] private float _dropTorque = 360f;        // 회전 토크

    [Header("스택 다 차면 나오는 연출 세팅")]
    [SerializeField] private float MultiShotAngle = 3f;

    // ----- 내부 상태 -----
    private Transform _stuckTarget;          // 박힌 Enemy
    private Vector3 _localRestPos;           // Enemy 기준 기본 local position
    private Quaternion _localRestRot;        // Enemy 기준 기본 local rotation

    private Vector3 _prevTargetPos;          // Enemy 이전 위치
    private Vector3 _smoothedTargetVelocity; // 부드럽게 만든 Enemy 속도

    // 스프링 시뮬레이션용
    private float _springAngle;              // 현재 스프링 각도
    private float _springAngularVel;         // 현재 스프링 각속도

    // 개별 창마다 다른 움직임을 위한 랜덤 값
    private float _randomAngleScale;         // 각도 스케일
    private float _noisePhase;               // 노이즈 위상

    private bool _useStuckJiggle;            // Enemy에 박힌 뒤 jiggle 활성화 여부

    // [SerializeField] private LayerMask _initialColliderIncludeLayers;
    // [SerializeField] private LayerMask _initialColliderExcludeLayers;


    protected override void OnEnable()
    {
        base.OnEnable();

        // Javelin 전용 초기화
        _useStuckJiggle = false;
        _stuckTarget = null;

        // 몸통 콜라이더 설정을 초기 상태로 복원
        if (_bodyCollider != null)
        {
            _bodyCollider.isTrigger = false;
            _bodyCollider.includeLayers = _initialColliderIncludeLayers;
            _bodyCollider.excludeLayers = _initialColliderExcludeLayers;
        }

        // 몸통 스프라이트 알파값 초기화
        if (_bodySpriteRenderer != null)
        {
            Color bodyColor = _bodySpriteRenderer.color;
            bodyColor.a = 1f;
            _bodySpriteRenderer.color = bodyColor;

            // DOTween 정리
            _bodySpriteRenderer.DOKill();
        }
        _bodySpriteRenderer.sortingLayerID = SortingLayer.NameToID("Projectile2");
        SpriteRenderer.sortingLayerID = SortingLayer.NameToID("Projectile2");
    }

    protected override void ProjectileMove()
    {
        if (_stuck) return;

        Vector2 v = Rigidbody2D.velocity;

        // 속도가 있을 때만 회전 갱신 (궤적 따라 머리 돌리기)
        if (v.sqrMagnitude > 0.5f) // 너무 느릴 땐 회전 안 함 (떨림 방지)
        {
            float angle = Mathf.Atan2(v.y, v.x) * Mathf.Rad2Deg;
            // rotationOffset이 선언되어 있지 않다면, 보통 창 그림에 따라 -90f 등을 더해야 함
            Quaternion targetRot = Quaternion.Euler(0, 0, angle - 90f); // 예시: -90도 보정

            // 바로 대입보다 Lerp를 쓰면 더 부드럽게 돕니다
            transform.rotation = Quaternion.Lerp(transform.rotation, targetRot, Time.deltaTime * 20f);
        }
    }
    // protected override void ProjectileMove()
    // {
    //     if (_stuck) return; // 이미 박혔으면 이동 안 함

    //     Vector2 v = Rigidbody2D.velocity;

    //     // 떨어지는 중일 때 (y 속도가 음수) 중력 가속도 적용
    //     if (v.y < 0)
    //     {
    //         v.y -= _fallGravity * Time.fixedDeltaTime;

    //         // 최대 낙하 속도 제한
    //         if (v.y < -_maxFallSpeed)
    //         {
    //             v.y = -_maxFallSpeed;
    //         }

    //         Rigidbody2D.velocity = v;
    //     }

    //     // 속도가 어느 정도 있을 때만 회전 갱신
    //     if (v.sqrMagnitude > 0.0001f)
    //     {
    //         float angle = Mathf.Atan2(v.y, v.x) * Mathf.Rad2Deg;

    //         // 회전 적용
    //         Quaternion targetRot = Quaternion.Euler(0, 0, angle + rotationOffset);
    //         Rigidbody2D.MoveRotation(targetRot);
    //     }
    // }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

        if (_stuck) return;

        if (!collision.CompareTag("Enemy") && !collision.CompareTag("BackGround"))
        {
            return;
        }

        bool isEnemy = collision.CompareTag("Enemy");

        _stuck = true;

        // 콜라이더 비활성화 
        if (Collider != null)
            Collider.enabled = false;

        // 현재 바라보는 방향으로 살짝 더 전진
        if (_penetrationDistance > 0f)
        {
            //화살이 위쪽으로 처음에 있음
            Vector3 forward = transform.up;
            transform.position += forward * _penetrationDistance;
        }

        // 물리 비활성화
        Rigidbody2D.velocity = Vector2.zero;
        Rigidbody2D.angularVelocity = 0f;
        Rigidbody2D.isKinematic = true;
        Rigidbody2D.gravityScale = 0f;

        if (isEnemy)
        {

            if (collision.gameObject.layer == LayerMask.NameToLayer("EnemyDefense"))
            {
                OnDefensed(collision.ClosestPoint(transform.position));
                return;
            }


            if (collision.TryGetComponent<IDamageable>(out var damageable))
            {
                damageable.TakeDamage(Damage);
            }

            UI_DamageManager.Instance.SpawnDamageText(collision.gameObject, transform.position, Damage.DamageAmount, EDamgeType.Normal);

            // Enemy에 자식으로 붙이기
            _stuckTarget = collision.transform;
            transform.SetParent(_stuckTarget);

            _localRestPos = transform.localPosition;
            _localRestRot = transform.localRotation;

            _prevTargetPos = _stuckTarget.position;
            _smoothedTargetVelocity = Vector3.zero;

            // 스프링 초기화 + 개별 랜덤 값 설정
            _springAngle = 0f;
            _springAngularVel = 0f;
            _randomAngleScale = Random.Range(0.5f, 1.5f);  // 창마다 반응 다르게
            _noisePhase = Random.Range(0f, Mathf.PI * 2f); // 노이즈 위상
        }

        // 첫 박힘 펀치 회전 연출
        transform.DOPunchRotation(
            new Vector3(0, 0, _punchAngle),
            _punchDuration,
            _punchVibrato,
            _punchElasticity
        )
        .OnComplete(() =>
        {
            if (isEnemy)
            {
                // Enemy에 박힌 경우: 계속 jiggle 모드 활성화
                _useStuckJiggle = true;
            }
            else
            {
                // 배경 등에 박힌 경우
                SpriteRenderer.DOFade(0f, _fadeOutDuration)
                    .OnComplete(() =>
                    {
                        ObjectPoolManager.Instance.Retrun(gameObject);
                    });
            }
        });
    }

    private void LateUpdate()
    {
        // Enemy에 박혀 있고, jiggle 활성화일 때만
        if (_useStuckJiggle == false || _stuckTarget == null)
            return;

        // 부모가 없으면 jiggle 비활성화
        if (transform.parent == null)
        {
            _useStuckJiggle = false;
            _stuckTarget = null;
            return;
        }

        // Enemy 이동 속도 계산
        Vector3 currentPos = _stuckTarget.position;
        float dt = Mathf.Max(Time.deltaTime, 0.0001f);
        Vector3 vel = (currentPos - _prevTargetPos) / dt;
        _prevTargetPos = currentPos;

        // 부모 기준 로컬 속도로 변환
        Vector3 localVel = transform.parent.InverseTransformDirection(vel);

        // 기본 목표 각도: 위/아래 움직임에 따라 약간 뒤로 젖혀지는 느낌
        float baseTilt = -localVel.y * _velocityToAngle;
        baseTilt = Mathf.Clamp(baseTilt, -_maxTiltAngle, _maxTiltAngle);

        // 개별 랜덤 스케일 적용
        float targetAngle = baseTilt * _randomAngleScale;

        // 가만히 있어도 살짝 살아있는 노이즈
        float smallNoise = Mathf.Sin(Time.time * 4f + _noisePhase) * 1.5f; // 약 1.5도
        targetAngle += smallNoise;

        //스프링 시뮬레이션
        float force = (targetAngle - _springAngle) * _springStiffness;
        _springAngularVel += force * dt;
        _springAngularVel -= _springAngularVel * _springDamping * dt; // 감쇠
        _springAngle += _springAngularVel * dt;

        // 최종 각도 적용
        Quaternion finalRot = _localRestRot * Quaternion.Euler(0, 0, _springAngle);
        transform.localRotation = finalRot;

    }

    private void OnDefensed(Vector2 hitPoint)
    {
        transform.SetParent(null);
        _bodySpriteRenderer.sortingLayerID = SortingLayer.NameToID("Projectile");
        SpriteRenderer.sortingLayerID = SortingLayer.NameToID("Projectile");
        Rigidbody2D.isKinematic = false;
        Rigidbody2D.gravityScale = 3f;

        // 창의 진행 방향 (transform.up)을 반대로 반사
        Vector2 incomingDirection = -transform.up; // 창의 진행 방향의 반대
        Vector2 normal = ((Vector2)transform.position - hitPoint).normalized; // 충돌 지점에서의 법선 벡터

        // 반사 공식: reflect = incoming - 2 * (incoming · normal) * normal
        Vector2 reflectDirection = Vector2.Reflect(incomingDirection, normal);

        // 반사 힘 설정
        float reflectForce = 15f;
        Rigidbody2D.velocity = Vector2.zero; // 기존 속도 초기화
        Rigidbody2D.AddForce(reflectDirection * reflectForce, ForceMode2D.Impulse);
        Rigidbody2D.angularVelocity = 720f;

        Collider.enabled = true;
        Collider.isTrigger = false;
        Collider.excludeLayers |= LayerMask.GetMask("Enemy", "EnemyDefense");

        //바닥 레이어 추가
        _bodyCollider.includeLayers |= LayerMask.GetMask("BackGround");
        _bodyCollider.excludeLayers |= LayerMask.GetMask("Enemy", "EnemyDefense");

        // 5초 후 페이드 아웃 후 풀로 리턴
        DOVirtual.DelayedCall(5f, () =>
        {
            // 페이드 아웃 연출
            SpriteRenderer.DOFade(0f, _fadeOutDuration)
                .OnComplete(() =>
                {
                    // 몸통 스프라이트도 페이드 아웃
                    if (_bodySpriteRenderer != null)
                    {
                        Color bodyColor = _bodySpriteRenderer.color;
                        bodyColor.a = 1f;
                        _bodySpriteRenderer.color = bodyColor;
                    }

                    // 풀로 리턴
                    ObjectPoolManager.Instance.Retrun(gameObject);
                });

            // 몸통 스프라이트도 함께 페이드 아웃
            if (_bodySpriteRenderer != null)
            {
                _bodySpriteRenderer.DOFade(0f, _fadeOutDuration);
            }
        });
    }


    public override void OnProjectileDeactivate()
    {
        transform.SetParent(null);
        _bodySpriteRenderer.sortingLayerID = SortingLayer.NameToID("Projectile");
        SpriteRenderer.sortingLayerID = SortingLayer.NameToID("Projectile");
        Rigidbody2D.isKinematic = false;
        Rigidbody2D.gravityScale = 3f;


        // 더 강한 힘으로 날아가는 연출
        Rigidbody2D.AddForce(Vector2.up * _dropForce, ForceMode2D.Impulse);
        Rigidbody2D.AddTorque(Random.Range(-_dropTorque, _dropTorque));

        Collider.enabled = true;
        Collider.isTrigger = false;
        Collider.excludeLayers |= LayerMask.GetMask("Enemy", "EnemyDefense");

        //바닥 레이어 추가
        _bodyCollider.includeLayers |= LayerMask.GetMask("BackGround");
        _bodyCollider.excludeLayers |= LayerMask.GetMask("Enemy", "EnemyDefense");

        // 5초 후 페이드 아웃 후 풀로 리턴
        DOVirtual.DelayedCall(5f, () =>
        {
            // 페이드 아웃 연출
            SpriteRenderer.DOFade(0f, _fadeOutDuration)
                .OnComplete(() =>
                {
                    // 몸통 스프라이트도 페이드 아웃
                    if (_bodySpriteRenderer != null)
                    {
                        Color bodyColor = _bodySpriteRenderer.color;
                        bodyColor.a = 1f;
                        _bodySpriteRenderer.color = bodyColor;
                    }

                    // 풀로 리턴
                    ObjectPoolManager.Instance.Retrun(gameObject);
                });

            // 몸통 스프라이트도 함께 페이드 아웃
            if (_bodySpriteRenderer != null)
            {
                _bodySpriteRenderer.DOFade(0f, _fadeOutDuration);
            }
        });
    }

    public override void Launch(DamageInfo damageInfo, Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity, bool isCharged)
    {
        Damage = damageInfo;
        // 위치 세팅
        transform.position = spawnPosition;

        // 각도 → 라디안
        float angleInRadians = angleDeg * Mathf.Deg2Rad;
        float dir = 1f; // 나중에 캐릭터 방향(좌우)에 따라 -1로 바꾸고 싶으면 여기만 수정

        // 기존 ThrowJavelin과 동일한 속도 계산
        Vector2 throwVelocity = new Vector2(
            dir * throwForce * powerScale * Mathf.Cos(angleInRadians),
            throwForce * powerScale * Mathf.Sin(angleInRadians)
        );

        if (Rigidbody2D != null)
        {
            // 중력 비율 설정 (Trajectory에서 쓰던 gravity 값 그대로 반영)
            Rigidbody2D.gravityScale = gravity / 9.81f;
            Rigidbody2D.velocity = throwVelocity;
        }

        // 차지샷일 경우 추가로 ±5도 각도로 2개 더 발사
        if (isCharged)
        {
            // 위쪽으로 +5도
            LaunchAdditionalJavelin(spawnPosition, powerScale, angleDeg + MultiShotAngle, throwForce, gravity);

            // 아래쪽으로 -5도
            LaunchAdditionalJavelin(spawnPosition, powerScale, angleDeg - MultiShotAngle, throwForce, gravity);
        }
    }

    private void LaunchAdditionalJavelin(Vector3 spawnPosition, float powerScale, float angleDeg, float throwForce, float gravity)
    {
        GameObject additionalJavelin = ObjectPoolManager.Instance.GetProjectile(
            EProjectileType.Javelin,
            spawnPosition,
            Quaternion.identity
        );

        if (additionalJavelin != null)
        {
            Javelin javelinComponent = additionalJavelin.GetComponent<Javelin>();
            if (javelinComponent != null)
            {
                // 추가 창은 차지샷이 아니므로 isCharged = false
                javelinComponent.Launch(Damage, spawnPosition, powerScale, angleDeg, throwForce, gravity, false);
            }
        }
    }
}
