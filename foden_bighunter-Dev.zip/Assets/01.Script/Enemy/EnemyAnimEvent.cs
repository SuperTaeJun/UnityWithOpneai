using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// Enemy의 애니메이션 이벤트를 처리하는 클래스
public class EnemyAnimEvent : MonoBehaviour
{
    private Enemy _enemy;

    private void Awake()
    {
        _enemy = GetComponentInParent<Enemy>();
    }

    public void AnimFinishTrigger()
    {
        _enemy.AnimFinishTrigger();
    }

}
