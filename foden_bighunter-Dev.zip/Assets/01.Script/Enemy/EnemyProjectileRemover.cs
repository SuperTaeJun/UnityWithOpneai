using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProjectileRemover : MonoBehaviour
{
    [Header("제거 설정")]
    [SerializeField] private int minRemoveCount = 1;  // 최소 제거 개수
    [SerializeField] private int maxRemoveCount = 3;  // 최대 제거 개수
    [SerializeField] private float dropDelay = 0.1f;  // 각 투사체가 떨어지는 시간 간격

    /// 랜덤으로 몇 개의 투사체를 제거하고 떨어뜨림
    public void RemoveRandomProjectiles()
    {
        StartCoroutine(RemoveProjectilesWithDelay());
    }

    // 시간차를 두고 투사체를 제거하는 코루틴
    private IEnumerator RemoveProjectilesWithDelay()
    {
        // 자식 오브젝트 개수 확인
        int childCount = transform.childCount;
        if (childCount == 0)
        {
            yield break;
        }

        // 제거할 개수 결정
        int removeCount = Random.Range(minRemoveCount, Mathf.Min(maxRemoveCount + 1, childCount + 1));
        removeCount = Mathf.Min(removeCount, childCount);

        // 랜덤 인덱스 선택 (HashSet으로 중복 방지)
        HashSet<int> selectedIndices = new HashSet<int>();
        while (selectedIndices.Count < removeCount)
        {
            selectedIndices.Add(Random.Range(0, childCount));
        }

        // 선택된 자식들을 먼저 리스트에 저장 (인덱스 변경 문제 방지)
        List<ProjectileBase> projectilesToDrop = new List<ProjectileBase>();
        foreach (int index in selectedIndices)
        {
            Transform child = transform.GetChild(index);
            ProjectileBase projectile = child.GetComponent<ProjectileBase>();
            
            if (projectile != null)
            {
                projectilesToDrop.Add(projectile);
            }
        }

        // 저장된 투사체들을 시간차를 두고 떨어뜨림
        foreach (ProjectileBase projectile in projectilesToDrop)
        {
            DropProjectile(projectile);
            yield return new WaitForSeconds(dropDelay);
        }
    }

    // 투사체를 Enemy로부터 분리하고 물리 효과를 적용하여 떨어뜨림
    private void DropProjectile(ProjectileBase projectile)
    {
        projectile.OnProjectileDeactivate();
    }

    // 현재 박혀있는 투사체 개수 반환
    public int GetStuckProjectileCount()
    {
        return transform.childCount;
    }
}
