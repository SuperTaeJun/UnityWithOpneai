public class EnemyStateMachine
{
    public bool IsInited = false;
    private EnemyState _currentState;
    public EnemyState currentState => _currentState;
    private Enemy _enemy;

    public void InitStateMachine(EnemyState currentState, Enemy enemy)
    {
        _currentState = currentState;
        _enemy = enemy;
        IsInited = true;
        _currentState.Enter();
    }
    
    public void ChangeState(EEnemyState state)
    {
        _currentState.Exit();
        _currentState = _enemy.States[state];
        _currentState.Enter();
    }

    public void Update()
    {
        _currentState.Update();
    }
}

public enum EEnemyState
{
    Idle,
    Move,
    Attack,
    DashAttack,
    Defense,
    Recovery,
    Dead
}
