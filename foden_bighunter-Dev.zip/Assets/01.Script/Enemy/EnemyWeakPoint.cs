using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyWeakPoint : MonoBehaviour
{
    private Enemy _owenr;

    private void Start()
    {
        _owenr = GetComponentInParent<Enemy>();
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("HitWeak");

        if (_owenr == null) return;
        _owenr.OnHitWeakPoint();

        Destroy(gameObject);
    }
}
