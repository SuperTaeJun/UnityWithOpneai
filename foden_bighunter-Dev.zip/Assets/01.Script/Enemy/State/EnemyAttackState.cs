using UnityEngine;
using DG.Tweening;

public class EnemyAttackState : EnemyState
{
    private Sequence _attackSequence;

    public EnemyAttackState(EnemyStateMachine stateMachine, Rigidbody2D rigidbody2D, Enemy enemy, string animBoolName) : base(stateMachine, rigidbody2D, enemy, animBoolName)
    {
    }
    public override void Update()
    {
        base.Update();

    }
    public override void Enter()
    {
        base.Enter();

        Debug.Log("EnemyAttackState Enter");
        
    }
    public override void Exit()
    {
        base.Exit();
    }

}
