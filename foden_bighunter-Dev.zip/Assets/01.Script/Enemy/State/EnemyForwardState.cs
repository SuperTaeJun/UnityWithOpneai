using UnityEngine;
using DG.Tweening;

public class EnemyForwardState : EnemyState
{
    private Tween _moveTween;


    public EnemyForwardState(EnemyStateMachine stateMachine, Rigidbody2D rigidbody2D, Enemy enemy, string animBoolName) : base(stateMachine, rigidbody2D, enemy, animBoolName)
    {
    }

    public override void Update()
    {
        base.Update();

        // 플레이어와의 거리 체크
        if (_owner.Target != null)
        {
            float distanceToPlayer = Vector2.Distance(_owner.transform.position, _owner.Target.position);

            // 공격 범위 체크 및 쿨타임 확인
            // 우선순위: 대시 공격 > 일반 공격
            
            // 1. 대시 공격 체크 (쿨타임 완료 + 대시 공격 범위 안)
            if (_owner.DashAttackCooldownTimer <= 0 && distanceToPlayer <= _owner.DashAttackRange)
            {
                _stateMachine.ChangeState(EEnemyState.DashAttack);
            }
            // 2. 일반 공격 체크 (일반 공격 범위 안, 쿨타임 없음)
            else if (distanceToPlayer <= _owner.AttackRange)
            {
                _stateMachine.ChangeState(EEnemyState.Attack);
            }
            // 3. 공격 범위 밖이면 계속 이동
            else
            {
                MoveTowardsPlayer();
            }
        }
    }

    public override void Enter()
    {
        base.Enter();
    }

    private void MoveTowardsPlayer()
    {
        if (_owner.Target == null) return;

        Vector3 currentPos = _owner.transform.position;
        Vector3 targetPos = _owner.Target.position;

        // 플레이어 방향 계산
        float direction = Mathf.Sign(targetPos.x - currentPos.x);
        
        // 플레이어를 향해 이동
        Vector3 moveDirection = new Vector3(direction * _owner.MoveSpeed * Time.deltaTime, 0f, 0f);
        _owner.transform.position += moveDirection;
    }

    public override void Exit()
    {
        base.Exit();
        _moveTween?.Kill();
        // DOTween 애니메이션 중지
        _owner.transform.DOKill();
    }
}
