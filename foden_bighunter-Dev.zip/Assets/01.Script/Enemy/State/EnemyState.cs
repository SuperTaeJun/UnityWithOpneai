using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyState
{
    protected EnemyStateMachine _stateMachine;
    protected Rigidbody2D _rigidbody;
    protected Enemy _owner;

    protected bool _triggerCalled; //나중에 애니메이션 끝났다는거 알려주는 용도로 쓸거임
    private string _animBoolName; // 애니메이션 상태변환 할때 쓸거
    protected float _stateTimer;// 각상태마다 사용할 타이머임

    public virtual void AnimFinishTrigger() => _triggerCalled = true;

    public EnemyState(EnemyStateMachine stateMachine, Rigidbody2D rigidbody2D, Enemy enemy, string animBoolName)
    {
        _stateMachine = stateMachine;
        _rigidbody = rigidbody2D;
        _owner = enemy;
        _animBoolName = animBoolName;

    }
    protected virtual void SetAnimation(bool value)
    {
        if (!string.IsNullOrEmpty(_animBoolName))
            _owner.Animator.SetBool(_animBoolName, value);
    }

    public virtual void Enter()
    {

        _stateTimer = 0;
        //SetAnimation(true);
        _triggerCalled = false;
    }
    public virtual void Update()
    {
        _stateTimer += Time.deltaTime;
    }
    public virtual void Exit()
    {
        //SetAnimation(false);
    }
}
