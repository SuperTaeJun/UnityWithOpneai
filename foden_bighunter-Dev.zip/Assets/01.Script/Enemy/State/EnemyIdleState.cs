using UnityEngine;

public class EnemyIdleState : EnemyState
{

    private float _randIdleTime;
    public EnemyIdleState(EnemyStateMachine stateMachine, Rigidbody2D rigidbody2D, Enemy enemy, string animBoolName) : base(stateMachine, rigidbody2D, enemy, animBoolName)
    {
    }
    public override void Enter()
    {
        base.Enter();
        _randIdleTime = Random.Range(1f, 2f);


    }
    public override void Update()
    {
        base.Update();

        if (_stateTimer > _randIdleTime)
        {
            _stateMachine.ChangeState(EEnemyState.Move);
        }

    }
    public override void Exit()
    {
        base.Exit();
    }
}
