using UnityEngine;
using DG.Tweening;

public class EnemyDashAttackState : EnemyState
{
    private Sequence _dashSequence;
    private float _backStepDistance = 3f;
    private float _dashSpeed = 0.5f;

    public EnemyDashAttackState(EnemyStateMachine stateMachine, Rigidbody2D rigidbody2D, Enemy enemy, string animBoolName) : base(stateMachine, rigidbody2D, enemy, animBoolName)
    {
        
    }

    public override void Update()
    {
        base.Update();

    }
    public override void Enter()
    {
        base.Enter();
        
        // 대시 공격 쿨타임 시작
        _owner.DashAttackCooldownTimer = _owner.DashAttackCooldown;
        
        TempDashAttackAnim();
    }
    public override void Exit()
    {
        base.Exit();
        _dashSequence?.Kill();
        _owner.transform.DOKill();
    }

    private void TempDashAttackAnim()
    {
        if (_owner.Target == null) 
        {
            _stateMachine.ChangeState(EEnemyState.Idle);
            return;
        }

        // 기존 시퀀스 정리
        _dashSequence?.Kill();

        Vector3 currentPos = _owner.transform.position;
        Vector3 targetPos = _owner.Target.position;
        
        // 플레이어 방향 계산
        float direction = Mathf.Sign(targetPos.x - currentPos.x);
        
        // 1단계: 뒤로 물러나기 (플레이어 반대 방향)
        Vector3 backStepPos = new Vector3(
            currentPos.x - (direction * _backStepDistance),
            currentPos.y,
            currentPos.z
        );
        
        // 2단계: 플레이어를 향해 빠르게 돌진
        Vector3 dashTargetPos = new Vector3(
            targetPos.x,
            currentPos.y,
            currentPos.z
        );

        _dashSequence = DOTween.Sequence();
        
        // 뒤로 물러나기
        _dashSequence.Append(_owner.transform.DOMove(backStepPos, 0.4f).SetEase(Ease.OutQuad))
            // 잠깐 대기 
            .AppendInterval(0.4f)
            // 빠르게 돌진 
            .Append(_owner.transform.DOMove(dashTargetPos, _dashSpeed).SetEase(Ease.InQuad))
            .OnComplete(() =>
            {
                // 대시 공격 완료 후 Idle 상태로 전환
                _stateMachine.ChangeState(EEnemyState.Recovery);
            });
    }
}
