using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class EnemyRecoveryState : EnemyState
{
    private Sequence _recoverySequence;

    public EnemyRecoveryState(EnemyStateMachine stateMachine, Rigidbody2D rigidbody2D, Enemy enemy, string animBoolName) : base(stateMachine, rigidbody2D, enemy, animBoolName)
    {
    }
    public override void Enter()
    {
        base.Enter();
        TempRecoveryAnim();
    }
    public override void Exit()
    {
        base.Exit();
        _recoverySequence?.Kill();
        _owner.transform.DOKill();

        // 스케일을 원래대로 복원
        _owner.transform.localScale = _owner.OriginScale;
    }
    public override void Update()
    {
        base.Update();

        if (_stateTimer > _owner.RecoveryTime)
        {
            _stateMachine.ChangeState(EEnemyState.Idle);
        }
    }

    private void TempRecoveryAnim()
    {
        // 기존 시퀀스 정리
        _recoverySequence?.Kill();

        // 회복 애니메이션: 작아졌다가 다시 커지는 효과 (숨 고르기)
        _recoverySequence = DOTween.Sequence();
        
        // 원래 스케일 저장
        Vector3 originalScale = _owner.transform.localScale;
        
        // 작아지기 (0.3초)
        _recoverySequence.Append(_owner.transform.DOScale(originalScale * 0.9f, 0.3f).SetEase(Ease.InOutQuad))
            // 다시 커지기 (0.3초)
            .Append(_owner.transform.DOScale(originalScale, 0.1f).SetEase(Ease.InOutQuad))
            // 반복 (RecoveryTime 동안)
            .SetLoops(-1, LoopType.Restart);
    }
}
