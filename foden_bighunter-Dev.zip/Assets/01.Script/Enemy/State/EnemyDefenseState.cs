using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDefenseState : EnemyState
{
    public EnemyDefenseState(EnemyStateMachine stateMachine, Rigidbody2D rigidbody2D, Enemy enemy, string animBoolName) : base(stateMachine, rigidbody2D, enemy, animBoolName)
    {
    }
    public override void Update()
    {
        base.Update();

    }
    public override void Enter()
    {
        base.Enter();
    }
    public override void Exit()
    {
        base.Exit();
    }
}
