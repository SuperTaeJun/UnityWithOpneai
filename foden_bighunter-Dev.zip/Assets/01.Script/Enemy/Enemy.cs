using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
public class Enemy : MonoBehaviour, IDamageable
{
    [field: Header("스텟")]
    [field: SerializeField] public float MaxHealth { get; private set; }
    [field: SerializeField] public float MoveSpeed { get; private set; }
    public float CurrentHealth { get; set; }

    [field: Header("컴포넌트")]
    [field: SerializeField] public SpriteRenderer[] SpriteRenderer{ get; private set; }
    [field: SerializeField] public Rigidbody2D Rigidbody2D { get; private set; }
    [field: SerializeField] public Collider2D Collider { get; private set; }
    [field: SerializeField] public Animator Animator { get; private set; }
    [field: SerializeField] public EnemyProjectileRemover ProjectileRemover { get; private set; }


    [field: Header("공격 - 공격탐지 범위(노랑색) , 일반공격범위()빨강색) , 대시공격범위(주황색)")]
    [field: SerializeField] public float AttackRange { get; private set; }
    [field: SerializeField] public float DashAttackRange { get; private set; }
    [field: SerializeField] public float AttackCheckDistance { get; private set; } = 5f;

    [field: Header("공격 쿨타임")]
    [field: SerializeField] public float DashAttackCooldown { get; private set; } = 5f;

    [field: Header("리커버리 타임")]
    [field: SerializeField] public float RecoveryTime { get; private set; } = 0.5f;

    public Vector3 OriginScale{ get; private set; }

    // 쿨타임 타이머
    public float DashAttackCooldownTimer { get; set; }

    protected EnemyStateMachine _stateMachine;
    private Dictionary<EEnemyState, EnemyState> _states;
    public Dictionary<EEnemyState, EnemyState> States => _states;

    public Transform Target { get; private set; }

    [SerializeField] private float _moveTime = 1.0f;
    [SerializeField] private Ease _easeType = Ease.OutBack;

    private Vector3 _targetPos;

    //애니메이션 이벤트들
    public void AnimFinishTrigger() => _stateMachine.currentState.AnimFinishTrigger();
    private void Awake()
    {
        _stateMachine = new EnemyStateMachine();
        _states = new Dictionary<EEnemyState, EnemyState>()
        {
            { EEnemyState.Idle, new EnemyIdleState(_stateMachine, Rigidbody2D, this, "Idle") },
            { EEnemyState.Move, new EnemyForwardState(_stateMachine, Rigidbody2D, this, "Move") },
            { EEnemyState.Attack, new EnemyAttackState(_stateMachine, Rigidbody2D, this, "Attack") },
            { EEnemyState.DashAttack, new EnemyDashAttackState(_stateMachine, Rigidbody2D, this, "DashAttack") },
            { EEnemyState.Defense, new EnemyDefenseState(_stateMachine, Rigidbody2D, this, "Defense") },
            { EEnemyState.Recovery, new EnemyRecoveryState(_stateMachine, Rigidbody2D,this, "Recovery")},
            { EEnemyState.Dead, new EnemyDeadState(_stateMachine, Rigidbody2D, this, "Dead")}
        };

        Target = GameObject.FindGameObjectWithTag("Player").transform;


        if (GameSessionData.Instance != null)
            MaxHealth *= GameSessionData.Instance.GameRunConfig.EnemyHpMultiplier;

        CurrentHealth = MaxHealth;

        _targetPos = transform.position;

        // 시작할 땐 오른쪽 화면 밖으로 보내두기
        transform.position = _targetPos + new Vector3(20f, 0, 0);
        OriginScale = transform.localScale;

        SpriteRenderer = GetComponentsInChildren<SpriteRenderer>();
        foreach(var sr in SpriteRenderer)
        {
            sr.sortingLayerName = "Enemy";
        }
    }
    public Tween MoveIn()
    {
        return transform.DOMove(_targetPos, _moveTime).SetEase(_easeType);
    }

    void Start()
    {
        if (_stateMachine != null)
        {
            _stateMachine.InitStateMachine(_states[EEnemyState.Idle], this);
        }
        UiManager.Instance.RefreshBossUi(CurrentHealth, MaxHealth);
    }

    void Update()
    {
        if (GameManager.Instance.CurrentState != EGameState.Playing) return;

        if (_stateMachine != null)
        {
            _stateMachine.currentState.Update();
        }

        // 쿨타임 타이머 감소
        if (DashAttackCooldownTimer > 0)
        {
            DashAttackCooldownTimer -= Time.deltaTime;
        }
    }

    public void TakeDamage(DamageInfo damageInfo)
    {
        CurrentHealth -= damageInfo.DamageAmount;

        if (CurrentHealth <= 0)
        {
            CurrentHealth = 0;
            _stateMachine.ChangeState(EEnemyState.Dead);
        }

        UiManager.Instance.RefreshBossUi(CurrentHealth, MaxHealth);

    }

    private void OnDrawGizmos()
    {
        // 공격 체크 거리 표시 (노란색)
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, AttackCheckDistance);

        // 일반 공격 범위 표시 (빨간색)
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, AttackRange);

        // 대시 공격 범위 표시 (주황색)
        Gizmos.color = new Color(1f, 0.5f, 0f);
        Gizmos.DrawWireSphere(transform.position, DashAttackRange);
    }

    public void OnHitWeakPoint()
    {
        _stateMachine.ChangeState(EEnemyState.Recovery);
    }
}
