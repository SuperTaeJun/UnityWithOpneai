using System;
using System.Collections.Generic;
using UnityEngine;

public enum EProjectileType
{
    None,
    Javelin,
    Boomerang,
    Laser,
    SplitBall,
    BounceBall
}

public enum EEffectType
{
    None,
    Explosion,
    Sparkle,
    Smoke,
}

[Serializable]
public class ProjectilePoolItem
{
    public EProjectileType type;
    public GameObject prefab;
    public int initialSize = 8;
}

[Serializable]
public class EffectPoolItem
{
    public EEffectType type;
    public GameObject prefab;
    public int initialSize = 8;
}

public class ObjectPoolManager : Singleton<ObjectPoolManager>
{
    [Header("공통 설정")]
    [SerializeField] private Transform projectileRoot;
    [SerializeField] private Transform effectRoot;

    [Header("발사체 풀 설정")]
    [SerializeField] private List<ProjectilePoolItem> projectileItems = new List<ProjectilePoolItem>();

    [Header("이펙트 풀 설정")]
    [SerializeField] private List<EffectPoolItem> effectItems = new List<EffectPoolItem>();

    // 발사체 풀
    private readonly Dictionary<EProjectileType, Queue<GameObject>> _projectilePools = new Dictionary<EProjectileType, Queue<GameObject>>();

    private readonly Dictionary<GameObject, EProjectileType> _projectileInstanceToType = new Dictionary<GameObject, EProjectileType>();

    // 이펙트 풀
    private readonly Dictionary<EEffectType, Queue<GameObject>> _effectPools = new Dictionary<EEffectType, Queue<GameObject>>();

    private readonly Dictionary<GameObject, EEffectType> _effectInstanceToType = new Dictionary<GameObject, EEffectType>();

    protected override void Awake()
    {
        base.Awake();
        if (projectileRoot == null)
            projectileRoot = transform;

        if (effectRoot == null)
            effectRoot = transform;

        InitProjectilePools();
        InitEffectPools();
    }



    private void InitProjectilePools()
    {
        foreach (var item in projectileItems)
        {
            if (item.prefab == null)
            {
                Debug.LogWarning($"[ObjectPool] Projectile {item.type} 프리팹이 비어 있음");
                continue;
            }

            if (!_projectilePools.ContainsKey(item.type))
                _projectilePools[item.type] = new Queue<GameObject>();

            var queue = _projectilePools[item.type];

            for (int i = 0; i < item.initialSize; i++)
            {
                var obj = CreateProjectileInstance(item.type, item.prefab);
                queue.Enqueue(obj);
            }
        }
    }

    private GameObject CreateProjectileInstance(EProjectileType type, GameObject prefab)
    {
        var obj = Instantiate(prefab, projectileRoot);
        obj.SetActive(false);
        _projectileInstanceToType[obj] = type;
        return obj;
    }

    private ProjectilePoolItem FindProjectileItem(EProjectileType type)
    {
        return projectileItems.Find(x => x.type == type);
    }


    private void InitEffectPools()
    {
        foreach (var item in effectItems)
        {
            if (item.prefab == null)
            {
                Debug.LogWarning($"[ObjectPool] Effect {item.type} 프리팹이 비어 있음");
                continue;
            }

            if (!_effectPools.ContainsKey(item.type))
                _effectPools[item.type] = new Queue<GameObject>();

            var queue = _effectPools[item.type];

            for (int i = 0; i < item.initialSize; i++)
            {
                var obj = CreateEffectInstance(item.type, item.prefab);
                queue.Enqueue(obj);
            }
        }
    }

    private GameObject CreateEffectInstance(EEffectType type, GameObject prefab)
    {
        var obj = Instantiate(prefab, effectRoot);
        obj.SetActive(false);
        _effectInstanceToType[obj] = type;
        return obj;
    }

    private EffectPoolItem FindEffectItem(EEffectType type)
    {
        return effectItems.Find(x => x.type == type);
    }

    public GameObject GetProjectile(EProjectileType type, Vector3 position, Quaternion rotation)
    {
        if (type == EProjectileType.None)
        {
            Debug.LogError("[ObjectPool] None ProjectileType으로 Spawn 호출됨");
            return null;
        }

        if (!_projectilePools.TryGetValue(type, out var queue))
        {
            var item = FindProjectileItem(type);
            if (item == null || item.prefab == null)
            {
                Debug.LogError($"[ObjectPool] 등록되지 않은 ProjectileType: {type}");
                return null;
            }

            queue = new Queue<GameObject>();
            _projectilePools[type] = queue;
        }

        GameObject obj;
        if (queue.Count > 0)
        {
            obj = queue.Dequeue();
        }
        else
        {
            var item = FindProjectileItem(type);
            if (item == null || item.prefab == null)
            {
                Debug.LogError($"[ObjectPool] Projectile {type} 프리팹을 찾을 수 없음");
                return null;
            }

            obj = CreateProjectileInstance(type, item.prefab);
        }

        // 활성화 (OnEnable에서 초기화가 먼저 실행됨)
        obj.SetActive(true);

        // 위치와 회전 설정 (OnEnable 이후에 설정하여 잔상 방지)
        var t = obj.transform;
        t.SetPositionAndRotation(position, rotation);

        return obj;
    }

    public T GetProjectile<T>(EProjectileType type, Vector3 position, Quaternion rotation) where T : Component
    {
        var obj = GetProjectile(type, position, rotation);
        return obj != null ? obj.GetComponent<T>() : null;
    }

    public GameObject GetEffect(EEffectType type, Vector3 position, Quaternion rotation)
    {
        if (type == EEffectType.None)
        {
            Debug.LogError("[ObjectPool] None EffectType으로 Spawn 호출됨");
            return null;
        }

        if (!_effectPools.TryGetValue(type, out var queue))
        {
            var item = FindEffectItem(type);
            if (item == null || item.prefab == null)
            {
                Debug.LogError($"[ObjectPool] 등록되지 않은 EffectType: {type}");
                return null;
            }

            queue = new Queue<GameObject>();
            _effectPools[type] = queue;
        }

        GameObject obj;
        if (queue.Count > 0)
        {
            obj = queue.Dequeue();
        }
        else
        {
            var item = FindEffectItem(type);
            if (item == null || item.prefab == null)
            {
                Debug.LogError($"[ObjectPool] Effect {type} 프리팹을 찾을 수 없음");
                return null;
            }

            obj = CreateEffectInstance(type, item.prefab);
        }

        // 활성화 (OnEnable에서 초기화가 먼저 실행됨)
        obj.SetActive(true);

        // 위치와 회전 설정 (OnEnable 이후에 설정하여 잔상 방지)
        var t = obj.transform;
        t.SetPositionAndRotation(position, rotation);

        return obj;
    }

    public T GetEffect<T>(EEffectType type, Vector3 position, Quaternion rotation) where T : Component
    {
        var obj = GetEffect(type, position, rotation);
        return obj != null ? obj.GetComponent<T>() : null;
    }

    // 어떤 오브젝트든 여기로 보내면 알아서 발사체/이펙트 중 맞는 풀로 되돌림.
    public void Retrun(GameObject obj)
    {
        if (obj == null) return;

        // 1) 발사체인지 확인
        if (_projectileInstanceToType.TryGetValue(obj, out var projType))
        {
            obj.transform.SetParent(projectileRoot);
            obj.SetActive(false);
            if (!_projectilePools.TryGetValue(projType, out var queue))
            {
                queue = new Queue<GameObject>();
                _projectilePools[projType] = queue;
            }

            queue.Enqueue(obj);
            return;
        }

        // 2) 이펙트인지 확인
        if (_effectInstanceToType.TryGetValue(obj, out var effType))
        {
            obj.SetActive(false);

            if (!_effectPools.TryGetValue(effType, out var queue))
            {
                queue = new Queue<GameObject>();
                _effectPools[effType] = queue;
            }

            queue.Enqueue(obj);
            return;
        }

        // 3) 풀에서 안 만든거면 그냥 Destroy
        Destroy(obj);
    }

    public void Despawn(Component comp)
    {
        if (comp != null)
            Retrun(comp.gameObject);
    }

}
