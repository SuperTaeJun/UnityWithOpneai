using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public struct DamageInfo
{
    public int DamageAmount;

    public DamageInfo(int damageAmount)
    {
        DamageAmount = damageAmount;
    }
}

public interface IDamageable
{
    void TakeDamage(DamageInfo damageInfo);
}
