using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UI_Popup : MonoBehaviour
{
    public Action _closeCallback;

    [Header("Animation Target")]
    [SerializeField] private Transform _contentTransform; // 팝업 내부 컨텐츠(패널 등)

    private CanvasGroup _canvasGroup; // [추가] 투명도 조절용

    protected virtual void Awake()
    {
        if (_canvasGroup != null)
            _canvasGroup = GetComponent<CanvasGroup>();
        else
            Debug.Log("캔버스 그룹 추가하세여");
    }
    public virtual void Open(Action callback = null)
    {
        _closeCallback = callback;

        Debug.Log("팝업 오픈");

        // 활성화 전 초기화
        gameObject.SetActive(true);

        // 기존 애니메이션 즉시 중단
        if (_contentTransform != null) _contentTransform.DOKill();
        if (_canvasGroup != null) _canvasGroup.DOKill();

        // [연출 설정]
        // 1. 크기: 0.95배(살짝 작음)에서 시작 -> 1.0배로 커짐
        if (_contentTransform != null)
        {
            _contentTransform.localScale = new Vector3(0.95f, 0.95f, 1f);
            _contentTransform.DOScale(1f, 0.25f).SetEase(Ease.OutBack).SetUpdate(true);
        }

        // 2. 투명도: 0(투명)에서 시작 -> 1(불투명)로 페이드 인
        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.DOFade(1f, 0.25f).SetUpdate(true);
        }
    }

    public virtual void Close()
    {
        _closeCallback?.Invoke();

        if (PopupManager.Instance != null)
        {
            PopupManager.Instance.PopUpClose();
        }

        // 애니메이션 중단
        if (_contentTransform != null) _contentTransform.DOKill();
        if (_canvasGroup != null) _canvasGroup.DOKill();

        // [닫기 연출]
        // 투명해지면서(Fade Out) 살짝 작아지거나(Scale Down) 그냥 사라짐
        Sequence seq = DOTween.Sequence().SetUpdate(true);

        // 1. 투명도 0으로
        if (_canvasGroup != null)
        {
            seq.Join(_canvasGroup.DOFade(0f, 0.2f));
        }

        // 2. 크기 살짝 줄이기 (선택 사항: 더 쫀득한 느낌을 원하면 추가)
        if (_contentTransform != null)
        {
            seq.Join(_contentTransform.DOScale(0.95f, 0.2f));
        }

        // 3. 애니메이션 끝나면 비활성화
        seq.OnComplete(() =>
        {
            gameObject.SetActive(false);
        });
    }
}