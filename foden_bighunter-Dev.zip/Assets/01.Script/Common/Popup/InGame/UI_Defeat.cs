using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UI_Defeat : UI_Popup
{
    [SerializeField] private Button _buttonRetry;
    [SerializeField] private Button _butoonRoby;

    private void OnEnable()
    {
        _buttonRetry.onClick.AddListener(OnClickRetry);
        _butoonRoby.onClick.AddListener(OnClickRoby);
    }
    private void OnDisable()
    {
        _buttonRetry.interactable = true;
        _buttonRetry.onClick.RemoveListener(OnClickRetry);
    }
    public override void Open(Action callback = null)
    {
        base.Open(callback);
        if (GameManager.Instance != null)
            GameManager.Instance.Pause();
    }
    private void OnClickRetry()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        _buttonRetry.interactable = false;
        Close();
    }
    private void OnClickRoby()
    {
        SceneManager.LoadSceneAsync("Loby");
        _butoonRoby.interactable = false;
        Close();
    }

}
