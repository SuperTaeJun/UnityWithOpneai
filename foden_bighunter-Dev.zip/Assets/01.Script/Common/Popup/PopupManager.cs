using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public enum EPopupType
{
    UI_Defeat = 0,
    UI_Result = 1,
    UI_Stage = 2,
    UI_Upgrade = 3
}
public class PopupManager : Singleton<PopupManager>
{
    public List<UI_Popup> Popups;
    private Stack<UI_Popup> _openPopups = new Stack<UI_Popup>();
    public Stack<UI_Popup> OpenPopups => _openPopups;

    public Action<bool> OnPopupStateChanged;

    protected override void Awake()
    {
        base.Awake();
        
        // 씬 전환 시 스택 초기화
        _openPopups.Clear();
        
        Debug.Log($"[PopupManager] 초기화 완료 - 등록된 팝업 수: {Popups?.Count ?? 0}");
    }

    protected override void OnDestroy()
    {
        base.OnDestroy();
        
        // 모든 이벤트 리스너 제거
        OnPopupStateChanged = null;
        _openPopups.Clear();
    }
    private T OpenPopup<T>(EPopupType popupType, Action closeCallback = null) where T : UI_Popup
    {
        foreach (UI_Popup pop in Popups)
        {
            if (pop.name == popupType.ToString())
            {
                pop.Open(closeCallback);
                _openPopups.Push(pop);
                return pop as T;
            }
        }
        return null;
    }
    private void PopUpOpen(string popupName, Action closeCallback)
    {
        foreach (UI_Popup pop in Popups)
        {
            if (pop.name == popupName)
            {
                pop.Open(closeCallback);
                _openPopups.Push(pop);
                break;
            }
        }
    }
    public void Open(EPopupType popupType, Action callBack = null)
    {
        PopUpOpen(popupType.ToString(), callBack);
        OnPopupStateChanged?.Invoke(true);
    }


    public void PopUpClose(Action callBack = null)
    {
        if (_openPopups.Count > 0)
        {
            _openPopups.Pop();
            OnPopupStateChanged?.Invoke(_openPopups.Count > 0);

            // 남은 팝업들의 Sort Order 재정렬
            UpdatePopupSortOrders();
        }
    }

    /// <summary>
    /// 현재 열려있는 팝업들의 Canvas Sort Order를 재정렬합니다.
    /// </summary>
    private void UpdatePopupSortOrders()
    {
        int index = 0;
        foreach (UI_Popup popup in _openPopups)
        {
            Canvas canvas = popup.GetComponent<Canvas>();
            if (canvas != null)
            {
                canvas.sortingOrder = index * 10;
            }
            index++;
        }
    }
}
