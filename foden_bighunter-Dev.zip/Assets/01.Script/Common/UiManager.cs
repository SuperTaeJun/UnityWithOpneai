using System;
using System.Collections;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UiManager : Singleton<UiManager>
{
    [Header("보스 Ui")]
    [SerializeField] private Slider _healthBar;
    [SerializeField] private TextMeshProUGUI _healthText;


    [Header("플레이어 Ui")]
    [SerializeField] private TextMeshProUGUI _playerProjectileText;
    [SerializeField] private Button _pauseButton;


    [Header("Game Ready Animation")]
    [SerializeField] private RectTransform _playerUiContainer;
    [SerializeField] private RectTransform _bossUiContainer;
    [SerializeField] private RectTransform _inputButtonContainer;
    [SerializeField] private float _animationDuration = 0.5f;
    [SerializeField] private float _delayBeforeStart = 0.3f;

    [Header("Test")]
    [SerializeField] private TextMeshProUGUI _fpsText;

    private float _targetHealth;
    private float _currentDisplayHealth;
    private float _maxHealth;
    private Coroutine _healthDecreaseCoroutine;

    private float _fpsUpdateTimer = 0f;
    private const float FPS_UPDATE_INTERVAL = 0.1f;

    protected override void Awake()
    {
        _pauseButton.onClick.AddListener(() => { PopupManager.Instance.Open(EPopupType.UI_Defeat); _pauseButton.interactable = false; });
    }
    private void OnDisable()
    {
        _pauseButton.onClick.RemoveAllListeners();
        DOTween.KillAll();
    }
    private void Update()
    {
        // FPS 표시 (0.1초마다 업데이트)
        _fpsUpdateTimer += Time.unscaledDeltaTime;
        if (_fpsUpdateTimer >= FPS_UPDATE_INTERVAL)
        {
            float fps = 1f / Time.unscaledDeltaTime;
            _fpsText.text = $"FPS: {Mathf.RoundToInt(fps)}";
            _fpsUpdateTimer = 0f;
        }
    }

    public void RefreshBossUi(float currentHealth, float maxHealth)
    {
        _maxHealth = maxHealth;
        _targetHealth = currentHealth;

        // 이전 코루틴이 실행 중이면 중지
        if (_healthDecreaseCoroutine != null)
        {
            StopCoroutine(_healthDecreaseCoroutine);
        }

        _currentDisplayHealth = currentHealth;
        _healthBar.value = currentHealth / maxHealth;


        _healthText.text = $"{currentHealth} / {maxHealth}";
    }

    public void RefreshPlayerProjectileUi(int currentCount)
    {
        _playerProjectileText.text = $"{currentCount}";
    }


    public IEnumerator GameReadyAnimationCoroutine(Action onComplete = null)
    {
        // 기존에 실행 중인 트윈이 있다면 중지
        _bossUiContainer?.DOKill();
        _playerUiContainer?.DOKill();
        _inputButtonContainer?.DOKill();

        // UI 초기 위치 설정 (화면 밖)
        Vector2 bossUiStartPos = Vector2.zero;
        Vector2 playerUiStartPos = Vector2.zero;
        Vector2 inputButtonStartPos = Vector2.zero;

        if (_bossUiContainer != null)
        {
            bossUiStartPos = _bossUiContainer.anchoredPosition;
            _bossUiContainer.anchoredPosition = new Vector2(bossUiStartPos.x, bossUiStartPos.y + 500f);
        }

        if (_playerUiContainer != null)
        {
            playerUiStartPos = _playerUiContainer.anchoredPosition;
            _playerUiContainer.anchoredPosition = new Vector2(playerUiStartPos.x, playerUiStartPos.y + 500f);
        }
        if (_inputButtonContainer != null)
        {
            inputButtonStartPos = _inputButtonContainer.anchoredPosition;
            _inputButtonContainer.anchoredPosition = new Vector2(playerUiStartPos.x, playerUiStartPos.y - 500f);
        }

        // 잠시 대기
        yield return new WaitForSeconds(_delayBeforeStart);

        // UI 애니메이션 시작
        Sequence sequence = DOTween.Sequence();

        if (_bossUiContainer != null)
        {
            sequence.Join(_bossUiContainer.DOAnchorPos(bossUiStartPos, _animationDuration).SetEase(Ease.OutBack));
        }

        if (_playerUiContainer != null)
        {
            sequence.Join(_playerUiContainer.DOAnchorPos(playerUiStartPos, _animationDuration).SetEase(Ease.OutBack));
        }

        if (_inputButtonContainer != null)
        {
            sequence.Join(_inputButtonContainer.DOAnchorPos(playerUiStartPos, _animationDuration).SetEase(Ease.OutBack));
        }

        // 애니메이션 완료 대기
        yield return sequence.WaitForCompletion();

        // 완료 콜백 호출
        onComplete?.Invoke();
    }

    // UI를 즉시 표시 (애니메이션 없이)
    public void ShowUiImmediate()
    {
        if (_bossUiContainer != null)
        {
            _bossUiContainer.DOKill();
        }

        if (_playerUiContainer != null)
        {
            _playerUiContainer.DOKill();
        }
    }
}
