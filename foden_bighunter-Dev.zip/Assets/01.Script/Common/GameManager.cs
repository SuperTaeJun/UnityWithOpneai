using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
public class GameManager : Singleton<GameManager>
{
    private EGameState _currentState = EGameState.Playing;
    private bool _isPaused = false;

    public EGameState CurrentState => _currentState;
    public bool IsPaused => _isPaused;

    [SerializeField] private Player _player;
    [SerializeField] private Enemy _enemy;

    void Start()
    {
        Time.timeScale = 1f;
        Application.targetFrameRate = 60;
        _currentState = EGameState.Ready;
        StartCoroutine(GameReadySequence());
    }

    private IEnumerator GameReadySequence()
    {
        Debug.Log("[GameManager] 캐릭터 등장 시작");
        yield return StartCoroutine(UiManager.Instance.GameReadyAnimationCoroutine());

        // 1. 플레이어와 적을 화면 밖에서 목표 지점으로 이동 (동시에 시작)
        // MoveToStartPos 코루틴은 Player/Enemy 스크립트에 추가해야 함 (아래 예시 참고)
        Tween playerTween = _player.MoveIn();
        Tween enemyTween = _enemy.MoveIn();

        yield return playerTween.WaitForCompletion();
        yield return enemyTween.WaitForCompletion();

        Debug.Log("[GameManager] 캐릭터 등장 완료 -> UI 애니메이션 시작");

        // 2. UI 애니메이션 재생 (UiManager의 코루틴이 끝날 때까지 대기)
        // UiManager의 GameReadyAnimationCoroutine이 끝나야 다음으로 넘어감

        Debug.Log("[GameManager] UI 애니메이션 완료 -> 게임 시작");

        // 3. 게임 시작
        GameStart();
    }

    private void GameStart()
    {
        _currentState = EGameState.Playing;
        Time.timeScale = 1f;
        Debug.Log("[GameManager] 게임 시작!");
    }
    public void Pause()
    {
        if (_isPaused) return;

        _isPaused = true;
        _currentState = EGameState.Paused;
        Time.timeScale = 0f;
    }

    public void Resume()
    {
        if (!_isPaused) return;

        _isPaused = false;
        _currentState = EGameState.Playing;
        Time.timeScale = 1f;
    }

    public void TogglePause()
    {
        if (_isPaused)
        {
            Resume();
        }
        else
        {
            Pause();
        }
    }
}

public enum EGameState
{
    Ready,
    Playing,
    Paused,
    GameOver
}
