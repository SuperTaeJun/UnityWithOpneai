using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MirroProp : MonoBehaviour
{
    [SerializeField] private SpriteRenderer _spriteRender;
    [SerializeField] private Collider2D _collider2D;
    [Header("복제 설정")]
    [SerializeField] private float _splitAngle = 5; // 복제된 발사체가 벌어지는 각도

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Javelin projectile = collision.gameObject.GetComponentInParent<Javelin>();
        if (projectile == null) return;



        // 현재 발사체의 정보 저장
        Vector3 currentPosition = projectile.transform.position;
        Vector2 currentVelocity = projectile.Rigidbody2D.velocity;
        float currentGravityScale = projectile.Rigidbody2D.gravityScale;

        // 발사체 타입 확인
        EProjectileType projectileType = EProjectileType.Javelin;
        if (projectile is Javelin)
        {
            projectileType = EProjectileType.Javelin;
        }
        // else if (projectile is Boomerang)
        // {
        //     projectileType = EProjectileType.Boomerang;
        // }

        // 원본 발사체는 풀로 반환
        ObjectPoolManager.Instance.Retrun(projectile.gameObject);

        // 현재 속도의 각도 계산
        float currentAngle = Mathf.Atan2(currentVelocity.y, currentVelocity.x) * Mathf.Rad2Deg;

        // 2개의 발사체 생성 (왼쪽, 오른쪽으로 분산)
        for (int i = 0; i < 2; i++)
        {
            // 각도 오프셋 (-splitAngle, +splitAngle)
            float angleOffset = (i == 0) ? -_splitAngle : _splitAngle;
            float newAngle = currentAngle + angleOffset;
            float newAngleRad = newAngle * Mathf.Deg2Rad;

            // 속도의 크기는 유지하고 방향만 변경
            float speed = currentVelocity.magnitude;
            Vector2 newVelocity = new Vector2(
                Mathf.Cos(newAngleRad) * speed,
                Mathf.Sin(newAngleRad) * speed
            );

            // 발사체 생성
            GameObject newProjectile = ObjectPoolManager.Instance.GetProjectile(
                projectileType,
                currentPosition,
                Quaternion.identity
            );

            ProjectileBase newProjectileBase = newProjectile.GetComponent<ProjectileBase>();
            if (newProjectileBase != null)
            {
                // 속도 및 중력 설정 (기존 궤적의 남은 거리를 같은 속도로 이동)
                newProjectileBase.Rigidbody2D.velocity = newVelocity;
                newProjectileBase.Rigidbody2D.gravityScale = currentGravityScale;
            }
        }

        if (_collider2D == null) return;
        StartCoroutine(ResetColliderAfterDelay(1));
    }

    private IEnumerator ResetColliderAfterDelay(float delay)
    {
        _collider2D.enabled = false;
        _spriteRender.color = new Color(1, 1, 1, 0.5f);
        yield return new WaitForSeconds(delay);
        _spriteRender.color = new Color(1, 1, 1, 1f);
        _collider2D.enabled = true;
    }
}
