using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowCamera : MonoBehaviour
{
    [SerializeField] private Vector3 _offset;
    private Transform _target;

    void Start()
    {
        _target = GameObject.FindWithTag("Player").transform;

        // // 초기 오프셋 계산 (카메라 위치 - 타겟 위치)
        // if (_target != null)
        // {
        //     _offset = transform.position - _target.position;
        // }
    }

    void LateUpdate()
    {
        if (GameManager.Instance.CurrentState != EGameState.Playing) return;

        if (_target != null)
        {
            // X축만 타겟을 따라가고, Y와 Z는 오프셋 유지
            Vector3 newPosition = transform.position;
            newPosition.x = _target.position.x + _offset.x;
            transform.position = newPosition;
        }
    }
}
