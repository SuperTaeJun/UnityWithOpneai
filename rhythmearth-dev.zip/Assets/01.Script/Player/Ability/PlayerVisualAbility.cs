using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class PlayerVisualAbility : PlayerAbility
{
    [SerializeField] private GameObject _danceVfx;
    [SerializeField] private float _scaleDuration = 0.1f; // 스케일 애니메이션 시간

    public void ActiveDanceVfx()
    {
        _danceVfx.SetActive(true);
        _danceVfx.transform.localScale = Vector3.zero;
        _danceVfx.transform.DOScale(Vector3.one, _scaleDuration).SetEase(Ease.OutBack);
    }

    public void DeactiveDanceVfx()
    {
        _danceVfx.transform.DOScale(Vector3.zero, _scaleDuration)
            .SetEase(Ease.InBack)
            .OnComplete(() => _danceVfx.SetActive(false));
    }

}
