using UnityEngine;
using DG.Tweening;
using System.Collections;
using System;
public class PlayerMovementAbility : PlayerAbility
{
    [Header("이동 설정")]
    [SerializeField] private float _moveDuration = 0.1f;
    [SerializeField] private float _minMoveDuration = 0.03f; // 최소 이동 시간
    [SerializeField] private float _maxMoveDuration = 0.15f; // 최대 이동 시간
    [SerializeField] private float _moveTimeRatio = 0.7f; // 다음 노트까지 시간의 몇 %를 이동에 사용할지

    [Header("점프 설정")]
    [SerializeField] private float _jumpPower = 0.8f; // 기본 점프 높이
    [SerializeField] private float _minJumpHeight = 0.5f; // 최소 점프 높이 (같은 높이 타일)
    [SerializeField] private float _maxJumpHeight = 2.5f; // 최대 점프 높이 (매우 높은 타일)
    [SerializeField] private float _jumpHeightMultiplier = 0.3f; // Y 차이에 곱할 배율 (자연스러운 증가)
    [SerializeField] private bool _useDynamicJumpHeight = true; // 동적 점프 높이 사용 여부

    [Tooltip("점프할때 최고 지점의 도달하는데 걸리는 시간의 비율 ex) 0.3 = 전체 시간중 최고 지점에 도달하는데 30% 필요")]
    [SerializeField] private float _ascentRatio = 0.4f;
    private bool _isMoving = false;
    public bool IsMoving => _isMoving;

    private Note _targetNote; // 이동할 타겟 노트
    private Note _previousNote; // 이전에 있던 노트 (파괴할 타일)
    private bool _skipTileDestruction = false; // 타일 파괴를 건너뛸지 여부 (멀티탭용)
    private bool _isHoldSliding = false; // 홀드 노트 슬라이딩 중인지 여부
    private DG.Tweening.Tween _holdSlideTween; // 홀드 슬라이드 트윈

    // 카메라 이동을 위한 이벤트
    public static event Action<Vector2> OnPlayerTargetPositionChanged;
    public static event Action OnElevatorAssistStarted; // 엘리베이터 어시스트 시작
    public static event Action OnElevatorAssistEnded; // 엘리베이터 어시스트 종료


    //-----------------------임시

    // 엘리베이터 옵션
    [SerializeField] private bool _enableElevatorAssist = true;
    [SerializeField] private float _yGapThreshold = 1.0f;        // 다음 타일과 현재 타일 Y 차가 이 값 이상일 때만 시작
    [SerializeField] private float _elevatorOffsetFromNext = 1.0f; // 항상 nextY - offset에서 멈춤(항상 아래)
    private DG.Tweening.Tween _elevatorTileTween;
    private bool _elevatorActive = false;

    private TileSpawner _tileSpawner;

    private void Start()
    {
        _tileSpawner = FindObjectOfType<TileSpawner>();
    }
    private void OnEnable()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnPlayerLandTile += OnPlayerLandOnTile;
        }
        if (InGameManager.Instance != null)
        {
            InGameManager.Instance.OnGamePause += () => { StopHoldSlide(); StopElevatorIfActive(); };
        }
    }
    private void OnDisable()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnPlayerLandTile -= OnPlayerLandOnTile;
        }
        if (InGameManager.Instance != null)
        {
            InGameManager.Instance.OnGamePause -= () => { StopHoldSlide(); StopElevatorIfActive(); };
        }
    }

    /// 엘리베이터 어시스트가 시작될지 미리 확인하는 헬퍼 메서드
    private bool WillStartElevatorAssist(Note landedNote)
    {
        if (!_enableElevatorAssist) return false;
        if (_isHoldSliding) return false;
        if (landedNote == null || landedNote.NoteType == ENoteType.Hold) return false;
        if (_tileSpawner == null) return false;

        // 다음 노트 확인
        if (!NoteManager.Instance.TryGetCurrentNote(out Note note)) return false;

        Note nextNote = note;

        // 멀티탭 노트 처리
        if (landedNote.NoteType == ENoteType.MultiTapNote)
        {
            if (!NoteManager.Instance.TryGetNextNote(out Note actualNextNote)) return false;
            nextNote = actualNextNote;
        }

        // 다음 노트의 타일 객체
        var nextTile = _tileSpawner.GetTileForNote(nextNote);
        if (nextTile == null) return false;

        // 현재 타일 객체
        var currentTile = _tileSpawner.GetTileForNote(landedNote);
        if (currentTile == null) return false;

        // 판정선 속도 확인
        float judgeLineSpeed = _owner.GetAbility<PlayerJudgeLine>().YMoveSpeed;
        if (judgeLineSpeed <= 0f) return false;

        float currentY = currentTile.transform.position.y;
        float nextY = nextTile.transform.position.y;

        // Y 격차 확인
        float gap = nextY - currentY;
        return gap > _yGapThreshold;
    }

    private void TryStartElevatorAssistAfterLanding()
    {
        if (!_enableElevatorAssist) return;
        if (_isHoldSliding) return; // 홀드 슬라이딩 중에는 엘리베이터 어시스트 실행 안 함
        if (_targetNote == null || _targetNote.NoteType == ENoteType.Hold) return;
        if (_tileSpawner == null) return;

        // 다음 노트 있어야 함
        if (!NoteManager.Instance.TryGetCurrentNote(out Note note)) return;

        Note nextNote = note;

        //멀티탭 노트의 경우 _activenotes에서 아직 디큐가 안된상태여서 따로 추가 처리해줘야함
        //nextNote == _targetNote 같음
        //일반노트는 _targetNote는 이미 디큐된상태 여서 TryGetCurrentNote하면 그다음 노트가 옴 멀티탭노트는 TryGetCurrentNote하면 _targetNote는랑 같은게 나옴
        if (_targetNote.NoteType == ENoteType.MultiTapNote)
        {
            if (!NoteManager.Instance.TryGetNextNote(out Note actualNextNote)) return;
            nextNote = actualNextNote;
        }

        // 다음 노트의 타일 객체/
        var nextTile = _tileSpawner.GetTileForNote(nextNote);
        if (nextTile == null) return;

        // 현재(착지) 타일 객체
        var currentTile = _tileSpawner.GetTileForNote(_targetNote);
        if (currentTile == null) return;

        // 판정선 속도 필요
        float judgeLineSpeed = _owner.GetAbility<PlayerJudgeLine>().YMoveSpeed;
        if (judgeLineSpeed <= 0f) return;

        float currentY = currentTile.transform.position.y;
        float nextY = nextTile.transform.position.y;

        // 다음 타일이 "위"에 있고, Y 격차가 임계 이상일 때만
        float gap = nextY - currentY;
        if (gap <= _yGapThreshold) return;

        // 항상 다음 타일 "아래"에서 멈춘다
        float desiredOffset = Mathf.Max(0.001f, _elevatorOffsetFromNext);
        float targetY = nextY - desiredOffset;

        float distance = Mathf.Abs(targetY - currentY);
        if (distance <= 0.0001f) return;

        // 판정선과 동일한 속도 → duration = 거리 / 속도
        float duration = distance / judgeLineSpeed;

        _elevatorActive = true;

        // 엘리베이터 시작 이벤트 발생 (카메라가 플레이어를 따라가도록)
        OnElevatorAssistStarted?.Invoke();

        // 원본 위치 저장
        Vector3 playerOriginalPos = _owner.transform.position;
        Vector3 tileOriginalPos = currentTile.transform.position;
        float playerX = playerOriginalPos.x;

        // 눌림 효과 설정 (OnPlayerLandOnTile과 비슷한 느낌)
        float pressDepth = 0.5f;
        float pressDuration = 0.15f; // 엘리베이터용은 조금 더 빠르게
        Ease smoothEase = Ease.OutCubic;

        // 시퀀스 생성: 눌림 → 엘리베이터 상승
        Sequence elevatorSequence = DOTween.Sequence();

        // 1단계: 눌림 효과 (타일과 플레이어 함께)
        elevatorSequence.Append(
            currentTile.transform.DOMoveY(tileOriginalPos.y - pressDepth, pressDuration)
            .SetEase(smoothEase)
        );
        elevatorSequence.Join(
            _owner.transform.DOMoveY(playerOriginalPos.y - pressDepth, pressDuration)
            .SetEase(smoothEase)
        );

        // 2단계: 엘리베이터 상승 (눌린 상태에서 바로 상승)
        elevatorSequence.Append(
            currentTile.transform.DOMoveY(targetY, duration)
            .SetEase(Ease.Linear)
            .OnUpdate(() =>
            {
                // 플레이어도 타일 따라서 이동
                _owner.transform.position = new Vector3(playerX, currentTile.LandingPosition.y, _owner.transform.position.z);
            })
        );

        elevatorSequence.OnComplete(() =>
        {
            // 엘리베이터 종료 이벤트 발생
            OnElevatorAssistEnded?.Invoke();
        });

        elevatorSequence.OnKill(() =>
        {
            _elevatorActive = false;
            OnElevatorAssistEnded?.Invoke();
        });

        _elevatorTileTween = elevatorSequence;

    }
    public void StopElevatorIfActive()
    {
        if (_elevatorActive)
        {
            _elevatorTileTween?.Kill();
            _elevatorActive = false;
        }
    }

    //특정 노트 위치로 이동합니다
    public void MoveToTile(Note targetNote, bool skipTileDestruction = false, bool startHoldSlide = false, bool forceMissMove = false)
    {
        if (_isMoving) return;

        StopElevatorIfActive();

        // 홀드 슬라이딩 중이면 먼저 중단 (StopHoldHandling에서 이미 StopHoldSlide 호출됨)
        // Miss 이동이 아닐 때만 체크하지 않고, 항상 허용

        if (targetNote == null) return;

        // 이전 노트를 저장 (현재 있는 타일)
        if (_targetNote != null)
            _previousNote = _targetNote;
        _targetNote = targetNote;
        _skipTileDestruction = skipTileDestruction;

        Vector2 destination = _targetNote.TilePosition;

        // 목적지가 현재 위치와 같다면 이동하지 않음
        if ((Vector2)transform.position == destination) return;

        _isMoving = true;

        float dynamicMoveDuration = CalculateDynamicMoveDuration(_targetNote);

        // 홀드 노트인 경우 endPosition과 holdDuration 전달
        if (startHoldSlide && _targetNote.NoteType == ENoteType.Hold)
        {
            JumpAnim(destination, dynamicMoveDuration);
        }
        else
        {
            JumpAnim(destination, dynamicMoveDuration);
        }
    }

    /// 다음 노트까지의 시간을 고려하여 동적으로 이동 시간을 계산합니다
    private float CalculateDynamicMoveDuration(Note currentNote)
    {
        if (currentNote == null)
        {
            return _moveDuration;
        }

        // 기본 이동 시간
        float calculatedDuration = _moveDuration;

        // NoteManager에서 현재 노트 정보 가져오기 
        if (NoteManager.Instance != null && NoteManager.Instance.TryGetCurrentNote(out Note note))
        {
            var nextNote = note;

            //멀티탭 노트의 경우 _activenotes에서 아직 디큐가 안되어 있어서 TryGetNextNote로 실제 다음 노트를 가져와야 함
            if (currentNote.NoteType == ENoteType.MultiTapNote)
            {
                if (!NoteManager.Instance.TryGetNextNote(out Note actualNextNote))
                {
                    return _moveDuration;
                }
                nextNote = actualNextNote;
            }

            float timeBetweenNotes = (float)(nextNote.TargetTime - currentNote.TargetTime);

            // 다음 노트까지의 시간이 충분하지 않으면 이동 시간을 줄임
            if (timeBetweenNotes > 0)
            {
                // 다음 노트까지 시간의 일정 비율만 이동에 사용
                float adjustedDuration = timeBetweenNotes * _moveTimeRatio;

                // 최소/최대 범위 내로 제한
                calculatedDuration = Mathf.Clamp(adjustedDuration, _minMoveDuration, _maxMoveDuration);
            }
        }

        return calculatedDuration;
    }

    /// 이전 노트와 타겟 노트의 Y값 차이를 기반으로 동적 점프 높이를 계산합니다
    private float CalculateDynamicJumpHeight(Note previousNote, Note targetNote)
    {
        // 동적 점프 높이를 사용하지 않으면 기본값 반환
        if (!_useDynamicJumpHeight)
        {
            return _jumpPower;
        }

        // 이전 노트가 없으면 기본 점프 높이 사용
        if (previousNote == null || targetNote == null || _tileSpawner == null)
        {
            return _jumpPower;
        }

        // 이전 노트와 타겟 노트의 타일 위치 가져오기
        var previousTile = _tileSpawner.GetTileForNote(previousNote);
        var targetTile = _tileSpawner.GetTileForNote(targetNote);

        if (previousTile == null || targetTile == null)
        {
            return _jumpPower;
        }

        // Y값 차이 계산
        float previousY = previousTile.transform.position.y;
        float targetY = targetTile.transform.position.y;
        float yDifference = Mathf.Abs(targetY - previousY);

        // Y 차이를 기반으로 점프 높이 계산
        // 기본 점프 높이 + (Y 차이 * 배율)
        float calculatedJumpHeight = _jumpPower + (yDifference * _jumpHeightMultiplier);

        // 최소/최대 범위 내로 제한
        calculatedJumpHeight = Mathf.Clamp(calculatedJumpHeight, _minJumpHeight, _maxJumpHeight);

        return calculatedJumpHeight;
    }

    private void JumpAnim(Vector2 destination, float moveDuration = 0.1f)
    {
        // 플레이어의 기존 애니메이션 중단 (OnPlayerLandOnTile의 눌림 애니메이션 포함)
        _owner.transform.DOKill();

        // 카메라에게 목표 지점 알림 (점프 시작 시)
        OnPlayerTargetPositionChanged?.Invoke(destination);

        if (!_skipTileDestruction && _previousNote != null && NoteManager.Instance != null)
        {
            NoteManager.Instance.NotifyPlayerPassedTile(_previousNote);
        }
        _skipTileDestruction = false;

        // 동적 점프 높이 계산
        float dynamicJumpHeight = CalculateDynamicJumpHeight(_previousNote, _targetNote);

        // 커스텀 점프: X축과 Y축을 분리하여 다른 속도로 제어
        Vector3 startPos = _owner.transform.position;
        float ascentDuration = moveDuration * _ascentRatio; // 상승 시간
        float descentDuration = moveDuration * (1f - _ascentRatio); // 하강 시간

        // X축 이동 (전체 시간 동안 일정하게)
        _owner.transform.DOMoveX(destination.x, moveDuration).SetEase(Ease.Linear);

        // Y축 이동 (2단계: 빠른 상승 + 느린 하강)
        Sequence jumpSequence = DOTween.Sequence();

        // 1단계: 빠르게 상승 (InQuad - 가속) - 동적 점프 높이 사용
        jumpSequence.Append(
            _owner.transform.DOMoveY(startPos.y + dynamicJumpHeight, ascentDuration)
            .SetEase(Ease.InQuad)
        );

        // 2단계: 느리게 하강 (OutQuad - 감속)
        jumpSequence.Append(
            _owner.transform.DOMoveY(destination.y, descentDuration)
            .SetEase(Ease.OutQuad)
        );

        jumpSequence.OnComplete(() =>
        {
            _isMoving = false;

            // 점프 애니메이션 완료 후 타일 착지 이벤트 발생
            if (NoteManager.Instance != null && _targetNote != null)
            {
                NoteManager.Instance.NotifyPlayerLandedOnTile(_targetNote);
            }

            TryStartElevatorAssistAfterLanding();
        });
    }

    /// 플레이어가 타일에 착지했을 때 눌림 애니메이션
    private void OnPlayerLandOnTile(Note note)
    {
        // 엘리베이터가 곧 시작될 예정이면 눌림 애니메이션 스킵
        if (WillStartElevatorAssist(note)) return;

        if (_tileSpawner == null) return;
        var currentTile = _tileSpawner.GetTileForNote(note);
        if (currentTile == null) return;

        // 기존 애니메이션 중단
        _owner.transform.DOKill();
        currentTile.transform.DOKill();

        // --- 0.2초 자연스러운 쿠션 효과 설정 ---

        // 1. 원본 위치 저장
        Vector3 playerOriginalPos = _owner.transform.position;
        Vector3 tileOriginalPos = currentTile.transform.localPosition;
        float pressDepth = 1f;

        // 2. 시간 배분 (총 0.2초)
        float pressDuration = 0.13f;  // 눌리는 시간
        float returnDuration = 0.07f; // 복귀하는 시간

        // 3. '자연스러운' 이징 (부드러운 감속)
        Ease smoothEase = Ease.OutCubic;

        // --- 애니메이션 실행 ---

        // 1. 눌림
        _owner.transform.DOMoveY(playerOriginalPos.y - pressDepth, pressDuration)
            .SetEase(smoothEase);

        currentTile.transform.DOLocalMoveY(tileOriginalPos.y - pressDepth, pressDuration)
            .SetEase(smoothEase)
            .OnComplete(() =>
            {
                // 2. 복귀
                _owner.transform.DOMoveY(playerOriginalPos.y, returnDuration)
                    .SetEase(smoothEase);

                currentTile.transform.DOLocalMoveY(tileOriginalPos.y, returnDuration)
                    .SetEase(smoothEase);
            });
    }

    /// 홀드 노트 슬라이드 시작 (LandingPos에서 EndPos까지 판정선 속도로 이동)
    public void StartHoldSlide(Note holdNote)
    {
        if (holdNote == null || holdNote.NoteType != ENoteType.Hold) return;

        // 이미 홀드 슬라이딩 중이면 먼저 중단하고 새로운 홀드 시작
        if (_isHoldSliding)
        {
            StopHoldSlide();
        }

        // 기존 엘리베이터 중단
        StopElevatorIfActive();

        // 플레이어의 기존 애니메이션 중단 (OnPlayerLandOnTile의 눌림 애니메이션 포함)
        _owner.transform.DOKill();

        _isHoldSliding = true;

        // 먼저 LandingPosition으로 점프 이동
        Vector2 landingPos = holdNote.TilePosition;

        // 이전 노트 저장 (홀드 노트로 덮어쓰기 전에)
        if (_targetNote != null)
            _previousNote = _targetNote;

        // 이제 타겟 노트를 홀드 노트로 설정
        _targetNote = holdNote;

        _isMoving = true;

        float dynamicMoveDuration = CalculateDynamicMoveDuration(holdNote);

        // 카메라에게 목표 지점 알림
        OnPlayerTargetPositionChanged?.Invoke(landingPos);
        //OnElevatorAssistStarted?.Invoke();


        // 홀드 노트는 타일을 파괴하지 않음 (종료 시까지 유지)
        if (!_skipTileDestruction && _previousNote != null && _previousNote != holdNote && NoteManager.Instance != null)
        {
            NoteManager.Instance.NotifyPlayerPassedTile(_previousNote);
        }
        _skipTileDestruction = false;

        // 동적 점프 높이 계산
        float dynamicJumpHeight = CalculateDynamicJumpHeight(_previousNote, holdNote);

        // 점프 애니메이션으로 LandingPos까지 이동
        Vector3 startPos = _owner.transform.position;
        float ascentDuration = dynamicMoveDuration * _ascentRatio;
        float descentDuration = dynamicMoveDuration * (1f - _ascentRatio);

        // X축 이동
        _owner.transform.DOMoveX(landingPos.x, dynamicMoveDuration).SetEase(Ease.Linear);

        // Y축 이동 (점프) - 동적 점프 높이 사용
        Sequence jumpSequence = DOTween.Sequence();
        jumpSequence.Append(
            _owner.transform.DOMoveY(startPos.y + dynamicJumpHeight, ascentDuration)
            .SetEase(Ease.InQuad)
        );
        jumpSequence.Append(
            _owner.transform.DOMoveY(landingPos.y, descentDuration)
            .SetEase(Ease.OutQuad)
        );

        jumpSequence.OnComplete(() =>
        {
            _isMoving = false;

            // LandingPos 도착 후 엘리베이터처럼 EndPos까지 슬라이드
            StartHoldElevatorSlide(holdNote);
        });
    }

    /// 홀드 노트 엘리베이터 슬라이드 (LandingPos에서 EndPos까지)
    private void StartHoldElevatorSlide(Note holdNote)
    {
        if (holdNote == null) return;
        _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.HoldJump);
        // 판정선 속도 가져오기
        float judgeLineSpeed = _owner.GetAbility<PlayerJudgeLine>().YMoveSpeed;
        if (judgeLineSpeed <= 0f) return;

        // EndPosition 가져오기
        Vector3 endPos = holdNote.HoldEndPosition;
        Vector3 currentPos = _owner.transform.position;

        // 이동 거리 계산
        float distance = Mathf.Abs(endPos.y - currentPos.y);

        // 홀드 지속 시간 사용 (판정선 속도와 동일하게)
        float duration = holdNote.HoldDurationTime;

        // 플레이어 X 위치 고정
        float playerX = currentPos.x;

        // 엘리베이터 시작 이벤트
        OnElevatorAssistStarted?.Invoke();

        // 플레이어를 판정선 속도로 EndPos까지 이동
        _holdSlideTween = _owner.transform.DOMoveY(endPos.y, duration)
            .SetEase(Ease.Linear)
            .OnUpdate(() =>
            {
                // X 위치 고정
                _owner.transform.position = new Vector3(playerX, _owner.transform.position.y, _owner.transform.position.z);
            })
            .OnComplete(() =>
            {
                _isHoldSliding = false;
                OnElevatorAssistEnded?.Invoke();
            })
            .OnKill(() =>
            {
                _isHoldSliding = false;
                OnElevatorAssistEnded?.Invoke();
            });
    }

    /// 홀드 슬라이드 중단 (새로운 입력이 들어왔을 때)
    public void StopHoldSlide()
    {
        Debug.Log("StopHoldSlide called");
        //if (!_isHoldSliding) return;

        // 홀드 슬라이드 트윈 중단
        _holdSlideTween?.Kill();

        _isHoldSliding = false;

        // 엘리베이터 종료 이벤트
        OnElevatorAssistEnded?.Invoke();
    }

}
