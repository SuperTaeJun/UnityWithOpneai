using UnityEngine;

public enum EPlayerAnimState
{
    Idle,
    LeftJump,
    RightJump,
    HoldJump,
    Miss,
    MultiTapDance,
}

public class PlayerAnimAbility : PlayerAbility
{
    private Animator _animator;
    private SpriteRenderer _spriteRenderer;
    protected override void Awake()
    {
        base.Awake();
        _animator = GetComponentInParent<Animator>();
        _spriteRenderer = GetComponentInParent<SpriteRenderer>();
    }

    private void Start()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnMiss += OnMiss;
        }

        if (InGameManager.Instance != null)
        {
            InGameManager.Instance.OnGameResume += () =>
            {
                ChangeAnimState(EPlayerAnimState.Idle);
            };
        }
        ChangeAnimState(EPlayerAnimState.Idle);
    }

    private void OnDisable()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnMiss -= OnMiss;
        }
        if(InGameManager.Instance != null)
        {
            InGameManager.Instance.OnGameResume -= () =>
            {
                ChangeAnimState(EPlayerAnimState.Idle);
            };
        }
    }

    private void OnMiss(Note note)
    {
        ChangeAnimState(EPlayerAnimState.Miss);
    }

    public void ChangeAnimState(EPlayerAnimState state, EJudgement eJudgement = EJudgement.Bad)
    {
        switch (state)
        {
            case EPlayerAnimState.Idle:
                _animator.SetTrigger("Idle");
                break;
            case EPlayerAnimState.LeftJump:
                _spriteRenderer.flipX = true;
                _animator.SetTrigger("LeftJump");
                _animator.SetFloat("JudgeType", (float)eJudgement);
                break;
            case EPlayerAnimState.RightJump:
                _spriteRenderer.flipX = false;
                _animator.SetTrigger("RightJump");
                _animator.SetFloat("JudgeType", (float)eJudgement);
                break;
            case EPlayerAnimState.HoldJump:
                _animator.SetTrigger("HoldJump");
                break;
            case EPlayerAnimState.Miss:
                _animator.SetTrigger("Miss");
                break;
            case EPlayerAnimState.MultiTapDance:
                _spriteRenderer.flipX = !_spriteRenderer.flipX;
                _animator.SetTrigger("MultiTapDance");
                break;
        }
    }

    private void AnimFinish()
    {
        ChangeAnimState(EPlayerAnimState.Idle);
    }
}
