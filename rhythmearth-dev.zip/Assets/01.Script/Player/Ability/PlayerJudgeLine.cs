using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerJudgeLine : PlayerAbility
{
    [SerializeField] private Transform _judgeLineTransform;
    [SerializeField] private float _yMoveSpeed = 2f; // 판정선이 위로 올라가는 일정한 속도
    [SerializeField] private float _firstNoteYOffset = 2f; // 첫 번째 노트가 플레이어보다 위에 생성될 오프셋
    [SerializeField] private float _ySmoothSpeed = 20f; // 판정선 Y축 부드러움 정도

    public float YMoveSpeed => _yMoveSpeed; // 외부에서 판정선 속도를 참조할 수 있도록
    public float CurrentY => _judgeLineTransform != null ? _judgeLineTransform.position.y : 0f; // 현재 Y 위치


    private float _initialYPosition;
    private bool _isInitialized = false;
    private void Start()
    {
        // 원본 스케일 저장

        // NoteManager의 노트 로드 완료 이벤트 구독
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnNotesLoaded += OnNotesLoaded;
        }
    }


    private void OnDisable()
    {
        // 이벤트 구독 해제
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnNotesLoaded -= OnNotesLoaded;
        }
    }

    /// 노트가 로드되고 초기화 완료되었을 때 호출
    private void OnNotesLoaded()
    {
        Debug.Log("[판정선] 노트 로드 완료 이벤트 수신 - 판정선 초기화 시작");
        InitializeJudgeLinePosition();
        _isInitialized = true;
    }
    private void Update()
    {
        if (!_isInitialized) return;
        UpdateJudgeLinePosition();
    }

    /// 판정선의 초기 위치를 설정합니다 (첫 번째 노트의 타겟 타임에 플레이어 앞에 도착하도록)
    private void InitializeJudgeLinePosition()
    {
        if (_judgeLineTransform == null || NoteManager.Instance == null) return;

        // 첫 번째 노트를 가져옵니다 (아직 스폰되지 않은 노트 포함)
        if (NoteManager.Instance.TryGetFirstNote(out Note firstNote))
        {
            // 첫 번째 노트의 타겟 타임에 판정선이 플레이어 Y + offset 위치에 도착해야 함
            // 판정선 초기 Y = (플레이어 Y + offset) - (판정선 속도 × 첫 노트 타겟 타임)

            float targetY = _owner.transform.position.y + _firstNoteYOffset;
            float timeToTarget = firstNote.TargetTime;
            float distanceToTravel = _yMoveSpeed * timeToTarget;
            float initialJudgeLineY = targetY - distanceToTravel;

            Debug.Log($"[판정선 초기화] 플레이어Y={_owner.transform.position.y:F2}, 오프셋={_firstNoteYOffset:F2}, " +
                     $"목표Y={targetY:F2}, 첫노트TargetTime={timeToTarget:F2}, 속도={_yMoveSpeed:F2}, " +
                     $"이동거리={distanceToTravel:F2}, 초기판정선Y={initialJudgeLineY:F2}");

            // 판정선 위치 설정
            Vector3 judgeLinePos = _judgeLineTransform.position;
            judgeLinePos.y = initialJudgeLineY;
            _judgeLineTransform.position = judgeLinePos;

            // 초기 Y 위치 저장 (판정선 이동 계산의 기준점)
            _initialYPosition = initialJudgeLineY;
        }
        else
        {
            Debug.LogWarning("첫 번째 노트를 찾을 수 없습니다. 판정선 초기화 실패.");
        }
    }

    /// 판정 라인의 x값은 플레이어 위치로, y값은 SongPosition 기준으로 일정한 속도로 위로 이동합니다
    private void UpdateJudgeLinePosition()
    {
        if (_judgeLineTransform == null || NoteManager.Instance == null) return;

        // SongPosition 기반으로 절대 위치 계산 (노트 타이밍과 동기화)
        float currentSongPosition = (float)NoteManager.Instance.SongPosition;

        // 목표 Y 위치 계산
        float targetY = _initialYPosition + (_yMoveSpeed * currentSongPosition);

        // X, Y 모두 부드럽게 보간하여 부들거림 방지
        Vector3 currentPos = _judgeLineTransform.position;
        float smoothY = Mathf.Lerp(currentPos.y, targetY, Time.deltaTime * _ySmoothSpeed);

        _judgeLineTransform.position = new Vector3(0, smoothY, currentPos.z);
    }
}
