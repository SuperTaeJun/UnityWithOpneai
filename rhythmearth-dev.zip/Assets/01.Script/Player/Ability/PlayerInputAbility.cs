using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerInputAbility : PlayerAbility
{
    private const float SCREEN_SPLIT_RATIO = 0.5f;

    [SerializeField] private bool _useHitSound;
    [SerializeField] private float _inputQueueTime = 0.2f; // 입력 큐 유지 시간 (0.2초로 증가)

    // 입력 상태
    private bool _isUpPressed;
    private bool _isLeftPressed;
    private bool _isRightPressed;
    private bool _anyButtonDown;

    // MultiTap 상태
    private bool _isTappingNoteActive;
    private int _tapCount;

    // Hold 상태
    private bool _isHoldingNote; // 홀드 노트 진행 중인지
    private Note _currentHoldNote; // 현재 홀드 중인 노트
    private EDirectionType _holdDirection; // 홀드 중인 방향

    // 입력 큐 시스템
    private struct InputEvent
    {
        public EDirectionType Direction;
        public float Time;
        public bool IsPress;
    }
    private Queue<InputEvent> _inputQueue = new Queue<InputEvent>();
    private HashSet<EDirectionType> _currentlyPressed = new HashSet<EDirectionType>();

    public event Action<int> OnMultiTap;
    public event Action OnMultiTapEnd;



    private void Start()
    {

    }
    private void Update()
    {
        if (InGameManager.Instance.CurrentState != EGameState.Playing)
            return;

        ProcessInput();

        if (_owner.GetAbility<PlayerMovementAbility>().IsMoving) return;

        if (_isTappingNoteActive)
        {
            HandleMultiTapInput();
        }
        else
        {
            HandleNormalInput();
        }
    }

    private void ProcessInput()
    {
        ResetInputState();
        CleanupInputQueue();

#if UNITY_EDITOR || UNITY_STANDALONE
        ProcessKeyboardInput();
#elif UNITY_ANDROID || UNITY_IOS
        ProcessTouchInput();
#endif     
        ProcessInputQueue();
    }

    private void ResetInputState()
    {
        _isLeftPressed = false;
        _isRightPressed = false;
        _isUpPressed = false;
        _anyButtonDown = false;
    }

    private void CleanupInputQueue()
    {
        // 오래된 입력 이벤트 제거
        float currentTime = Time.time;
        while (_inputQueue.Count > 0 && currentTime - _inputQueue.Peek().Time > _inputQueueTime)
        {
            _inputQueue.Dequeue();
        }
    }

    private void AddInputEvent(EDirectionType direction, bool isPress)
    {
        _inputQueue.Enqueue(new InputEvent
        {
            Direction = direction,
            Time = Time.time,
            IsPress = isPress
        });

        if (isPress)
        {
            _currentlyPressed.Add(direction);
        }
        else
        {
            _currentlyPressed.Remove(direction);
        }
    }

    private void ProcessInputQueue()
    {
        // 다음 노트가 Up 방향인지 확인
        bool isNextNoteUp = false;
        if (NoteManager.Instance != null && NoteManager.Instance.TryGetCurrentNote(out Note currentNote))
        {
            isNextNoteUp = currentNote.TargetDir == EDirectionType.Up;
        }

        // 현재 눌려있는 상태 확인
        bool isLeftCurrentlyPressed = _currentlyPressed.Contains(EDirectionType.Left);
        bool isRightCurrentlyPressed = _currentlyPressed.Contains(EDirectionType.Right);

        // 큐에서 Left와 Right 입력이 모두 있는지 확인
        bool hasLeftPress = false;
        bool hasRightPress = false;
        bool leftJustPressed = false;
        bool rightJustPressed = false;

        foreach (var inputEvent in _inputQueue)
        {
            if (inputEvent.IsPress)
            {
                if (inputEvent.Direction == EDirectionType.Left)
                {
                    hasLeftPress = true;
                    if (Time.time - inputEvent.Time < Time.deltaTime * 2)
                        leftJustPressed = true;
                }
                else if (inputEvent.Direction == EDirectionType.Right)
                {
                    hasRightPress = true;
                    if (Time.time - inputEvent.Time < Time.deltaTime * 2)
                        rightJustPressed = true;
                }
            }
        }

        // Up 입력 처리: 큐에 둘 다 있거나, 현재 둘 다 눌려있으면 OK
        bool canBeUpInput = (hasLeftPress && hasRightPress) || (isLeftCurrentlyPressed && isRightCurrentlyPressed);

        if (isNextNoteUp && canBeUpInput)
        {
            _isUpPressed = true;
            _anyButtonDown = leftJustPressed || rightJustPressed || _anyButtonDown;
        }
        else
        {
            // 일반 입력 처리
            _isLeftPressed = isLeftCurrentlyPressed;
            _isRightPressed = isRightCurrentlyPressed;
        }
    }

    private void ProcessKeyboardInput()
    {
        bool keyDownLeft = Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow);
        bool keyDownRight = Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow);

        bool keyUpLeft = Input.GetKeyUp(KeyCode.A) || Input.GetKeyUp(KeyCode.LeftArrow);
        bool keyUpRight = Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.RightArrow);

        // 입력 큐에 이벤트 추가
        if (keyDownLeft)
        {
            AddInputEvent(EDirectionType.Left, true);
            _anyButtonDown = true;
        }
        if (keyDownRight)
        {
            AddInputEvent(EDirectionType.Right, true);
            _anyButtonDown = true;
        }
        if (keyUpLeft)
        {
            AddInputEvent(EDirectionType.Left, false);
        }
        if (keyUpRight)
        {
            AddInputEvent(EDirectionType.Right, false);
        }
    }

    private void ProcessTouchInput()
    {
        foreach (Touch touch in Input.touches)
        {
            if (EventSystem.current.IsPointerOverGameObject(touch.fingerId))
                continue;

            bool isLeftSide = touch.position.x < Screen.width * SCREEN_SPLIT_RATIO;

            if (isLeftSide)
            {
                ProcessLeftTouch(touch);
            }
            else
            {
                ProcessRightTouch(touch);
            }
        }

    }

    private void ProcessLeftTouch(Touch touch)
    {
        switch (touch.phase)
        {
            case TouchPhase.Began:
                AddInputEvent(EDirectionType.Left, true);
                _anyButtonDown = true;
                break;

            case TouchPhase.Moved:
            case TouchPhase.Stationary:
                // 터치가 유지되는 동안은 입력 상태만 유지
                break;

            case TouchPhase.Ended:
            case TouchPhase.Canceled:
                AddInputEvent(EDirectionType.Left, false);
                break;
        }
    }

    private void ProcessRightTouch(Touch touch)
    {
        switch (touch.phase)
        {
            case TouchPhase.Began:
                AddInputEvent(EDirectionType.Right, true);
                _anyButtonDown = true;
                break;

            case TouchPhase.Moved:
            case TouchPhase.Stationary:
                // 터치가 유지되는 동안은 입력 상태만 유지
                break;

            case TouchPhase.Ended:
            case TouchPhase.Canceled:
                AddInputEvent(EDirectionType.Right, false);
                break;
        }
    }


    private bool IsUpPressed() => _isUpPressed;
    private bool IsLeftPressed() => _isLeftPressed && !_isUpPressed;
    private bool IsRightPressed() => _isRightPressed && !_isUpPressed;
    private bool AnyDirectionalInputDown() => _anyButtonDown;
    private bool AnyTapInputDown() => _anyButtonDown;


    private void HandleNormalInput()
    {
        // 홀드 노트 진행 중일 때
        if (_isHoldingNote)
        {
            // 홀드 종료 시간 계산
            double holdEndTime = _currentHoldNote.TargetTime + _currentHoldNote.HoldDurationTime;
            double currentTime = NoteManager.Instance.SongPosition;
            double timeUntilEnd = holdEndTime - currentTime;

            // 홀드 종료까지 0.1초 이상 남았을 때
            if (timeUntilEnd > 0.15)
            {
                // 버튼을 떼면 Miss 판정 (새로운 노트로 이동하는 것은 무시)
                if (!IsDirectionPressed(_holdDirection))
                {
                    FailHoldNote();
                }
                // 새로운 입력은 무시
                return;
            }

            // 0.1초 이내일 때만 새로운 입력 확인
            // 새로운 입력이 들어왔는지 확인 (키 다운 또는 현재 홀드 방향과 다른 방향이 눌려있는지)
            bool hasNewInput = AnyDirectionalInputDown();
            bool isDifferentDirectionPressed = false;

            // 현재 홀드 방향과 다른 방향이 눌려있는지 확인 (현재 홀드 방향은 제외)
            if (!hasNewInput)
            {
                EDirectionType currentPressedDir = GetCurrentPressedDirection(_holdDirection);
                if (currentPressedDir != EDirectionType.None)
                {
                    hasNewInput = true;
                    isDifferentDirectionPressed = true;
                }
            }

            if (hasNewInput)
            {
                // 홀드 종료 시점 확인하여 판정 후 중단
                StopHoldHandling();

                // 다른 방향이 눌려있어서 감지된 경우, _anyButtonDown을 true로 설정하여 다음 노트 처리 가능하게 함
                if (isDifferentDirectionPressed)
                {
                    _anyButtonDown = true;
                }

                // 새로운 노트 처리
                if (NoteManager.Instance.TryGetCurrentNote(out var note))
                {
                    switch (note.NoteType)
                    {
                        case ENoteType.MultiTapNote:
                            StartMultiTapHandling();
                            break;
                        case ENoteType.Hold:
                            CheckHoldNoteStart();
                            break;
                        default:
                            CheckTapNote();
                            break;
                    }
                }
            }
            else
            {
                // 새로운 입력이 없으면 기존 홀드 처리
                HandleHoldInput();
            }
            return;
        }

        if (AnyDirectionalInputDown())
        {
            if (NoteManager.Instance.TryGetCurrentNote(out var note))
            {
                switch (note.NoteType)
                {
                    case ENoteType.MultiTapNote:
                        StartMultiTapHandling();
                        break;
                    case ENoteType.Hold:
                        CheckHoldNoteStart();
                        break;
                    default:
                        CheckTapNote();
                        break;
                }
            }
        }
    }

    private void HandleHoldInput()
    {
        if (_currentHoldNote == null) return;

        double holdEndTime = _currentHoldNote.TargetTime + _currentHoldNote.HoldDurationTime;
        double currentTime = NoteManager.Instance.SongPosition;

        // 홀드 방향 버튼이 계속 눌려있는지 확인
        if (!IsDirectionPressed(_holdDirection))
        {
            // 홀드 종료 판정 윈도우 내에서 버튼을 뗐는지 확인
            if (NoteManager.Instance.IsWithinHoldEndWindow(currentTime, holdEndTime))
            {
                // 판정 윈도우 내에서 버튼을 떼면 홀드 종료 판정
                CompleteHoldNoteWithJudgement(holdEndTime);
            }
            else
            {
                // 판정 윈도우 밖에서 버튼을 떼면 홀드 실패 (하지만 이동은 계속됨)
                FailHoldNote();
            }
            return;
        }

        // 홀드 종료 시점 확인 (타겟 타임 + 홀드 지속 시간)
        if (currentTime >= holdEndTime)
        {
            // 홀드 성공 (버튼을 계속 누르고 있었음)
            CompleteHoldNoteWithJudgement(holdEndTime);
        }
    }

    /// 홀드 노트 종료 판정 처리 (판정 윈도우 적용)
    private void CompleteHoldNoteWithJudgement(double holdEndTime)
    {
        if (_currentHoldNote == null) return;

        double currentTime = NoteManager.Instance.SongPosition;
        bool isSuccess = NoteManager.Instance.CheckHoldNoteEnd(currentTime, holdEndTime, out EJudgement judgement);

        // 홀드 방향의 입력 상태 초기화 (다시 눌렀을 때 새로운 입력으로 인식되도록)
        if (_holdDirection != EDirectionType.None && _holdDirection != EDirectionType.Up)
        {
            _currentlyPressed.Remove(_holdDirection);
        }

        _isHoldingNote = false;
        _currentHoldNote = null;
        _holdDirection = EDirectionType.None;
    }

    private void CheckHoldNoteStart()
    {
        if (!NoteManager.Instance.TryGetCurrentNote(out Note targetNote))
            return;

        EDirectionType targetDirection = targetNote.TargetDir;

        // 타겟 방향이 눌려있으면 홀드 시작 (다른 방향이 눌려있어도 무시)
        if (IsDirectionPressed(targetDirection))
        {
            NoteManager.Instance.CheckHoldNoteStart(targetDirection, out EJudgement judgement);
            StartHoldHandling(targetNote, targetDirection);
            return; // 여기서 종료 (잘못된 방향 체크 안 함)
        }

        // 타겟 방향이 안 눌려있는 경우에만 잘못된 방향 체크
        EDirectionType wrongDirection = GetCurrentPressedDirection(targetDirection);
        if (wrongDirection != EDirectionType.None)
        {
            NoteManager.Instance.CheckHoldNoteStart(wrongDirection, out _); // Miss 처리
        }

        StartHoldHandling(targetNote, targetDirection);
    }

    private void StartHoldHandling(Note holdNote, EDirectionType direction)
    {
        _isHoldingNote = true;
        _currentHoldNote = holdNote;
        _holdDirection = direction;

        // 애니메이션 처리
        if (direction == EDirectionType.Left)
            _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.LeftJump, EJudgement.Perfect);
        else if (direction == EDirectionType.Right)
            _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.RightJump, EJudgement.Perfect);
        else if (direction == EDirectionType.Up)
        {
            bool isLeft = UnityEngine.Random.Range(0, 2) == 0;
            _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(isLeft ? EPlayerAnimState.LeftJump : EPlayerAnimState.RightJump, EJudgement.Perfect);
        }

        if (_useHitSound)
        {
            SoundManager.Instance.PlayHitSound(SoundType.SFX_HitSound);
        }

        // 홀드 이동 시작
        _owner.GetAbility<PlayerMovementAbility>().StartHoldSlide(holdNote);
    }

    /// 홀드 노트 실패 처리 (버튼을 떼었을 때, 이동은 계속됨)
    private void FailHoldNote()
    {
        _isHoldingNote = false;

        // NoteManager에 홀드 실패 알림
        NoteManager.Instance.CompleteHoldNote(false);

        // 이동은 계속되므로 StopHoldSlide 호출하지 않음

        // 홀드 방향의 입력 상태 초기화
        if (_holdDirection != EDirectionType.None && _holdDirection != EDirectionType.Up)
        {
            _currentlyPressed.Remove(_holdDirection);
        }
        else if (_holdDirection == EDirectionType.Up)
        {
            _currentlyPressed.Remove(EDirectionType.Left);
            _currentlyPressed.Remove(EDirectionType.Right);
        }

        // _currentHoldNote = null;
        _holdDirection = EDirectionType.None;
    }

    /// 홀드 노트 중단 처리 (새로운 입력이 들어왔을 때, 시간에 따라 판정)
    private void StopHoldHandling()
    {
        if (!_isHoldingNote || _currentHoldNote == null) return;

        double holdEndTime = _currentHoldNote.TargetTime + _currentHoldNote.HoldDurationTime;
        double currentTime = NoteManager.Instance.SongPosition;

        // 홀드 종료 시점과 현재 시간을 비교하여 판정
        NoteManager.Instance.CheckHoldNoteEnd(currentTime, holdEndTime, out EJudgement judgement);

        // 홀드 슬라이드 중단 (상태 초기화보다 먼저)
        _owner.GetAbility<PlayerMovementAbility>().StopHoldSlide();

        // 홀드 방향의 입력 상태 초기화
        if (_holdDirection != EDirectionType.None && _holdDirection != EDirectionType.Up)
        {
            _currentlyPressed.Remove(_holdDirection);
        }
        else if (_holdDirection == EDirectionType.Up)
        {
            _currentlyPressed.Remove(EDirectionType.Left);
            _currentlyPressed.Remove(EDirectionType.Right);
        }

        _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.Idle);
        _isHoldingNote = false;
        _currentHoldNote = null;
        _holdDirection = EDirectionType.None;
    }

    private void HandleMultiTapInput()
    {
        // 멀티탭 종료 시점 확인 (다음 노트의 타겟 타임 - 배드 윈도우)
        double multiTapEndTime = NoteManager.Instance.GetMultiTapEndTime();

        if (NoteManager.Instance.SongPosition >= multiTapEndTime)
        {
            // 종료 시점이 지나면 멀티탭 종료
            ProcessMultiTapNote();
            return;
        }

        // 종료 시점 전까지 계속 탭 가능
        if (AnyTapInputDown())
        {
            _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.MultiTapDance);

            ObjectPool.Instance.Get(EPoolType.NoteHitVfx).transform.position = transform.position;
            SoundManager.Instance.PlayHitSound(SoundType.SFX_HitSound);

            _tapCount++;
            OnMultiTap?.Invoke(_tapCount);
        }
    }

    private void CheckTapNote()
    {
        // 현재 노트의 타겟 방향이 눌려있는지 확인
        if (!NoteManager.Instance.TryGetCurrentNote(out Note targetNote))
            return;

        EDirectionType targetDirection = targetNote.TargetDir;

        // 타겟 방향이 눌려있으면 성공
        if (IsDirectionPressed(targetDirection))
        {
            ProcessTapNote(targetDirection);
        }
        else
        {
            // 타겟 방향이 안 눌려있는데 다른 방향이 눌려있으면 Miss
            EDirectionType wrongDirection = GetCurrentPressedDirection();
            if (wrongDirection != EDirectionType.None)
            {
                ProcessTapNote(wrongDirection); // NoteManager에서 Miss 처리됨
            }
        }
    }



    private EDirectionType GetCurrentPressedDirection(EDirectionType excludeDirection = EDirectionType.None)
    {

        if (IsUpPressed() && excludeDirection != EDirectionType.Up)
            return EDirectionType.Up;
        if (IsLeftPressed() && excludeDirection != EDirectionType.Left)
            return EDirectionType.Left;
        if (IsRightPressed() && excludeDirection != EDirectionType.Right)
            return EDirectionType.Right;


        return EDirectionType.None;
    }

    private void ProcessTapNote(EDirectionType direction)
    {
        if (!NoteManager.Instance.TryGetCurrentNote(out Note note))
            return;
        Note targetNote = note;

        bool isHit = NoteManager.Instance.CheckTapNote(direction, out EJudgement judgement);

        if (isHit)
        {
            if (targetNote.TargetDir == EDirectionType.Left)
                _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.LeftJump, judgement);
            else if (targetNote.TargetDir == EDirectionType.Right)
                _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.RightJump, judgement);
            else if (targetNote.TargetDir == EDirectionType.Up)
            {
                // Up 방향일 때 랜덤으로 왼쪽/오른쪽 애니메이션 선택
                bool isLeft = UnityEngine.Random.Range(0, 2) == 0;
                _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(isLeft ? EPlayerAnimState.LeftJump : EPlayerAnimState.RightJump, judgement);
            }


            if (_useHitSound)
            {
                SoundManager.Instance.PlayHitSound(SoundType.SFX_HitSound);
            }

            _owner.GetAbility<PlayerMovementAbility>().MoveToTile(targetNote);
        }
    }

    // 특정 방향이 현재 눌려있는지 확인 (다른 버튼 상태는 무시)
    private bool IsDirectionPressed(EDirectionType direction)
    {
        switch (direction)
        {
            case EDirectionType.Up:
                return IsUpPressed();
            case EDirectionType.Left:
                return IsLeftPressed();
            case EDirectionType.Right:
                return IsRightPressed();
            default:
                return false;
        }
    }

    private void StartMultiTapHandling()
    {
        if (!NoteManager.Instance.TryGetCurrentNote(out Note targetNote))
            return;

        EDirectionType targetDirection = targetNote.TargetDir;

        // 타겟 방향이 눌려있는지 확인
        if (IsDirectionPressed(targetDirection))
        {
            // 멀티탭 노트가 타겟 타임에 맞게 시작되었는지 판정
            bool isHit = NoteManager.Instance.CheckMultiTapNoteStart(targetDirection, out EJudgement judgement);

            if (!isHit)
            {
                // 타이밍이 맞지 않으면 멀티탭 시작 안 함
                return;
            }

            if (targetNote.TargetDir == EDirectionType.Left)
                _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.LeftJump, judgement);
            else if (targetNote.TargetDir == EDirectionType.Right)
                _owner.GetAbility<PlayerAnimAbility>().ChangeAnimState(EPlayerAnimState.RightJump, judgement);

            _isTappingNoteActive = true;
            _tapCount = 1;
            OnMultiTap?.Invoke(_tapCount);

            if (_useHitSound)
            {
                SoundManager.Instance.PlayHitSound(SoundType.SFX_HitSound);
            }
            _owner.GetAbility<PlayerMovementAbility>().MoveToTile(targetNote);
            _owner.GetAbility<PlayerVisualAbility>().ActiveDanceVfx();

            CameraShake.Instance.DoZoom(2.5f, 0.2f);
        }
        else
        {
            // 타겟 방향이 안 눌려있는데 다른 방향이 눌려있으면 Miss
            EDirectionType wrongDirection = GetCurrentPressedDirection();
            if (wrongDirection != EDirectionType.None)
            {
                NoteManager.Instance.CheckMultiTapNoteStart(wrongDirection, out _); // Miss 처리
            }
        }
    }

    private void StopMultiTapHandling()
    {
        _isTappingNoteActive = false;
        _tapCount = 0;
        OnMultiTapEnd?.Invoke();
        _owner.GetAbility<PlayerVisualAbility>().DeactiveDanceVfx();
        CameraShake.Instance.ResetZoom(0.2f);
    }


    private void ProcessMultiTapNote()
    {
        if (!NoteManager.Instance.TryGetCurrentNote(out Note targetNote))
            return;

        bool isHit = NoteManager.Instance.CheckMultiTapNoteEnd();

        if (isHit)
        {
            if (_useHitSound)
            {
                SoundManager.Instance.PlayHitSound(SoundType.SFX_HitSound);
            }
        }

        StopMultiTapHandling();
    }

}
