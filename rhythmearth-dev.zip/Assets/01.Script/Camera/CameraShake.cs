using UnityEngine;
using DG.Tweening;
using System.Threading;

public class CameraShake : Singleton<CameraShake>
{
    private Camera _camera;
    private float _originSize;

    private Transform _player;
    private Vector3 _shakeOffset = Vector3.zero; // 쉐이크 오프셋 (FollowCamera에서 참조)
    
    public Vector3 ShakeOffset => _shakeOffset; // 외부에서 쉐이크 오프셋을 가져올 수 있도록
    protected override void Awake()
    {

        _camera = Camera.main;
        _originSize = _camera.orthographicSize;

        _player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    public void DoZoom(float zoomValue, float duration)
    {
        _camera.DOOrthoSize(_originSize - zoomValue, duration);
    }

    public void ResetZoom(float duration)
    {
        _camera.DOOrthoSize(_originSize, duration);
    }
}
