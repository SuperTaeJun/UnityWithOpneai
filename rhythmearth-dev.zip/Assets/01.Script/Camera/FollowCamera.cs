using UnityEngine;
using DG.Tweening;

public class FollowCamera : MonoBehaviour
{
    public Transform target;

    [SerializeField] private Vector3 _offset = new Vector3(0, 4, 0); // 카메라 오프셋 (타겟보다 4만큼 위)
    [SerializeField] private float smoothTime = 0.15f; // SmoothDamp 시간

    private Vector3 _velocity = Vector3.zero;
    private Camera _camera;
    private float _originalSize;
    private bool _isZoomedIn = false;
    private Vector3 _positionBeforeZoom;
    private void OnDisable()
    {

        // 실행 중인 DOTween 애니메이션 중단
        DOTween.Kill(this);
        if (_camera != null)
        {
            _camera.DOKill();
        }
    }

    private void Start()
    {
        _camera = GetComponent<Camera>();
        if (_camera != null)
        {
            _originalSize = _camera.orthographicSize;
            Debug.Log($"[FollowCamera] 카메라 초기 크기: {_originalSize}");
        }
        else
        {
            Debug.LogError("[FollowCamera] Camera 컴포넌트를 찾을 수 없습니다!");
        }

        NoteManager.Instance.OnAllNotesCompleted += ZoomIn;
        InGameManager.Instance.OnGamePause += ZoomIn;
        InGameManager.Instance.OnGameResume += ResetZoom;
    }

    private void ZoomIn()
    {
        if (_camera != null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player == null)
            {
                Debug.LogError("[FollowCamera] Player 태그를 가진 오브젝트를 찾을 수 없습니다!");
                return;
            }

            _isZoomedIn = true;

            // 줌인 전 위치 저장
            _positionBeforeZoom = transform.position;

            float zoomValue = 5f;
            float duration = 1f;

            Vector3 centerPosition = player.transform.position;
            centerPosition.z = transform.position.z;

            transform.DOMove(centerPosition, duration).SetId(this);
            _camera.DOOrthoSize(_originalSize - zoomValue, duration).SetId(this);
        }
    }

    public void ResetZoom()
    {
        if (_camera == null) return;

        _isZoomedIn = false;

        // DOTween 애니메이션 중단
        DOTween.Kill(this);
        _camera.DOKill();

        // 원래 크기로 복구
        _camera.orthographicSize = _originalSize;

        Vector3 resetPosition = _positionBeforeZoom;
        transform.position = resetPosition;

        Debug.Log($"[FollowCamera] 줌 복구 완료 - Size: {_originalSize}, Position: {resetPosition}");
    }
    void LateUpdate()
    {
        // 줌인 상태일 때는 카메라를 가만히 유지
        if (_isZoomedIn)
        {
            return;
        }

        // target이 있고 줌인 중이 아닐 때 부드럽게 따라가기 (y값만)
        if (target != null)
        {
            Vector3 targetPosition = target.position + _offset;

            // 목표 위치가 카메라보다 아래에 있으면 이동하지 않음
            if (targetPosition.y < transform.position.y)
            {
                return;
            }

            targetPosition.x = transform.position.x; // x값 고정
            targetPosition.z = transform.position.z; // z값 고정
            transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref _velocity, smoothTime);
        }

    }
}
