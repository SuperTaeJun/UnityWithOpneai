using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class UI_JudgeText : MonoBehaviour
{
    [Header("이미지 설정")]
    [SerializeField] private Image _judgeImage;
    
    [Header("애니메이션 설정")]
    [SerializeField] private float _duration = 1f;
    private Vector3 _originScale;

    public void SetJudgeSprite(Sprite sprite)
    {
        _originScale = transform.localScale;
        
        // 스프라이트 설정
        if (_judgeImage != null && sprite != null)
        {
            _judgeImage.sprite = sprite;
        }

        // 스케일 트윈 애니메이션 (튀어오르는 효과)
        Sequence sequence = DOTween.Sequence();
        sequence.Append(transform.DOScale(_originScale * 2f, 0.2f).SetEase(Ease.OutBack))
                .Append(transform.DOScale(_originScale, 0.1f).SetEase(Ease.InOutQuad))
                .OnComplete(() => StartCoroutine(FadeOut()));
    }

    private IEnumerator FadeOut()
    {
        if (_judgeImage == null)
        {
            Destroy(gameObject);
            yield break;
        }

        float timer = 0f;
        Color startColor = _judgeImage.color;

        while (timer < _duration)
        {
            timer += Time.deltaTime;
            float alpha = Mathf.Lerp(1f, 0f, timer / _duration);
            _judgeImage.color = new Color(startColor.r, startColor.g, startColor.b, alpha);
            yield return null;
        }

        Destroy(gameObject);
    }
}
