using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_JudgeTextManager : MonoBehaviour
{
    [Header("프리팹 설정")]
    [SerializeField] private GameObject _judgeTextPrefab;
    
    [Header("스폰 위치 설정")]
    [SerializeField] private float _spawnOffsetY = -0.8f;

    [Header("판정 스프라이트 설정")]
    [SerializeField] private Sprite _perfectSprite;
    [SerializeField] private Sprite _goodSprite;
    [SerializeField] private Sprite _badSprite;
    [SerializeField] private Sprite _missSprite;

    private Transform _playerPos;
    
    void Start()
    {
        _playerPos = GameObject.FindGameObjectWithTag("Player").transform;
        
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnJudgement += SpawnJudgeText;
        }
    }

    private void OnDisable()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnJudgement -= SpawnJudgeText;
        }
    }

    private void SpawnJudgeText(EJudgement judge)
    {
        GameObject judgeTextObj = Instantiate(_judgeTextPrefab, transform);
        UI_JudgeText judgeText = judgeTextObj.GetComponent<UI_JudgeText>();

        // 플레이어 위치 아래에 고정 생성
        Vector3 spawnPos = new Vector3(_playerPos.position.x, _playerPos.position.y + _spawnOffsetY, _playerPos.position.z);

        judgeTextObj.transform.position = spawnPos;

        // 판정에 따른 스프라이트 전달
        Sprite judgeSprite = GetJudgeSprite(judge);
        judgeText.SetJudgeSprite(judgeSprite);
    }

    private Sprite GetJudgeSprite(EJudgement judgement)
    {
        switch(judgement)
        {
            case EJudgement.Perfect:
                return _perfectSprite;
            case EJudgement.Good:
                return _goodSprite;
            case EJudgement.Bad:
                return _badSprite;
            case EJudgement.Miss:
                return _missSprite;
            default:
                return null;
        }
    }

    private void OnDrawGizmos()
    {
        if (_playerPos == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player == null) return;
            _playerPos = player.transform;
        }

        // 스폰 위치 표시 (노란색)
        Gizmos.color = Color.yellow;
        Vector3 spawnPos = new Vector3(_playerPos.position.x, _playerPos.position.y + _spawnOffsetY, _playerPos.position.z);
        Gizmos.DrawWireSphere(spawnPos, 0.1f);
        Gizmos.DrawLine(_playerPos.position, spawnPos);
    }
}
