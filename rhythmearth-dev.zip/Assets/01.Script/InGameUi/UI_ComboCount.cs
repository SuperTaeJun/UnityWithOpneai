using TMPro;
using UnityEngine;
using DG.Tweening;
public class UI_ComboCount : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI _textMesh;
    [SerializeField] TextMeshProUGUI _comboText;

    [SerializeField] private float _punchStrength = 3.5f;
    [SerializeField] private float _punchDuration = 0.2f;

    [SerializeField] private float _jumpHeight = 10f; // 점프 높이
    [SerializeField] private float _jumpDuration = 0.4f; // 점프 한 번 시간
    [SerializeField] private float _jumpInterval = 0.1f; // 각 글자 간 시간 간격
    private TMP_TextInfo _cachedTextInfo;
    private Vector3[][] _originalVertices;

    private void Start()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnComboChanged += OnHit;
            NoteManager.Instance.OnMiss += OnMiss;
        }
        if (InGameManager.Instance != null)
        {
            Debug.Log("이벤트 구독");
            InGameManager.Instance.OnGamePause += OnPaaseMiss;
            InGameManager.Instance.OnGameResume += OnGameResume;
        }
        // 초기화 시 한 번만 캐싱
        _comboText.ForceMeshUpdate();
        _cachedTextInfo = _comboText.textInfo;

        // 원본 버텍스 저장
        _originalVertices = new Vector3[_cachedTextInfo.meshInfo.Length][];
        for (int i = 0; i < _cachedTextInfo.meshInfo.Length; i++)
        {
            _originalVertices[i] = _cachedTextInfo.meshInfo[i].vertices.Clone() as Vector3[];
        }
    }

    private void OnDestroy()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnComboChanged -= OnHit;
            NoteManager.Instance.OnMiss -= OnMiss;
        }
        if (InGameManager.Instance != null)
        {
            InGameManager.Instance.OnGamePause -= OnPaaseMiss;
            InGameManager.Instance.OnGameResume -= OnGameResume;
        }
    }
    private void OnPaaseMiss()
    {
        gameObject.SetActive(false);
    }
    private void OnGameResume()
    {
        gameObject.SetActive(true);
    }
    private void OnHit(int combo)
    {
        _textMesh.text = combo.ToString();
        _textMesh.transform.DOKill();
        _textMesh.transform.localScale = Vector3.one;
        _textMesh.transform.DOPunchScale(Vector3.one * _punchStrength, _punchDuration);
    }

    private void OnMiss(Note note)
    {
        _textMesh.text = "0";
        _textMesh.transform.DOKill();
        _textMesh.transform.localScale = Vector3.one;
        _textMesh.transform.DOPunchScale(Vector3.one * _punchStrength, _punchDuration);
    }
    private void Update()
    {
        AnimateComboTextJump();
    }
    private void AnimateComboTextJump()
    {
        for (int i = 0; i < _cachedTextInfo.characterCount; i++)
        {
            if (!_cachedTextInfo.characterInfo[i].isVisible) continue;

            int materialIndex = _cachedTextInfo.characterInfo[i].materialReferenceIndex;
            int vertexIndex = _cachedTextInfo.characterInfo[i].vertexIndex;

            Vector3[] vertices = _cachedTextInfo.meshInfo[materialIndex].vertices;

            // 각 글자마다 시간 오프셋 적용
            float timeOffset = i * _jumpInterval;
            float currentTime = (Time.time + timeOffset) % (_jumpDuration * _cachedTextInfo.characterCount);

            // 해당 글자의 점프 사이클 시간
            float charCycleTime = currentTime % _jumpDuration;
            float normalizedTime = charCycleTime / _jumpDuration; // 0~1

            // 포물선 점프 (위로 갔다가 다시 내려옴)
            // Ease.OutQuad 느낌: 빠르게 올라갔다가 천천히 내려옴
            float yOffset = 0f;
            if (normalizedTime < 0.5f)
            {
                // 올라가는 구간 (0 → 1)
                float t = normalizedTime * 2f; // 0~1로 정규화
                yOffset = Mathf.Lerp(0f, _jumpHeight, 1f - (1f - t) * (1f - t)); // EaseOut
            }
            else
            {
                // 내려오는 구간 (1 → 0)
                float t = (normalizedTime - 0.5f) * 2f; // 0~1로 정규화
                yOffset = Mathf.Lerp(_jumpHeight, 0f, t * t); // EaseIn
            }

            // 원본 위치에서 오프셋 적용
            for (int j = 0; j < 4; j++)
            {
                vertices[vertexIndex + j] = _originalVertices[materialIndex][vertexIndex + j];
                vertices[vertexIndex + j].y += yOffset;
            }
        }

        // 메시 업데이트
        for (int i = 0; i < _cachedTextInfo.meshInfo.Length; i++)
        {
            _cachedTextInfo.meshInfo[i].mesh.vertices = _cachedTextInfo.meshInfo[i].vertices;
            _comboText.UpdateGeometry(_cachedTextInfo.meshInfo[i].mesh, i);
        }
    }
}
