using TMPro;
using UnityEngine;

public class UI_ScoreText : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI _scoreText;

    private int _currentDisplayScore = 0; // 현재 화면에 표시되는 점수
    private int _targetScore = 0; // 목표 점수
    private float _animationDuration = 0.4f; // 목표 점수까지 도달하는 시간 (초)
    private float _elapsedTime = 0f; // 경과 시간
    private int _startScore = 0; // 애니메이션 시작 점수

    private void Start()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnScoreChanged += OnScoreChanged;
        }

        if (InGameManager.Instance != null)
        {
            InGameManager.Instance.OnGamePause += OnPauseMiss;
            InGameManager.Instance.OnGameResume += OnGameResume;
        }
        UpdateScoreDisplay(_currentDisplayScore);

    }

    private void OnDestroy()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnScoreChanged -= OnScoreChanged;
        }
        if (InGameManager.Instance != null)
        {
            InGameManager.Instance.OnGamePause -= OnPauseMiss;
            InGameManager.Instance.OnGameResume -= OnGameResume;
        }
    }
    private void OnGameResume()
    {
        gameObject.SetActive(true);
    }
    private void OnPauseMiss()
    {
        gameObject.SetActive(false);
    }
    private void Update()
    {
        // 현재 표시 점수가 목표 점수와 다르면 0.2초 동안 보간
        if (_currentDisplayScore != _targetScore)
        {
            _elapsedTime += Time.deltaTime;

            // 0.2초 동안 시작 점수에서 목표 점수까지 선형 보간
            float t = Mathf.Clamp01(_elapsedTime / _animationDuration);
            _currentDisplayScore = Mathf.RoundToInt(Mathf.Lerp(_startScore, _targetScore, t));

            UpdateScoreDisplay(_currentDisplayScore);
        }
    }

    private void OnScoreChanged(int newScore)
    {
        _startScore = _currentDisplayScore; // 현재 점수를 시작점으로 설정
        _targetScore = newScore;
        _elapsedTime = 0f; // 타이머 리셋
    }

    private void UpdateScoreDisplay(int score)
    {
        if (_scoreText != null)
        {
            _scoreText.text = score.ToString("N0"); // 천 단위 구분 기호 포함
        }
    }
}
