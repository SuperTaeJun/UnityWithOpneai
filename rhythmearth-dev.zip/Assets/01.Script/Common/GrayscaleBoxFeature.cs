using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

// 1. 렌더 패스 (실제 작업)
public class GrayscaleBoxPass : ScriptableRenderPass
{
    private Material grayscaleMaterial;

    // 생성자: 사용할 머티리얼을 받아옵니다.
    public GrayscaleBoxPass(Material material)
    {
        this.grayscaleMaterial = material;
        // 포스트 프로세싱 직전에 실행되도록 설정
        this.renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
    }

    // !! 수정됨 !! : Setup 함수는 더 이상 필요 없으므로 삭제합니다.

    // 매 프레임 실제 렌더링이 일어나는 곳
    public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
    {
        // 머티리얼이 없으면 중단
        if (grayscaleMaterial == null) return;
        
        // 카메라가 Post Processing을 사용하지 않으면 중단
        if (!renderingData.cameraData.postProcessEnabled) return;

        // !! 수정됨 !! : 
        // 렌더 타겟(source)을 Feature에서 받아오는 대신 Execute 내부에서 직접 가져옵니다.
        // 에러 메시지가 말한 "ScriptableRenderPass의 스코프"가 바로 여기입니다.
        RTHandle source = renderingData.cameraData.renderer.cameraColorTargetHandle;

        CommandBuffer cmd = CommandBufferPool.Get("GrayscaleBoxEffect");

        // 카메라 타겟 디스크립터 가져오기
        RenderTextureDescriptor descriptor = renderingData.cameraData.cameraTargetDescriptor;
        descriptor.depthBufferBits = 0; // 깊이 버퍼 불필요
        
        // 임시 렌더 텍스처 ID 생성
        int tempTextureID = Shader.PropertyToID("_TempGrayscaleTexture");
        cmd.GetTemporaryRT(tempTextureID, descriptor);
        
        // source를 grayscaleMaterial로 처리해서 임시 텍스처에 씁니다.
        cmd.Blit(source, tempTextureID, grayscaleMaterial, 0);
        // 다시 임시 텍스처를 source로 복사
        cmd.Blit(tempTextureID, source);
        
        context.ExecuteCommandBuffer(cmd);
        CommandBufferPool.Release(cmd);
        
        // 임시 렌더 텍스처 해제
        cmd.ReleaseTemporaryRT(tempTextureID);
    }
}


// 2. 렌더 피처 (패스 관리자)
[CreateAssetMenu(menuName = "Rendering/GrayscaleBoxFeature")]
public class GrayscaleBoxFeature : ScriptableRendererFeature
{
    // 인스펙터에서 흑백 머티리얼을 할당받을 슬롯
    public Material grayscaleMaterial;
    
    private GrayscaleBoxPass grayscalePass;

    // 렌더러가 생성될 때 호출됨
    public override void Create()
    {
        if (grayscaleMaterial != null)
        {
            grayscalePass = new GrayscaleBoxPass(grayscaleMaterial);
        }
    }

    // 매 프레임 렌더러에 이 Pass를 추가할 때 호출됨
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if (grayscalePass == null || grayscaleMaterial == null)
        {
            return;
        }

        // !! 수정됨 !! : 
        // 여기서 cameraColorTarget을 호출하는 것이 에러의 원인이었습니다.
        // grayscalePass.Setup(...) 호출을 삭제합니다.
        
        // 렌더러 큐에 우리가 만든 Pass를 추가
        renderer.EnqueuePass(grayscalePass);
    }
}
