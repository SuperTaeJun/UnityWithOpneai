//싱글톤 매니저들이 구현하는 리셋 인터페이스
public interface IResettable
{
void ResetManager();
}
