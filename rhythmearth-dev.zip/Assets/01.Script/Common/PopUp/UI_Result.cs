using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

/// 게임 결과를 표시하는 팝업
public class UI_Result : UI_Popup
{
    [Header("Result Display")]
    [SerializeField] private TextMeshProUGUI _scoreText;
    [SerializeField] private TextMeshProUGUI _gradeText;
    [SerializeField] private TextMeshProUGUI _accuracyText;
    [SerializeField] private TextMeshProUGUI _comboText;

    [Header("Judgement Counts")]
    [SerializeField] private TextMeshProUGUI _perfectCountText;
    [SerializeField] private TextMeshProUGUI _goodCountText;
    [SerializeField] private TextMeshProUGUI _badCountText;
    [SerializeField] private TextMeshProUGUI _missCountText;

    [Header("Buttons")]
    [SerializeField] private Button _retryButton;
    [SerializeField] private Button _lobbyButton;
    [SerializeField] private Button _closeButton;

    private int _currentScore;
    private string _grade;
    private float _accuracy;
    private int _maxCombo;
    private int _perfectCount;
    private int _goodCount;
    private int _badCount;
    private int _missCount;

    protected override void Awake()
    {
        base.Awake();

        // 버튼 이벤트 연결
        if (_retryButton != null)
            _retryButton.onClick.AddListener(OnRetryClicked);

        if (_lobbyButton != null)
            _lobbyButton.onClick.AddListener(OnLobbyClicked);

        if (_closeButton != null)
            _closeButton.onClick.AddListener(Close);
    }

    public override void Open(System.Action callback = null)
    {
        // NoteManager에서 결과 데이터 가져오기
        if (NoteManager.Instance != null)
        {
            _currentScore = NoteManager.Instance.GetCurrentScore();
            _grade = NoteManager.Instance.GetGrade();
            _accuracy = NoteManager.Instance.GetAccuracy();
            _maxCombo = NoteManager.Instance.GetMaxCombo();
            _perfectCount = NoteManager.Instance.GetPerfectCount();
            _goodCount = NoteManager.Instance.GetGoodCount();
            _badCount = NoteManager.Instance.GetBadCount();
            _missCount = NoteManager.Instance.GetMissCount();
        }
        else
        {
            Debug.LogWarning("NoteManager를 찾을 수 없습니다!");
        }

        // UI 업데이트
        UpdateUI();

        base.Open(callback);
    }

    private void UpdateUI()
    {
        // 점수 표시
        if (_scoreText != null)
            _scoreText.text = $"Score: {_currentScore:N0}";

        // 등급 표시
        if (_gradeText != null)
        {
            _gradeText.text = $"Grade: {_grade}";

            // 등급에 따른 색상 변경
            _gradeText.color = _grade switch
            {
                "S" => new Color(1f, 0.84f, 0f),      // 금색
                "A" => new Color(0.5f, 1f, 0.5f),     // 연두색
                "B" => new Color(0.3f, 0.7f, 1f),     // 하늘색
                "C" => new Color(1f, 0.7f, 0.3f),     // 주황색
                "D" => new Color(1f, 0.5f, 0.5f),     // 연분홍색
                _ => new Color(0.7f, 0.7f, 0.7f)      // 회색
            };
        }

        // 정확도 표시
        if (_accuracyText != null)
            _accuracyText.text = $"Accuracy: {_accuracy:F2}%";

        // 최대 콤보 표시
        if (_comboText != null)
            _comboText.text = $"Max Combo: {_maxCombo}";

        // 판정 횟수 표시
        if (_perfectCountText != null)
            _perfectCountText.text = $"Perfect: {_perfectCount}";

        if (_goodCountText != null)
            _goodCountText.text = $"Good: {_goodCount}";

        if (_badCountText != null)
            _badCountText.text = $"Bad: {_badCount}";

        if (_missCountText != null)
            _missCountText.text = $"Miss: {_missCount}";
    }

    private void OnRetryClicked()
    {
        Debug.Log("재시도 버튼 클릭");

        // 현재 씬 다시 로드
        //Close();
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    private void OnLobbyClicked()
    {
        Debug.Log("로비로 이동 버튼 클릭");

        // 로비 씬으로 이동
        Close();

        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.DestroyManager();
        }

        if (ObjectPool.Instance != null)
        {
            ObjectPool.Instance.DestroyManager();
        }

        // 씬 전환 후 매니저 파괴 (콜백 사용)
        FadeManager.Instance.FadeToScene("LobyScene");
    }

    private void OnDestroy()
    {
        // 버튼 이벤트 해제
        if (_retryButton != null)
            _retryButton.onClick.RemoveListener(OnRetryClicked);

        if (_lobbyButton != null)
            _lobbyButton.onClick.RemoveListener(OnLobbyClicked);

        if (_closeButton != null)
            _closeButton.onClick.RemoveListener(Close);
    }
}
