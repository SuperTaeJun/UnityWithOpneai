using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.UI;

public class UI_Pause : UI_Popup
{
    [SerializeField] private Button _continueButton;
    [SerializeField] private Button _lobyButton;
    [SerializeField] private Button _restartButton;

    void Start()
    {

    }
    private void OnEnable()
    {
        _continueButton.onClick.AddListener(OnClickContinueButton);
        _lobyButton.onClick.AddListener(OnClickLobyButton);
        _restartButton.onClick.AddListener(OnClickRestartButton);
    }
    private void OnDisable()
    {
        _continueButton.onClick.RemoveListener(OnClickContinueButton);
        _lobyButton.onClick.RemoveListener(OnClickLobyButton);
        _restartButton.onClick.RemoveListener(OnClickRestartButton);
    }
    private void OnClickContinueButton()
    {
        InGameManager.Instance.ResumeGame();
        Close();
    }
    private void OnClickLobyButton()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.DestroyManager();
        }

        if (ObjectPool.Instance != null)
        {
            ObjectPool.Instance.DestroyManager();
        }

        Close();
        FadeManager.Instance.FadeToScene("LobyScene");
    }
    private void OnClickRestartButton()
    {
        InGameManager.Instance.RestartGame();
        Close();
    }
}
