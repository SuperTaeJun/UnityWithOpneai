using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UI_Exit : UI_Popup
{
    [SerializeField] private Button _exitButton;

    private void OnEnable()
    {
        _exitButton.onClick.AddListener(() =>
        {
            Close();
            
            Debug.Log("로비 씬으로 이동합니다...");

        });
    }

    private void OnDisable()
    {
        _exitButton.onClick.RemoveAllListeners();
    }
}
