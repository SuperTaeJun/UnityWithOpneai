using System;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UI_Popup : MonoBehaviour
{
    public Action _closeCallback;
    
    private Canvas _canvas;
    private GraphicRaycaster _raycaster;
    private CanvasScaler _canvasScaler;

    protected virtual void Awake()
    {
        // Canvas 컴포넌트 확인 및 추가
        _canvas = GetComponent<Canvas>();
        if (_canvas == null)
        {
            _canvas = gameObject.AddComponent<Canvas>();
            _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        }

        // GraphicRaycaster 확인 및 추가
        _raycaster = GetComponent<GraphicRaycaster>();
        if (_raycaster == null)
        {
            _raycaster = gameObject.AddComponent<GraphicRaycaster>();
        }

        // CanvasScaler 확인 및 추가
        _canvasScaler = GetComponent<CanvasScaler>();
        if (_canvasScaler == null)
        {
            _canvasScaler = gameObject.AddComponent<CanvasScaler>();
            _canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            _canvasScaler.referenceResolution = new Vector2(1920, 1080);
            _canvasScaler.matchWidthOrHeight = 0.5f;
        }
    }

    public virtual void Open(Action callback = null)
    {
        _closeCallback = callback;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        // Stack 순서에 따라 Canvas Sort Order 설정
        if (_canvas != null)
        {
            _canvas.sortingOrder = PopupManager.Instance.OpenPopups.Count * 10;
        }

        gameObject.transform.DOKill();
        gameObject.SetActive(true);
        gameObject.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
        gameObject.transform.DOScale(1f, 0.2f).SetEase(Ease.OutCirc).SetUpdate(true);
    }

    public virtual void Close()
    {
        _closeCallback?.Invoke();

        PopupManager.Instance.PopUpClose();

        gameObject.transform.DOKill();
        gameObject.transform.DOScale(0f, 0.2f).SetEase(Ease.OutCirc).OnComplete(() =>
        {
            gameObject.SetActive(false);
        });
    }
}
