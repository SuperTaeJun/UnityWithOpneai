using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ParallaxLayer
{
    [Tooltip("배경 (3개)")]
    public Transform[] backgrounds;
    
    [Tooltip("원근감 속도 (0~1, 1이 카메라와 동일 속도, 0에 가까울수록 느림)")]
    [Range(0f, 1f)]
    public float parallaxSpeed = 1f;
    
    [HideInInspector]
    public float backgroundHeight;
    
    [HideInInspector]
    public float loopHeight;
}

public class InfiniteScroll : MonoBehaviour
{
    [SerializeField] private ParallaxLayer[] parallaxLayers;

    private Transform cameraTransform; // 메인 카메라의 Transform
    private Vector3 lastCameraPosition; // 이전 프레임의 카메라 위치

    void Start()
    {
        if (parallaxLayers == null || parallaxLayers.Length == 0)
        {
            Debug.LogError("Parallax 레이어가 설정되지 않았습니다!");
            return;
        }

        cameraTransform = Camera.main.transform;
        lastCameraPosition = cameraTransform.position;

        // 각 레이어 초기화
        foreach (ParallaxLayer layer in parallaxLayers)
        {
            if (layer.backgrounds == null || layer.backgrounds.Length < 3)
            {
                Debug.LogError("레이어의 배경 이미지 3개가 모두 할당되지 않았습니다!");
                continue;
            }

            SpriteRenderer sr = layer.backgrounds[0].GetComponent<SpriteRenderer>();
            if (sr == null)
            {
                Debug.LogError("배경 오브젝트에 SpriteRenderer가 없습니다.");
                continue;
            }

            layer.backgroundHeight = sr.sprite.bounds.size.y;
            layer.loopHeight = layer.backgroundHeight * layer.backgrounds.Length;
        }
    }

    void Update()
    {
        if (parallaxLayers == null || parallaxLayers.Length == 0) return;

        // 카메라 이동량 계산
        Vector3 cameraDelta = cameraTransform.position - lastCameraPosition;
        
        // 각 레이어에 대해 parallax 효과 적용
        foreach (ParallaxLayer layer in parallaxLayers)
        {
            if (layer.backgrounds == null || layer.backgrounds.Length < 3) continue;

            // Parallax 속도에 따라 배경 이동
            Vector3 parallaxMovement = cameraDelta * layer.parallaxSpeed;
            
            foreach (Transform bg in layer.backgrounds)
            {
                bg.position += parallaxMovement;
            }

            // 무한 스크롤을 위한 재배치 로직
            float cameraY = cameraTransform.position.y;
            
            // 카메라가 위로 올라갈 때 (아래쪽 배경을 위로)
            float bottomTrigger = cameraY - (layer.backgroundHeight * 1.5f);
            
            foreach (Transform bg in layer.backgrounds)
            {
                if (bg.position.y < bottomTrigger)
                {
                    bg.position += new Vector3(0, layer.loopHeight, 0);
                }
            }

            // 카메라가 아래로 내려갈 때 (위쪽 배경을 아래로)
            float topTrigger = cameraY + (layer.backgroundHeight * 1.5f);
            
            foreach (Transform bg in layer.backgrounds)
            {
                if (bg.position.y > topTrigger)
                {
                    bg.position += new Vector3(0, -layer.loopHeight, 0);
                }
            }
        }

        // 현재 카메라 위치 저장
        lastCameraPosition = cameraTransform.position;
    }
}
