using System;
using System.Collections.Generic;
using UnityEngine;

public enum EPoolType
{
    TapTile,
    MultiTapTile,
    HoldTile,
    HoldTapTile,
    MirroTile,

    NoteHitVfx,
    NoteLandVfx,
    HoldTapNoteHitVfx,

    GhostTapTile,
    DoubleTapTile,
    
}

[Serializable]
public class Pool
{
    public EPoolType type;
    public GameObject prefab;
    public int size;
}

public class ObjectPool : PersistentSingleton<ObjectPool>, IResettable
{
    [SerializeField]
    private List<Pool> _pools;
    private Dictionary<EPoolType, Queue<GameObject>> _poolDictionary;
    private Dictionary<GameObject, EPoolType> _pooledObjectType;
    private Transform _parentTransform;
    private bool _isInitialized = false;

    public bool IsInitialized => _isInitialized;

    protected override void Awake()
    {
        base.Awake(); // PersistentSingleton의 Awake 호출
        _parentTransform = transform;
        // InitializePools()는 LoadingManager에서 수동으로 호출
    }

    public void InitializePools()
    {
        _poolDictionary = new Dictionary<EPoolType, Queue<GameObject>>();
        _pooledObjectType = new Dictionary<GameObject, EPoolType>();

        foreach (Pool pool in _pools)
        {
            Queue<GameObject> objectPool = new Queue<GameObject>();
            _poolDictionary.Add(pool.type, objectPool);

            for (int i = 0; i < pool.size; i++)
            {
                GameObject obj = CreateNewObject(pool.prefab, pool.type);
                Return(obj);
            }
        }

        _isInitialized = true;
        Debug.Log("ObjectPool 초기화 완료");
    }

    private GameObject CreateNewObject(GameObject prefab, EPoolType type)
    {
        GameObject newObj = Instantiate(prefab);
        newObj.transform.SetParent(_parentTransform);
        _pooledObjectType.Add(newObj, type);
        return newObj;
    }

    public GameObject Get(EPoolType type)
    {
        if (!_poolDictionary.ContainsKey(type))
        {
            return null;
        }

        Queue<GameObject> poolQueue = _poolDictionary[type];
        GameObject objToGet;

        if (poolQueue.Count > 0)
        {
            objToGet = poolQueue.Dequeue();
        }
        else
        {
            Pool pool = _pools.Find(p => p.type == type);
            objToGet = CreateNewObject(pool.prefab, type);
        }

        objToGet.SetActive(true);
        return objToGet;
    }

    public T Get<T>(EPoolType type) where T : Component
    {
        GameObject obj = Get(type);
        if (obj == null) return null;

        T component = obj.GetComponent<T>();
        if (component == null)
        {
            Return(obj);
            return null;
        }

        return component;
    }

    public void Return(GameObject obj)
    {
        if (!_pooledObjectType.TryGetValue(obj, out EPoolType type))
        {
            Destroy(obj);
            return;
        }

        if (!_poolDictionary.ContainsKey(type))
        {
            Destroy(obj);
            return;
        }

        obj.SetActive(false);
        _poolDictionary[type].Enqueue(obj);
    }

    /// ObjectPool을 파괴하기 전에 모든 풀링된 오브젝트를 먼저 파괴
    public new void DestroyManager()
    {
        Debug.Log("[ObjectPool] 모든 풀링된 오브젝트를 파괴합니다.");

        // 부모 클래스의 DestroyManager 호출
        base.DestroyManager();
    }

    public void ResetManager()
    {
        // 모든 풀링된 오브젝트를 비활성화하고 풀로 반환
        foreach (var objPair in _pooledObjectType)
        {
            GameObject obj = objPair.Key;
            if (obj != null && obj.activeSelf)
            {
                Return(obj);  // Return 메서드가 SetActive(false)와 Enqueue를 처리
            }
        }
    }
}
