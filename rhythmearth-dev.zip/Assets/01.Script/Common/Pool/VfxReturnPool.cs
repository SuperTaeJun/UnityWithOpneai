using System.Collections;
using UnityEngine;

public class VfxReturnPool : MonoBehaviour
{
    private ParticleSystem[] _particleSystems;
    private float _maxDuration;
    private float _returnDelay = 0.1f; // 추가 대기 시간

    private void Awake()
    {
        // 자신과 모든 하위 오브젝트의 ParticleSystem을 가져옴
        _particleSystems = GetComponentsInChildren<ParticleSystem>();
        
        if (_particleSystems == null || _particleSystems.Length == 0)
        {
            Debug.LogWarning($"VfxReturnPool: ParticleSystem이 {gameObject.name}에 없습니다!");
            return;
        }

        // 가장 긴 재생 시간을 미리 계산 (성능 최적화)
        _maxDuration = 0f;
        foreach (ParticleSystem ps in _particleSystems)
        {
            if (ps != null)
            {
                float duration = ps.main.duration + ps.main.startLifetime.constantMax;
                if (duration > _maxDuration)
                {
                    _maxDuration = duration;
                }
            }
        }
    }

    private void OnEnable()
    {
        if (_particleSystems != null && _particleSystems.Length > 0)
        {
            StartCoroutine(ReturnToPoolWhenFinished());
        }
    }

    private IEnumerator ReturnToPoolWhenFinished()
    {
        // 계산된 최대 재생 시간만큼 대기 (매 프레임 체크 없이 효율적)
        yield return new WaitForSeconds(_maxDuration + _returnDelay);

        // ObjectPool로 반환
        if (ObjectPool.Instance != null)
        {
            ObjectPool.Instance.Return(gameObject);
        }
        else
        {
            Debug.LogWarning("VfxReturnPool: ObjectPool.Instance가 null입니다!");
            gameObject.SetActive(false);
        }
    }

    private void OnDisable()
    {
        // 코루틴 정리
        StopAllCoroutines();
    }
}
