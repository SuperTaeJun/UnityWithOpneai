using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteAlways]
public class GrayscaleBoxController : MonoBehaviour
{
    public SpriteRenderer boxRenderer;
    public Material grayscaleMaterial;

    void Update()
    {
        Camera cam = Camera.main;
        if (!cam || !boxRenderer || !grayscaleMaterial) return;

        // 박스의 네 꼭짓점 계산
        Vector3 worldMin = boxRenderer.bounds.min;
        Vector3 worldMax = boxRenderer.bounds.max;

        // 뷰포트 좌표 변환
        Vector3 minVP = cam.WorldToViewportPoint(worldMin);
        Vector3 maxVP = cam.WorldToViewportPoint(worldMax);

        // 값 클램프 (0~1 범위)
        minVP.x = Mathf.Clamp01(minVP.x);
        minVP.y = Mathf.Clamp01(minVP.y);
        maxVP.x = Mathf.Clamp01(maxVP.x);
        maxVP.y = Mathf.Clamp01(maxVP.y);

        grayscaleMaterial.SetVector("_BoxMin", new Vector4(minVP.x, minVP.y, 0, 0));
        grayscaleMaterial.SetVector("_BoxMax", new Vector4(maxVP.x, maxVP.y, 0, 0));
    }
}
