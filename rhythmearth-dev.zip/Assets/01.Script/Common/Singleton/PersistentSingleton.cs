using UnityEngine;


/// 씬 전환 시에도 파괴되지 않으며 (DontDestroyOnLoad),
/// 필요시 수동 파괴도 가능한 제네릭 싱글톤 클래스입니다.

public class PersistentSingleton<T> : MonoBehaviour where T : MonoBehaviour
{
    private static T _instance;

    public static T Instance
    {
        get
        {
            return _instance;
        }
    }

    /// 이 싱글톤 오브젝트가 Awake될 때 호출됩니다.
    protected virtual void Awake()
    {
        if (_instance == null)
        {
            // 이 오브젝트를 static 인스턴스로 설정
            _instance = this as T;

            // 씬 전환 시 파괴되지 않도록 설정
            DontDestroyOnLoad(this.gameObject);
        }
        else if (_instance != this)
        {
            Debug.LogWarning($"[PersistentSingleton] {typeof(T)}의 중복 인스턴스 발견. " + $"({this.gameObject.name}) 파괴.");
            Destroy(this.gameObject);
        }
    }

    protected virtual void OnDestroy()
    {
        if (_instance == this)
        {
            _instance = null;
        }
    }

    public void DestroyManager()
    {
        Debug.Log($"[PersistentSingleton] {gameObject.name}을(를) 수동으로 파괴합니다.");
        
        // 먼저 static 인스턴스를 null로 설정하여 새로운 인스턴스 생성 방지
        if (_instance == this)
        {
            _instance = null;
        }
        
        if (gameObject != null)
        {
            Destroy(gameObject);
        }
    }
}
