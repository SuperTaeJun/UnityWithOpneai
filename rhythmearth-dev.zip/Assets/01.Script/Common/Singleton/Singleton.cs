using UnityEngine;
/// 씬(Scene) 내에서만 유일성이 보장되는 기본 싱글톤 클래스입니다.
/// 씬이 변경되면 파괴됩니다.
public class Singleton<T> : MonoBehaviour where T : MonoBehaviour
{
    private static T _instance;
    public static T Instance
    {
        get
        {

            if (_instance == null)
            {
                // 씬에서 인스턴스를 찾습니다.
                _instance = FindObjectOfType<T>();

                // 씬에 여러 개 있는지 확인
                if (FindObjectsOfType<T>().Length > 1)
                {
                    Debug.LogError($"[Singleton] {typeof(T)} 타입의 인스턴스가 씬에 여러 개 존재합니다.");
                }
            }
            return _instance;

        }
    }

    /// <summary>
    /// 이 싱글톤 오브젝트가 Awake될 때 호출됩니다.
    /// </summary>
    protected virtual void Awake()
    {
        if (_instance != null && _instance != this)
        {
            // 씬에 이미 다른 인스턴스가 존재하면 이 오브젝트는 파괴
            Debug.LogWarning($"[Singleton] {typeof(T)}의 중복 인스턴스 발견. ({this.gameObject.name}) 파괴.");
            Destroy(this.gameObject);
        }
        else
        {
            // 첫 번째 인스턴스인 경우, static 변수에 할당
            _instance = this as T;
        }
    }

    /// <summary>
    /// 씬이 파괴될 때 static 참조도 클리어해줍니다.
    /// </summary>
    protected virtual void OnDestroy()
    {
        if (_instance == this)
        {
            _instance = null;
        }
    }
}