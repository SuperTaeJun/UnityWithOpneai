using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using DG.Tweening;

public enum SoundType
{
    SFX_HitSound,
}

[Serializable]
public class SoundClipData
{
    public SoundType soundType;
    public AudioClip audioClip;
}
public class SoundManager : PersistentSingleton<SoundManager>
{

    [Header("Audio Sources (Assign in Inspector)")]
    [SerializeField] private AudioSource bgmSource; // BGM 전용 오디오 소스

    [Header("SFX Pool Settings")]
    [SerializeField] private int sfxPoolSize = 10; // SFX용 오디오 소스 풀 크기
    [SerializeField] private AudioMixer _audioMixer;

    [Header("Sound Clips")]

    [SerializeField] private List<SoundClipData> soundClipList = new List<SoundClipData>();

    private Dictionary<SoundType, AudioClip> soundClips = new Dictionary<SoundType, AudioClip>();
    private List<AudioSource> sfxSourcePool = new List<AudioSource>(); // SFX 오디오 소스 풀
    private int currentSfxIndex = 0; // 현재 사용할 풀 인덱스
    private double bgmStartTime; // dspTime 기준으로 BGM이 시작된 정확한 시간
    [SerializeField] private AudioLowPassFilter _bgmLowPassFilter;
    protected override void Awake()
    {
        base.Awake();

        if (bgmSource == null)
        {
            Debug.LogError("BGM Source가 할당되지 않았습니다!");
        }

        // --- 오디오 소스 초기 설정 ---
        if (bgmSource != null)
        {
            bgmSource.playOnAwake = false; // 자동으로 재생되지 않게 설정
            bgmSource.loop = false;         // 리듬 게임 BGM은 보통 루프하지 않음
        }

        // --- SFX 오디오 소스 풀 생성 ---
        InitializeSfxPool();

        // --- Dictionary 초기화 ---
        InitializeSoundClips();
    }
    private void InitializeSfxPool()
    {
        sfxSourcePool.Clear();

        // AudioMixer에서 SFX 그룹 가져오기
        AudioMixerGroup[] groups = _audioMixer.FindMatchingGroups("Sfx");
        AudioMixerGroup sfxGroup = groups.Length > 0 ? groups[0] : null;

        if (sfxGroup == null)
        {
            Debug.LogWarning("AudioMixer에서 'SFX' 그룹을 찾을 수 없습니다!");
        }

        for (int i = 0; i < sfxPoolSize; i++)
        {
            GameObject sfxObj = new GameObject($"SFX_AudioSource_{i}");
            sfxObj.transform.SetParent(transform);

            AudioSource source = sfxObj.AddComponent<AudioSource>();
            source.playOnAwake = false;
            source.loop = false;
            source.priority = 0; // 최고 우선순위 (0-256, 낮을수록 높은 우선순위)
            source.ignoreListenerPause = true; // 일시정지 무시
            source.ignoreListenerVolume = false;

            // SFX AudioMixerGroup 할당
            if (sfxGroup != null)
            {
                source.outputAudioMixerGroup = sfxGroup;
            }

            sfxSourcePool.Add(source);
        }

        Debug.Log($"SFX 오디오 소스 풀 생성 완료: {sfxPoolSize}개");
    }

    private void InitializeSoundClips()
    {
        soundClips.Clear();
        foreach (var data in soundClipList)
        {
            if (data.audioClip != null)
            {
                if (!soundClips.ContainsKey(data.soundType))
                {
                    soundClips.Add(data.soundType, data.audioClip);
                }
                else
                {
                    Debug.LogWarning($"중복된 SoundType이 발견되었습니다: {data.soundType}");
                }
            }
        }
    }

    private AudioSource GetAvailableSfxSource()
    {
        AudioSource source = sfxSourcePool[currentSfxIndex];
        currentSfxIndex = (currentSfxIndex + 1) % sfxSourcePool.Count;

        // 현재 재생 중이면 강제로 정지 (새로운 사운드 우선)
        if (source.isPlaying)
        {
            source.Stop();
        }

        return source;
    }

    public void StopBGM()
    {
        if (bgmSource != null)
        {
            bgmSource.Stop();
            //bgmSource.clip = null;
        }
        bgmStartTime = 0;

        Debug.Log("BGM 정지 및 초기화");
    }
    public void PlayBGMFromTime(double startTime,float fadeInDuration = 1.0f)
    {
        if (bgmSource == null || bgmSource.clip == null)
        {
            Debug.LogError("BGM Source 또는 Clip이 없습니다!");
            return;
        }

        bgmSource.DOKill(); // 기존 트윈 중단

        if (_bgmLowPassFilter != null)
        {
            _bgmLowPassFilter.cutoffFrequency = 22000f;
        }

        // 시작 시간이 음수면 0으로 설정
        startTime = Math.Max(0, startTime);

        // 클립 길이를 초과하지 않도록 제한
        if (startTime >= bgmSource.clip.length)
        {
            startTime = 0;
        }

        // AudioSource의 재생 위치 설정
        bgmSource.time = (float)startTime;

        // DSP Time 기준으로 bgmStartTime 조정
        bgmStartTime = AudioSettings.dspTime - startTime;

        // 볼륨 0에서 시작
        bgmSource.volume = 0f;
        bgmSource.Play();

        // 페이드인 효과 (0 → 1.0)
        bgmSource.DOFade(1.0f, fadeInDuration).SetEase(Ease.InOutQuad);

        Debug.Log($"BGM을 {startTime}초부터 페이드인({fadeInDuration}초)으로 재생");
    }
    /// Resources 경로에서 AudioClip을 로드하여 BGM 재생
    public void PlayBGM(string audioClipPath, double startDelay = 0f)
    {
        if (bgmSource == null)
        {
            Debug.LogError("BGM Source가 할당되지 않았습니다!");
            return;
        }

        if (string.IsNullOrEmpty(audioClipPath))
        {
            Debug.LogError("AudioClip 경로가 비어있습니다!");
            return;
        }

        // Resources 폴더에서 AudioClip 로드
        AudioClip clip = Resources.Load<AudioClip>(audioClipPath);

        if (clip == null)
        {
            Debug.LogError($"AudioClip을 찾을 수 없습니다: {audioClipPath}");
            return;
        }
        bgmSource.DOKill();

        if (_bgmLowPassFilter != null)
        {
            _bgmLowPassFilter.cutoffFrequency = 22000f;
        }

        bgmSource.volume = 1.0f; // 또는 원하는 기본 볼륨 값
        // BGM Source에 클립 할당
        bgmSource.clip = clip;

        // 예약 재생
        bgmStartTime = AudioSettings.dspTime + startDelay;
        bgmSource.PlayScheduled(bgmStartTime);

        Debug.Log($"BGM 재생 예약: {audioClipPath} ({startDelay}초 후)");
    }

    public double GetCurrentBGMTime()
    {
        if (bgmSource == null)
        {
            return 0.0;
        }

        // bgmStartTime이 설정되지 않았으면 0 반환
        if (bgmStartTime == 0)
        {
            return 0.0;
        }

        return AudioSettings.dspTime - bgmStartTime;
    }

    public void PlayHitSound(SoundType soundType)
    {
        if (soundClips.TryGetValue(soundType, out AudioClip sfxClip))
        {
            PlayHitSound(sfxClip, 1.0f);
        }
        else
        {
            Debug.LogWarning($"SoundType {soundType}에 해당하는 AudioClip을 찾을 수 없습니다.");
        }
    }

    public void PlayHitSound(AudioClip sfxClip, float volumeScale)
    {
        if (sfxClip == null) return;

        AudioSource source = GetAvailableSfxSource();
        source.clip = sfxClip;
        source.volume = volumeScale;
        source.Play();

    }

    public IEnumerator ApplyMissEffect()
    {
        // 원래 볼륨 저장
        float originalVolume = bgmSource.volume;

        // 1. 로우패스 필터 적용
        _bgmLowPassFilter.cutoffFrequency = 1000f;

        // 2. DOTween으로 볼륨 페이드아웃
        bgmSource.DOFade(0f, 1.5f); // 1초 동안 볼륨 0으로

        yield return new WaitForSeconds(1f);

        // 3. 필터 복구
        _bgmLowPassFilter.cutoffFrequency = 22000f;

        // 4. 볼륨 복구
        bgmSource.volume = originalVolume;

        // 5. BGM 정지
        if (bgmSource != null)
        {
            bgmSource.Stop();
        }
    }
}
