using System.Collections;
using UnityEngine;

public class LineManager : MonoBehaviour
{
    [SerializeField] private Material lineMaterial;
    [SerializeField] private float lineHeight = 5f;
    [SerializeField] private float bounceAmplitude = 0.5f;
    [SerializeField] private float bounceDuration = 0.5f;
    [SerializeField] private int waveResolution = 20;   // 줄 포인트 수 (꾸불꾸불 세밀도)
    [SerializeField] private float centerRange = 0.2f;  // 중앙에서 이 비율만 흔들리게 (0.2면 40% 구간)
    [SerializeField] private int edgePointCount = 3;    // 위/아래에 둘 포인트 수 (나머지는 중앙에 몰아줌)

    private LineRenderer[] _lines = new LineRenderer[5];
    private float[] _xPositions = new float[] { -4f, -2, 0f, 2f, 4f };

    void Start()
    {
        for (int i = 0; i < 5; i++)
        {
            GameObject lineObj = new GameObject($"Line_{i}");
            lineObj.transform.parent = this.transform;

            LineRenderer lr = lineObj.AddComponent<LineRenderer>();
            lr.material = lineMaterial;
            lr.positionCount = waveResolution;
            lr.startWidth = 0.3f;
            lr.endWidth = 0.3f;
            lr.useWorldSpace = true;

            _lines[i] = lr;

            // 초기 위치
            UpdateLineWave(i, 0f);
        }

        if(NoteManager.Instance != null)
            NoteManager.Instance.OnHit += OnHit;

        if(InGameManager.Instance!=null)
        {
            InGameManager.Instance.OnGamePause += OnGamePause;
            InGameManager.Instance.OnGameResume += OnGameResume;
        }
    }
    private void OnDisable()
    {
        if (NoteManager.Instance != null)
            NoteManager.Instance.OnHit -= OnHit;

        if (InGameManager.Instance != null)
        {
            InGameManager.Instance.OnGamePause -= OnGamePause;
            InGameManager.Instance.OnGameResume -= OnGameResume;
        }
    }
    private void OnHit(Note note)
    {
         TriggerBounce(note.TilePosition.x);
    }
    private void OnGamePause()
    {
        foreach (var line in _lines)
        {
            line.gameObject.SetActive(false);
        }
    }
    private void OnGameResume()
    {
        foreach (var line in _lines)
        {
            line.gameObject.SetActive(true);
        }
    }

    public void TriggerBounce(float tileXpos)
    {
        int index = FindClosestLineIndex(tileXpos);
        if (index >= 0 && index < _lines.Length)
            StartCoroutine(WaveLine(index));
    }

    private int FindClosestLineIndex(float x)
    {
        int closest = 0;
        float minDist = Mathf.Abs(x - _xPositions[0]);

        for (int i = 1; i < _xPositions.Length; i++)
        {
            float dist = Mathf.Abs(x - _xPositions[i]);
            if (dist < minDist)
            {
                minDist = dist;
                closest = i;
            }
        }

        return closest;
    }

    private IEnumerator WaveLine(int index)
    {
        float elapsed = 0f;

        while (elapsed < bounceDuration)
        {
            float t = elapsed / bounceDuration;
            float waveStrength = Mathf.Sin(t * Mathf.PI) * bounceAmplitude;

            UpdateLineWave(index, waveStrength);

            elapsed += Time.deltaTime;
            yield return null;
        }

        UpdateLineWave(index, 0f); // 복원
    }

    private void UpdateLineWave(int index, float strength)
    {
        LineRenderer lr = _lines[index];
        float x = _xPositions[index];
        float baseY = transform.position.y;

        // 세로 t 기준에서 중앙 구간 범위
        float center = 0.5f;
        float halfRange = centerRange * 0.5f;
        float bottomEndT = center - halfRange; // 중앙 구간 시작
        float topStartT = center + halfRange;  // 중앙 구간 끝

        int total = waveResolution;

        // 위/아래에 둘 점 개수
        int bottomCount = edgePointCount;
        int topCount = edgePointCount;

        // 중앙에 몰릴 점 개수
        int centerCount = total - bottomCount - topCount;
        if (centerCount < 3)
            centerCount = 3; // 최소 안전장치

        for (int i = 0; i < total; i++)
        {
            float t; // 0~1 사이, 세로 위치

            if (i < bottomCount) // 🔽 아래쪽 구간
            {
                float local = bottomCount == 1 ? 0f : i / (float)(bottomCount - 1);
                t = Mathf.Lerp(0f, bottomEndT, local);
            }
            else if (i < bottomCount + centerCount) // 🎯 중앙 구간 (점 많이)
            {
                int j = i - bottomCount;
                float local = centerCount == 1 ? 0f : j / (float)(centerCount - 1);
                t = Mathf.Lerp(bottomEndT, topStartT, local);
            }
            else // 🔼 위쪽 구간
            {
                int j = i - bottomCount - centerCount;
                float local = topCount == 1 ? 0f : j / (float)(topCount - 1);
                t = Mathf.Lerp(topStartT, 1f, local);
            }

            float y = Mathf.Lerp(-lineHeight, lineHeight, t);

            // 기본적으로는 직선
            float waveX = 0f;

            // 중앙 구간 안에 있을 때만 S자로 휜다
            float distFromCenter = Mathf.Abs(t - center);
            if (distFromCenter <= halfRange && strength > 0f)
            {
                // 중앙 구간 안에서 0~1로 다시 매핑
                float localT = Mathf.InverseLerp(bottomEndT, topStartT, t);

                // S자 커브 (위는 +, 아래는 -)
                float sCurve = Mathf.Sin((localT - 0.5f) * Mathf.PI * 2f); // -1 ~ 1

                // 중앙이 더 휘고 양 끝은 줄어들게
                float centerEmphasis = Mathf.Sin(localT * Mathf.PI); // 0 -> 1 -> 0

                waveX = sCurve * centerEmphasis * strength;
            }

            Vector3 point = new Vector3(x + waveX, baseY + y, 0f);
            lr.SetPosition(i, point);
        }
    }
}


//using System.Collections;
//using UnityEngine;

//public class LineManager : MonoBehaviour
//{
//    [SerializeField] private Material lineMaterial;
//    [SerializeField] private float lineHeight = 5f;

//    [Header("Wave Timing")]
//    [SerializeField] private float bounceAmplitude = 0.5f;  // 휘어지는 강도
//    [SerializeField] private float bounceDuration = 0.5f;   // 바운스 시간

//    [Header("Wave Shape")]
//    [SerializeField] private int waveResolution = 20;       // 라인 분할 포인트 수
//    [SerializeField] private float centerRange = 0.2f;      // 세로 기준 중앙에서만 휘는 비율 (0.2면 40% 구간)
//    [SerializeField] private int edgePointCount = 3;        // 위/아래에 둘 포인트 수 (나머지는 중앙에 몰아줌)

//    [Header("Randomness")]
//    [SerializeField] private float waveRandomAmount = 0.3f; // 웨이브 모양 랜덤 세기

//    private LineRenderer[] _lines = new LineRenderer[5];
//    private float[] _xPositions = new float[] { -5f, -2.5f, 0f, 2.5f, 5f };

//    // [라인 인덱스, 포인트 인덱스] 별 랜덤 값
//    private float[,] _waveRandom;

//    void Start()
//    {
//        _waveRandom = new float[_lines.Length, waveResolution];

//        for (int i = 0; i < _lines.Length; i++)
//        {
//            GameObject lineObj = new GameObject($"Line_{i}");
//            lineObj.transform.parent = this.transform;

//            LineRenderer lr = lineObj.AddComponent<LineRenderer>();
//            lr.material = lineMaterial;
//            lr.positionCount = waveResolution;
//            lr.startWidth = 0.3f;
//            lr.endWidth = 0.3f;
//            lr.useWorldSpace = true;

//            _lines[i] = lr;

//            // 초기 직선 상태로 셋업
//            UpdateLineWave(i, 0f);
//        }

//        // 노트 히트 시 호출
//        NoteManager.Instance.OnHit += (note) => TriggerBounce(note.TilePosition.x);
//    }

//    /// <summary>
//    /// 노트 X 위치 받아서 가장 가까운 라인 하나만 바운스
//    /// </summary>
//    public void TriggerBounce(float tileXpos)
//    {
//        int index = FindClosestLineIndex(tileXpos);
//        if (index >= 0 && index < _lines.Length)
//        {
//            StartCoroutine(WaveLine(index));
//        }
//    }

//    /// <summary>
//    /// tile X에 가장 가까운 라인 인덱스 찾기
//    /// </summary>
//    private int FindClosestLineIndex(float x)
//    {
//        int closest = 0;
//        float minDist = Mathf.Abs(x - _xPositions[0]);

//        for (int i = 1; i < _xPositions.Length; i++)
//        {
//            float dist = Mathf.Abs(x - _xPositions[i]);
//            if (dist < minDist)
//            {
//                minDist = dist;
//                closest = i;
//            }
//        }
//        return closest;
//    }

//    /// <summary>
//    /// 한 라인에 대해 S-wave 바운스 코루틴
//    /// </summary>
//    private IEnumerator WaveLine(int index)
//    {
//        float elapsed = 0f;

//        // 이번 바운스 동안 사용할 랜덤 프로필 생성
//        for (int i = 0; i < waveResolution; i++)
//        {
//            _waveRandom[index, i] = Random.Range(-1f, 1f);
//        }

//        while (elapsed < bounceDuration)
//        {
//            float t = elapsed / bounceDuration;
//            float waveStrength = Mathf.Sin(t * Mathf.PI) * bounceAmplitude; // 0 -> 1 -> 0

//            UpdateLineWave(index, waveStrength);

//            elapsed += Time.deltaTime;
//            yield return null;
//        }

//        // 끝나면 직선으로 복원
//        UpdateLineWave(index, 0f);
//    }

//    /// <summary>
//    /// 특정 라인의 점들을 업데이트해서
//    /// 중앙만 S 모양 + 랜덤 약간 섞인 웨이브로 만든다.
//    /// strength가 0이면 직선.
//    /// </summary>
//    private void UpdateLineWave(int index, float strength)
//    {
//        LineRenderer lr = _lines[index];
//        float x = _xPositions[index];
//        float baseY = transform.position.y;

//        // 세로 t 기준에서 중앙 구간 범위 (0~1 구간의 일부만 사용)
//        float center = 0.5f;
//        float halfRange = centerRange * 0.5f;
//        float bottomEndT = center - halfRange; // 중앙 구간 시작 t
//        float topStartT = center + halfRange;  // 중앙 구간 끝 t

//        int total = waveResolution;

//        // 위/아래 포인트 수
//        int bottomCount = edgePointCount;
//        int topCount = edgePointCount;

//        // 중앙 구간 포인트 수 (최소 3개)
//        int centerCount = total - bottomCount - topCount;
//        if (centerCount < 3)
//        {
//            centerCount = 3;
//            // total보다 커지는 극단 상황은 waveResolution만 늘려주면 해결
//        }

//        for (int i = 0; i < total; i++)
//        {
//            float t; // 0~1 사이, 수직 위치 비율

//            if (i < bottomCount) // 🔽 아래쪽 구간
//            {
//                float local = bottomCount == 1 ? 0f : i / (float)(bottomCount - 1);
//                t = Mathf.Lerp(0f, bottomEndT, local);
//            }
//            else if (i < bottomCount + centerCount) // 🎯 중앙 구간 (점 많음)
//            {
//                int j = i - bottomCount;
//                float local = centerCount == 1 ? 0f : j / (float)(centerCount - 1);
//                t = Mathf.Lerp(bottomEndT, topStartT, local);
//            }
//            else // 🔼 위쪽 구간
//            {
//                int j = i - bottomCount - centerCount;
//                float local = topCount == 1 ? 0f : j / (float)(topCount - 1);
//                t = Mathf.Lerp(topStartT, 1f, local);
//            }

//            float y = Mathf.Lerp(-lineHeight, lineHeight, t);

//            // 기본은 직선
//            float waveX = 0f;

//            // 중앙 구간 안에 있을 때만 S 모양 + 랜덤을 섞어준다
//            float distFromCenter = Mathf.Abs(t - center);
//            if (distFromCenter <= halfRange && strength > 0f)
//            {
//                // 중앙 구간 안에서의 로컬 0~1
//                float localT = Mathf.InverseLerp(bottomEndT, topStartT, t);

//                // S자 커브 (아래쪽은 -, 위쪽은 + 쪽으로 휘는 모양)
//                float sCurve = Mathf.Sin((localT - 0.5f) * Mathf.PI * 2f); // -1 ~ 1

//                // 중앙에서 제일 많이, 양 끝은 적게 (종 모양)
//                float centerEmphasis = Mathf.Sin(localT * Mathf.PI); // 0 -> 1 -> 0

//                float baseWave = sCurve * centerEmphasis;

//                // 이 바운스 동안 미리 뽑아둔 랜덤 프로필
//                float noise = _waveRandom[index, i] * waveRandomAmount;

//                // 최종 X 오프셋
//                waveX = (baseWave + noise) * strength;
//            }

//            Vector3 point = new Vector3(x + waveX, baseY + y, 0f);
//            lr.SetPosition(i, point);
//        }
//    }
//}
