using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadingManager : Singleton<LoadingManager>
{
    private const float MIN_LOADING_TIME = 2f;
    private const string INGAME_SCENE_NAME = "InGame";

    private float _loadingStartTime;

    protected override void Awake()
    {
        base.Awake();
        _loadingStartTime = Time.time;
    }

    private void Start()
    {
        StartCoroutine(WaitForInitializationAndLoadScene());
    }

    private IEnumerator WaitForInitializationAndLoadScene()
    {
        // NoteManager 먼저 초기화 대기 (Awake 완료 확인)
        yield return new WaitUntil(() => IsNoteManagerInitialized());
        Debug.Log("NoteManager 초기화 완료");

        // ObjectPool Awake 완료 대기
        yield return new WaitUntil(() => ObjectPool.Instance != null);
        
        // ObjectPool 수동 초기화 (NoteManager가 먼저 초기화된 후)
        ObjectPool.Instance.InitializePools();
        
        // ObjectPool 초기화 완료 대기
        yield return new WaitUntil(() => ObjectPool.Instance.IsInitialized);

        // 최소 대기 시간 확인
        float elapsedTime = Time.time - _loadingStartTime;
        float remainingTime = MIN_LOADING_TIME - elapsedTime;

        if (remainingTime > 0)
        {
            Debug.Log($"최소 로딩 시간 대기 중... ({remainingTime:F2}초 남음)");
            yield return new WaitForSeconds(remainingTime);
        }

        // InGame 씬으로 전환 (콜백으로 이벤트 구독)
        Debug.Log("InGame 씬으로 전환합니다.");
        FadeManager.Instance.FadeToScene(INGAME_SCENE_NAME, OnInGameSceneLoaded);
    }

    private void OnInGameSceneLoaded()
    {
        Debug.Log("InGame 씬 로드 완료!");
        
        // InGameManager의 게임 시작 이벤트에 NoteManager 구독
        if (InGameManager.Instance != null && NoteManager.Instance != null)
        {
            InGameManager.Instance.OnGameStart += NoteManager.Instance.StartGame;
            Debug.Log("NoteManager가 InGameManager의 OnGameStart 이벤트를 구독했습니다.");
        }
        else
        {
            Debug.LogError("InGameManager 또는 NoteManager를 찾을 수 없습니다!");
        }
    }

    private bool IsNoteManagerInitialized()
    {
        // NoteManager가 존재하고 Awake가 완료되었는지 확인
        return NoteManager.Instance != null;
    }
}
