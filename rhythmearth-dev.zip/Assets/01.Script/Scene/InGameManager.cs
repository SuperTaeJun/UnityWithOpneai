using System;
using UnityEngine;
using Cysharp.Threading.Tasks;


public enum EGameState
{
    Ready,
    Playing,
    Paused,
    Ended,
    Restart,
}
/// <summary>
/// InGame 씬 전용 매니저
/// 게임 시작, 일시정지, 종료 등을 관리합니다.
/// </summary>
public class InGameManager : Singleton<InGameManager>
{
    [SerializeField] private float _countdownTime = 3f;

    public EGameState CurrentState { get; private set; } = EGameState.Ready;


    // 게임 시작 이벤트
    public event Action OnGameStart;
    public event Action OnGamePause;
    public event Action OnGameEnd;
    public event Action OnGameResume;
    public event Action OnGameRestart;
    private bool _canShowResult = false; //
    private double _missTime = 0f;
    private void Start()
    {
        // NoteManager와 ObjectPool이 이미 초기화되어 있는지 확인
        if (NoteManager.Instance == null)
        {
            Debug.LogError("NoteManager가 초기화되지 않았습니다!");
            return;
        }

        if (ObjectPool.Instance == null || !ObjectPool.Instance.IsInitialized)
        {
            Debug.LogError("ObjectPool이 초기화되지 않았습니다!");
            return;
        }

        NoteManager.Instance.OnMiss += HandleMiss;
        NoteManager.Instance.OnAllNotesCompleted += OnAllNotesCompleted;
        // 카운트다운 후 게임 시작
        CountdownAndStartAsync().Forget();
    }
    private void OnDisable()
    {
        //base.OnDestroy();
        // NoteManager 이벤트 구독 해제
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnMiss -= HandleMiss;
            NoteManager.Instance.OnAllNotesCompleted -= OnAllNotesCompleted;
        }
    }
    private void HandleMiss(Note note)
    {
        PauseGame();
    }
    private async UniTaskVoid CountdownAndStartAsync()
    {
        Debug.Log($"{_countdownTime}초 후 게임 시작...");

        // 이전 게임의 BGM 정지 및 초기화
        if (SoundManager.Instance != null)
        {
            SoundManager.Instance.StopBGM();
        }

        // 카운트다운 대기
        await UniTask.Delay(TimeSpan.FromSeconds(_countdownTime), cancellationToken: this.GetCancellationTokenOnDestroy());

        // 게임 시작 이벤트 발생
        Debug.Log("게임 시작!");
        CurrentState = EGameState.Playing;
        OnGameStart?.Invoke();
        SoundManager.Instance.PlayBGM(MusicManager.Instance.SelectedMusic.AudioClipPath);
    }

    // 게임 일시정지 (필요시 구현)
    public void PauseGame()
    {
        OnGamePause?.Invoke();

        _missTime = NoteManager.Instance.SongPosition;

        StartCoroutine(SoundManager.Instance.ApplyMissEffect());

        PopupManager.Instance.Open(EPopupType.UI_Pause);
        CurrentState = EGameState.Paused;
    }

    // 게임 재개
    public void ResumeGame()
    {
        Debug.Log("게임 재개");
        double resumeTime = Math.Max(0, _missTime - 3.0);
        SoundManager.Instance.PlayBGMFromTime(resumeTime);
        OnGameResume?.Invoke();
        CurrentState = EGameState.Playing;
    }

    //게임 다시시작
    public void RestartGame()
    {
        OnGameRestart?.Invoke();
        NoteManager.Instance.ResetManager();
        ObjectPool.Instance.ResetManager();
        FadeManager.Instance.FadeToScene("InGame", NoteManager.Instance.TempTriger);
    }

    // 게임 종료
    public void EndGame()
    {
        CurrentState = EGameState.Ended;
        Debug.Log("게임 종료");
        // 결과 화면으로 이동하거나 로비로 돌아가는 로직
    }

    private void Update()
    {
        if (_canShowResult)
        {
            // PC: 마우스 클릭
            bool mouseClick = Input.GetMouseButtonDown(0);

            // 모바일: 터치 입력
            bool touchInput = Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began;

            if (mouseClick || touchInput)
            {
                ShowResult();
            }
        }
    }


    private void OnAllNotesCompleted()
    {
        Debug.Log("모든 노트 완료! 화면 클릭 대기 중...");
        _canShowResult = true;
    }

    private void ShowResult()
    {
        _canShowResult = false;
        Debug.Log("결과 화면 표시");
        PopupManager.Instance.Open(EPopupType.UI_Result);
        CurrentState = EGameState.Ended;
    }
}
