using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public Transform playerTarget;

    public float smoothTime = 0.3f;
    public Vector3 offset = new Vector3(0f, 10f, 0f);

    private Vector3 currentVelocity = Vector3.zero;

    private float zPosition;

    void Start()
    {
        zPosition = transform.position.z;
    }

    void LateUpdate()
    {
        if (playerTarget != null)
        {
            Vector3 targetPosition = playerTarget.position + offset;
            targetPosition.z = zPosition;

            transform.position = Vector3.SmoothDamp(
                transform.position, 
                targetPosition, 
                ref currentVelocity, 
                smoothTime
            );
        }
    }
}
