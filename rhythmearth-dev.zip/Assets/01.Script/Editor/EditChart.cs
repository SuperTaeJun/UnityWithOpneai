using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

public class EditChart : EditorWindow
{
    // 파일 관련
    private Object jsonFile;
    private Object audioFile;
    private Chart currentChart;
    private string jsonPath;

    // 오디오 관련
    private AudioClip audioClip;
    private AudioClip hitSoundClip;
    private double audioStartTime;
    private bool isPlaying = false;
    private bool isPendingPlay = false; // 재생 대기 중 플래그
    private float currentTime = 0f;
    private float lastPlayedNoteTime = -1f;
    private MethodInfo playClipMethod;
    private MethodInfo stopAllClipsMethod;
    private MethodInfo isClipPlayingMethod;

    // UI 관련
    private Vector2 scrollPosition;
    private List<int> selectedNoteIndices = new List<int>();
    private float timelineZoom = 100f;
    private Vector2 timelineScroll;

    // 편집 관련
    private bool isDirty = false;
    private NoteData clipboardNote = null;
    
    // 일괄 편집용 변수
    private ENoteType batchNoteType = ENoteType.Tap;
    private float batchTimeOffset = 0f;
    private float batchHoldDuration = 0.5f;

    // 필터 및 표시 옵션
    private bool showTap = true;
    private bool showHold = true;
    private bool showMultiTap = true;
    private bool showHoldTap = true;
    private float snapInterval = 0.25f;
    private bool enableSnap = true;

    [MenuItem("Tools/Chart Editor (노래 들으며 편집)")]
    public static void ShowWindow()
    {
        var window = GetWindow<EditChart>("Chart Editor");
        window.minSize = new Vector2(800, 600);
    }

    void OnEnable()
    {
        EditorApplication.update += Update;
        InitializeAudioUtil();
    }

    void OnDisable()
    {
        EditorApplication.update -= Update;
        StopAudio();
    }

    void InitializeAudioUtil()
    {
        Assembly unityEditorAssembly = typeof(AudioImporter).Assembly;
        System.Type audioUtilClass = unityEditorAssembly.GetType("UnityEditor.AudioUtil");

        if (audioUtilClass != null)
        {
            playClipMethod = audioUtilClass.GetMethod(
                "PlayPreviewClip",
                BindingFlags.Static | BindingFlags.Public,
                null,
                new System.Type[] { typeof(AudioClip), typeof(int), typeof(bool) },
                null
            );

            stopAllClipsMethod = audioUtilClass.GetMethod(
                "StopAllPreviewClips",
                BindingFlags.Static | BindingFlags.Public
            );

            isClipPlayingMethod = audioUtilClass.GetMethod(
                "IsPreviewClipPlaying",
                BindingFlags.Static | BindingFlags.Public
            );
        }
    }

    void Update()
    {
        if (isPlaying && audioClip != null)
        {
            currentTime = (float)(EditorApplication.timeSinceStartup - audioStartTime);

            if (currentTime >= audioClip.length)
            {
                StopAudio();
            }

            CheckAndPlayHitSounds();
            Repaint();
        }
    }

    void CheckAndPlayHitSounds()
    {
        if (currentChart == null || currentChart.notes == null || hitSoundClip == null || !isPlaying)
            return;

        foreach (var note in currentChart.notes)
        {
            float tolerance = 0.05f;

            if (Mathf.Abs(currentTime - note.targetTime) < tolerance &&
                note.targetTime > lastPlayedNoteTime)
            {
                PlayHitSound();
                lastPlayedNoteTime = note.targetTime;
                break;
            }
        }
    }

    void PlayHitSound()
    {
        if (hitSoundClip != null && playClipMethod != null && isPlaying)
        {
            playClipMethod.Invoke(null, new object[] { hitSoundClip, 0, false });
        }
    }

    void OnGUI()
    {
        HandleKeyboardInput();
        DrawHeader();

        if (currentChart != null && audioClip != null)
        {
            DrawToolbar();
            DrawTimeline();
            DrawNoteList();
            DrawNoteEditor();
        }

        if (isDirty)
        {
            EditorGUILayout.HelpBox("⚠️ 변경사항이 저장되지 않았습니다!", MessageType.Warning);
        }
    }

    void HandleKeyboardInput()
    {
        Event e = Event.current;

        if (e.type == EventType.KeyDown)
        {
            if (e.keyCode == KeyCode.Space)
            {
                if (audioClip != null)
                {
                    if (isPlaying)
                        PauseAudio();
                    else
                        PlayAudio();

                    e.Use();
                    Repaint();
                }
            }
            else if (e.keyCode == KeyCode.Delete && selectedNoteIndices.Count > 0)
            {
                DeleteSelectedNotes();
                e.Use();
                Repaint();
            }
            else if (e.control && e.keyCode == KeyCode.C && selectedNoteIndices.Count > 0)
            {
                CopySelectedNote();
                e.Use();
            }
            else if (e.control && e.keyCode == KeyCode.V && clipboardNote != null)
            {
                PasteNote();
                e.Use();
                Repaint();
            }
            else if (e.control && e.keyCode == KeyCode.S && currentChart != null && isDirty)
            {
                SaveChart();
                e.Use();
            }
            else if (e.control && e.keyCode == KeyCode.A && currentChart != null)
            {
                SelectAllNotes();
                e.Use();
                Repaint();
            }
            else if (e.keyCode == KeyCode.Escape && selectedNoteIndices.Count > 0)
            {
                selectedNoteIndices.Clear();
                e.Use();
                Repaint();
            }
        }
    }

    void DrawHeader()
    {
        GUILayout.Label("Chart Editor - 노래를 들으며 차트 편집", EditorStyles.boldLabel);
        GUILayout.Space(5);

        EditorGUILayout.BeginHorizontal();

        EditorGUI.BeginChangeCheck();
        jsonFile = EditorGUILayout.ObjectField("Chart JSON", jsonFile, typeof(TextAsset), false);
        if (EditorGUI.EndChangeCheck() && jsonFile != null)
        {
            LoadChart();
        }

        EditorGUI.BeginChangeCheck();
        audioFile = EditorGUILayout.ObjectField("Audio File", audioFile, typeof(AudioClip), false);
        if (EditorGUI.EndChangeCheck() && audioFile != null)
        {
            audioClip = audioFile as AudioClip;
        }

        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUI.BeginChangeCheck();
        Object hitSoundFile = EditorGUILayout.ObjectField("Hit Sound", hitSoundClip, typeof(AudioClip), false);
        if (EditorGUI.EndChangeCheck() && hitSoundFile != null)
        {
            hitSoundClip = hitSoundFile as AudioClip;
        }
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        GUI.enabled = currentChart != null && isDirty;
        if (GUILayout.Button("💾 저장", GUILayout.Height(25)))
        {
            SaveChart();
        }
        GUI.enabled = true;

        if (GUILayout.Button("🔄 새로고침", GUILayout.Height(25)))
        {
            LoadChart();
        }
        EditorGUILayout.EndHorizontal();

        GUILayout.Space(10);
    }

    void DrawToolbar()
    {
        EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);

        if (GUILayout.Button(isPlaying ? "⏸ 일시정지" : "▶ 재생", EditorStyles.toolbarButton, GUILayout.Width(80)))
        {
            if (isPlaying)
                PauseAudio();
            else
                PlayAudio();
        }

        if (GUILayout.Button("⏹ 정지", EditorStyles.toolbarButton, GUILayout.Width(60)))
        {
            StopAudio();
        }

        GUILayout.Space(10);

        GUILayout.Label($"⏱ {currentTime:F2}s / {(audioClip != null ? audioClip.length : 0):F2}s", EditorStyles.toolbarButton);

        GUILayout.FlexibleSpace();

        GUILayout.Label("BPM:", EditorStyles.toolbarButton);
        EditorGUI.BeginChangeCheck();
        float newBpm = EditorGUILayout.FloatField(currentChart.bpm, EditorStyles.toolbarTextField, GUILayout.Width(60));
        if (EditorGUI.EndChangeCheck())
        {
            currentChart.bpm = newBpm;
            isDirty = true;
        }

        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);

        if (GUILayout.Button("➕ 노트 추가", EditorStyles.toolbarButton))
        {
            AddNoteAtCurrentTime();
        }

        GUI.enabled = selectedNoteIndices.Count > 0;
        if (GUILayout.Button($"🗑 삭제 ({selectedNoteIndices.Count})", EditorStyles.toolbarButton))
        {
            DeleteSelectedNotes();
        }

        if (GUILayout.Button("📋 복사", EditorStyles.toolbarButton))
        {
            CopySelectedNote();
        }
        
        if (GUILayout.Button("전체선택", EditorStyles.toolbarButton))
        {
            SelectAllNotes();
        }
        
        if (GUILayout.Button("선택해제", EditorStyles.toolbarButton))
        {
            selectedNoteIndices.Clear();
        }
        GUI.enabled = true;

        GUI.enabled = clipboardNote != null;
        if (GUILayout.Button("📄 붙여넣기", EditorStyles.toolbarButton))
        {
            PasteNote();
        }
        GUI.enabled = true;

        GUILayout.FlexibleSpace();

        enableSnap = GUILayout.Toggle(enableSnap, "스냅", EditorStyles.toolbarButton);
        if (enableSnap)
        {
            GUILayout.Label("간격:", EditorStyles.toolbarButton);
            snapInterval = EditorGUILayout.FloatField(snapInterval, EditorStyles.toolbarTextField, GUILayout.Width(50));
        }

        EditorGUILayout.EndHorizontal();
    }

    void DrawTimeline()
    {
        GUILayout.Label("타임라인", EditorStyles.boldLabel);

        EditorGUILayout.BeginHorizontal();
        GUILayout.Label("줌:", GUILayout.Width(40));
        timelineZoom = EditorGUILayout.Slider(timelineZoom, 20f, 500f);
        EditorGUILayout.EndHorizontal();

        Rect timelineRect = GUILayoutUtility.GetRect(0, 150, GUILayout.ExpandWidth(true));

        EditorGUI.DrawRect(timelineRect, new Color(0.2f, 0.2f, 0.2f));

        float totalWidth = audioClip != null ? audioClip.length * timelineZoom : 1000f;
        Rect scrollRect = new Rect(timelineRect.x, timelineRect.y, timelineRect.width, timelineRect.height);
        Rect contentRect = new Rect(0, 0, totalWidth, timelineRect.height);

        timelineScroll = GUI.BeginScrollView(scrollRect, timelineScroll, contentRect);

        DrawTimelineGrid(contentRect);
        DrawTimelineNotes(contentRect);

        float playheadX = currentTime * timelineZoom;
        Handles.color = Color.red;
        Handles.DrawLine(new Vector3(playheadX, 0, 0), new Vector3(playheadX, contentRect.height, 0));

        GUI.EndScrollView();

        if (Event.current.type == EventType.MouseDown && timelineRect.Contains(Event.current.mousePosition))
        {
            float clickedTime = (Event.current.mousePosition.x - timelineRect.x + timelineScroll.x) / timelineZoom;
            SeekToTime(clickedTime);
            Event.current.Use();
        }
    }

    void DrawTimelineGrid(Rect rect)
    {
        Handles.color = new Color(0.5f, 0.5f, 0.5f, 0.3f);

        float interval = 1f;
        if (timelineZoom < 50) interval = 5f;
        else if (timelineZoom > 200) interval = 0.5f;

        for (float t = 0; t < rect.width / timelineZoom; t += interval)
        {
            float x = t * timelineZoom;
            Handles.DrawLine(new Vector3(x, 0, 0), new Vector3(x, rect.height, 0));
            GUI.Label(new Rect(x + 2, 2, 50, 20), $"{t:F1}s", EditorStyles.miniLabel);
        }
    }

    void DrawTimelineNotes(Rect rect)
    {
        if (currentChart == null || currentChart.notes == null) return;

        float noteHeight = rect.height - 30;
        float laneHeight = noteHeight / 4f;

        for (int i = 0; i < currentChart.notes.Count; i++)
        {
            var note = currentChart.notes[i];

            if (!ShouldShowNote(note)) continue;

            float x = note.targetTime * timelineZoom;
            float y = GetLaneY(note.noteType, laneHeight) + 25;

            Color noteColor = GetNoteColor(note.noteType);
            if (selectedNoteIndices.Contains(i))
            {
                noteColor = Color.yellow;
            }

            if (note.noteType == ENoteType.Hold)
            {
                float width = note.holdDurationTime * timelineZoom;
                EditorGUI.DrawRect(new Rect(x, y, Mathf.Max(width, 3), laneHeight - 4), noteColor);
            }
            else
            {
                EditorGUI.DrawRect(new Rect(x - 2, y, 4, laneHeight - 4), noteColor);
            }

            Rect noteRect = new Rect(x - 5, y, 10, laneHeight - 4);
            if (Event.current.type == EventType.MouseDown && noteRect.Contains(Event.current.mousePosition))
            {
                HandleNoteSelection(i, Event.current.control);
                Event.current.Use();
                Repaint();
            }
        }
    }

    void HandleNoteSelection(int index, bool isCtrlHeld)
    {
        if (isCtrlHeld)
        {
            // Ctrl 누른 상태: 토글 선택
            if (selectedNoteIndices.Contains(index))
            {
                selectedNoteIndices.Remove(index);
            }
            else
            {
                selectedNoteIndices.Add(index);
            }
        }
        else
        {
            // Ctrl 안 누른 상태: 단일 선택
            selectedNoteIndices.Clear();
            selectedNoteIndices.Add(index);
        }
    }

    float GetLaneY(ENoteType noteType, float laneHeight)
    {
        switch (noteType)
        {
            case ENoteType.Tap:
            case ENoteType.LeftTap:
            case ENoteType.RightTap:
            case ENoteType.UpTap:
                return 0; // 모든 Tap 관련 노트는 같은 라인
            case ENoteType.Hold: 
                return laneHeight;
            case ENoteType.MultiTapNote: 
                return laneHeight * 2;
            case ENoteType.HoldTap: 
                return laneHeight * 3;
            case ENoteType.Mirro:
                return 0; // Mirror도 Tap과 같은 라인
            default: 
                return 0;
        }
    }

    void DrawNoteList()
    {
        GUILayout.Label($"노트 목록 ({currentChart.notes.Count}개) - 선택됨: {selectedNoteIndices.Count}개", EditorStyles.boldLabel);

        EditorGUILayout.BeginHorizontal();
        showTap = GUILayout.Toggle(showTap, "Tap", EditorStyles.toolbarButton);
        showHold = GUILayout.Toggle(showHold, "Hold", EditorStyles.toolbarButton);
        showMultiTap = GUILayout.Toggle(showMultiTap, "MultiTap", EditorStyles.toolbarButton);
        showHoldTap = GUILayout.Toggle(showHoldTap, "HoldTap", EditorStyles.toolbarButton);
        EditorGUILayout.EndHorizontal();

        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, GUILayout.Height(200));

        for (int i = 0; i < currentChart.notes.Count; i++)
        {
            var note = currentChart.notes[i];

            if (!ShouldShowNote(note)) continue;

            EditorGUILayout.BeginHorizontal();

            bool isSelected = selectedNoteIndices.Contains(i);
            Color bgColor = isSelected ? Color.yellow : (i % 2 == 0 ? Color.gray : Color.clear);

            if (bgColor != Color.clear)
            {
                Rect rect = EditorGUILayout.BeginVertical();
                EditorGUI.DrawRect(rect, bgColor * 0.3f);
            }

            if (GUILayout.Button($"{i}", GUILayout.Width(40)))
            {
                HandleNoteSelection(i, Event.current.control);
                if (selectedNoteIndices.Count == 1)
                {
                    SeekToTime(note.targetTime);
                }
            }

            GUILayout.Label($"{note.noteType}", GUILayout.Width(80));
            GUILayout.Label($"⏱ {note.targetTime:F3}s", GUILayout.Width(100));

            if (note.noteType == ENoteType.Hold || note.noteType == ENoteType.HoldTap)
            {
                GUILayout.Label($"⏳ {note.holdDurationTime:F3}s", GUILayout.Width(100));
            }

            if (bgColor != Color.clear)
            {
                EditorGUILayout.EndVertical();
            }

            EditorGUILayout.EndHorizontal();
        }

        EditorGUILayout.EndScrollView();
    }

    void DrawNoteEditor()
    {
        if (selectedNoteIndices.Count == 0)
        {
            GUILayout.Label("노트를 선택하세요 (Ctrl+클릭으로 여러 개 선택 가능)", EditorStyles.helpBox);
            return;
        }

        if (selectedNoteIndices.Count == 1)
        {
            // 단일 선택: 기존 편집 UI
            GUILayout.Label("선택된 노트 편집", EditorStyles.boldLabel);

            int index = selectedNoteIndices[0];
            if (index < 0 || index >= currentChart.notes.Count) return;

            var note = currentChart.notes[index];

            EditorGUI.BeginChangeCheck();

            note.noteType = (ENoteType)EditorGUILayout.EnumPopup("노트 타입", note.noteType);
            note.targetTime = EditorGUILayout.FloatField("시간 (초)", note.targetTime);

            if (note.noteType == ENoteType.Hold || note.noteType == ENoteType.HoldTap)
            {
                note.holdDurationTime = EditorGUILayout.FloatField("홀드 길이 (초)", note.holdDurationTime);
            }
            if (EditorGUI.EndChangeCheck())
            {
                isDirty = true;
                SortNotes();
            }
        }
        else
        {
            // 다중 선택: 일괄 편집 UI
            GUILayout.Label($"선택된 노트 일괄 편집 ({selectedNoteIndices.Count}개)", EditorStyles.boldLabel);

            EditorGUILayout.HelpBox("선택된 모든 노트에 동일한 값을 적용합니다.", MessageType.Info);

            GUILayout.Space(5);
            GUILayout.Label("노트 타입 일괄 변경:", EditorStyles.boldLabel);
            batchNoteType = (ENoteType)EditorGUILayout.EnumPopup("변경할 타입", batchNoteType);
            
            if (GUILayout.Button("적용", GUILayout.Height(30)))
            {
                foreach (int index in selectedNoteIndices)
                {
                    if (index >= 0 && index < currentChart.notes.Count)
                    {
                        currentChart.notes[index].noteType = batchNoteType;
                    }
                }
                isDirty = true;
                Repaint();
            }

            GUILayout.Space(10);
            GUILayout.Label("시간 이동:", EditorStyles.boldLabel);
            batchTimeOffset = EditorGUILayout.FloatField("오프셋 (초)", batchTimeOffset);
            if (GUILayout.Button("적용", GUILayout.Height(30)))
            {
                foreach (int index in selectedNoteIndices)
                {
                    if (index >= 0 && index < currentChart.notes.Count)
                    {
                        currentChart.notes[index].targetTime += batchTimeOffset;
                    }
                }
                isDirty = true;
                SortNotes();
                Repaint();
            }

            GUILayout.Space(10);
            GUILayout.Label("홀드 길이 변경:", EditorStyles.boldLabel);
            batchHoldDuration = EditorGUILayout.FloatField("길이 (초)", batchHoldDuration);
            if (GUILayout.Button("적용", GUILayout.Height(30)))
            {
                foreach (int index in selectedNoteIndices)
                {
                    if (index >= 0 && index < currentChart.notes.Count)
                    {
                        var note = currentChart.notes[index];
                        if (note.noteType == ENoteType.Hold || note.noteType == ENoteType.HoldTap)
                        {
                            note.holdDurationTime = batchHoldDuration;
                        }
                    }
                }
                isDirty = true;
                Repaint();
            }
        }
    }

    bool ShouldShowNote(NoteData note)
    {
        switch (note.noteType)
        {
            case ENoteType.Tap:
            case ENoteType.LeftTap:
            case ENoteType.RightTap:
            case ENoteType.UpTap:
            case ENoteType.Mirro:
                return showTap; // 모든 Tap 관련 노트는 showTap 필터 사용
            case ENoteType.Hold: 
                return showHold;
            case ENoteType.MultiTapNote: 
                return showMultiTap;
            case ENoteType.HoldTap: 
                return showHoldTap;
            default: 
                return true;
        }
    }

    Color GetNoteColor(ENoteType noteType)
    {
        switch (noteType)
        {
            case ENoteType.Tap: 
                return Color.cyan;
            case ENoteType.LeftTap: 
                return new Color(1f, 0.5f, 0f); // 주황색
            case ENoteType.RightTap: 
                return new Color(0.5f, 0f, 1f); // 보라색
            case ENoteType.UpTap: 
                return Color.yellow;
            case ENoteType.Mirro: 
                return new Color(1f, 0.08f, 0.58f); // 핑크색
            case ENoteType.Hold: 
                return Color.green;
            case ENoteType.MultiTapNote: 
                return Color.magenta;
            case ENoteType.HoldTap: 
                return Color.blue;
            default: 
                return Color.white;
        }
    }

    void LoadChart()
    {
        if (jsonFile == null) return;

        jsonPath = AssetDatabase.GetAssetPath(jsonFile);
        string json = File.ReadAllText(jsonPath);
        currentChart = JsonUtility.FromJson<Chart>(json);

        if (currentChart.notes == null)
            currentChart.notes = new List<NoteData>();

        SortNotes();
        isDirty = false;
        selectedNoteIndices.Clear();

        Debug.Log($"Chart loaded: {currentChart.notes.Count} notes, BPM: {currentChart.bpm}");
    }

    void SaveChart()
    {
        if (currentChart == null || string.IsNullOrEmpty(jsonPath)) return;

        SortNotes();
        string json = JsonUtility.ToJson(currentChart, true);
        File.WriteAllText(jsonPath, json);
        AssetDatabase.Refresh();

        isDirty = false;
        Debug.Log($"Chart saved: {jsonPath}");
        EditorUtility.DisplayDialog("저장 완료", "차트가 저장되었습니다!", "확인");
    }

    void SortNotes()
    {
        if (currentChart != null && currentChart.notes != null)
        {
            currentChart.notes = currentChart.notes.OrderBy(n => n.targetTime).ToList();
        }
    }

    void PlayAudio()
    {
        if (audioClip == null || playClipMethod == null || isPendingPlay) return;

        // 중복 재생 방지
        isPendingPlay = true;

        // 먼저 모든 클립 정지
        if (stopAllClipsMethod != null)
        {
            stopAllClipsMethod.Invoke(null, null);
        }

        // 현재 시간부터 재생 (루프 없이)
        int startSample = Mathf.RoundToInt(currentTime * audioClip.frequency);
        playClipMethod.Invoke(null, new object[] { audioClip, startSample, false });

        audioStartTime = EditorApplication.timeSinceStartup - currentTime;
        isPlaying = true;
        isPendingPlay = false;
    }

    void PauseAudio()
    {
        // 먼저 isPlaying을 false로 설정하여 Update에서 힛사운드 재생 중단
        isPlaying = false;
        isPendingPlay = false;

        // 즉시 모든 클립 정지
        if (stopAllClipsMethod != null)
        {
            stopAllClipsMethod.Invoke(null, null);
        }
    }

    void StopAudio()
    {
        if (stopAllClipsMethod != null)
        {
            stopAllClipsMethod.Invoke(null, null);
        }
        isPlaying = false;
        isPendingPlay = false;
        currentTime = 0f;
        lastPlayedNoteTime = -1f;
    }

    void SeekToTime(float time)
    {
        bool wasPlaying = isPlaying;

        if (isPlaying)
        {
            PauseAudio();
        }

        currentTime = Mathf.Clamp(time, 0, audioClip != null ? audioClip.length : 0);
        lastPlayedNoteTime = currentTime - 0.1f;

        if (wasPlaying)
        {
            PlayAudio();
        }
    }

    void AddNoteAtCurrentTime()
    {
        float time = enableSnap ? SnapTime(currentTime) : currentTime;

        var newNote = new NoteData
        {
            noteType = ENoteType.Tap,
            targetTime = time,
            holdDurationTime = 0.1f,
        };

        currentChart.notes.Add(newNote);
        SortNotes();

        selectedNoteIndices.Clear();
        selectedNoteIndices.Add(currentChart.notes.IndexOf(newNote));
        isDirty = true;
    }

    void DeleteSelectedNotes()
    {
        if (selectedNoteIndices.Count == 0) return;

        // 인덱스를 내림차순으로 정렬하여 뒤에서부터 삭제 (인덱스 변경 방지)
        var sortedIndices = selectedNoteIndices.OrderByDescending(i => i).ToList();
        
        foreach (int index in sortedIndices)
        {
            if (index >= 0 && index < currentChart.notes.Count)
            {
                currentChart.notes.RemoveAt(index);
            }
        }

        selectedNoteIndices.Clear();
        isDirty = true;
    }

    void CopySelectedNote()
    {
        if (selectedNoteIndices.Count == 0) return;

        // 첫 번째 선택된 노트만 복사
        int index = selectedNoteIndices[0];
        if (index >= 0 && index < currentChart.notes.Count)
        {
            var note = currentChart.notes[index];
            clipboardNote = new NoteData
            {
                noteType = note.noteType,
                targetTime = note.targetTime,
                holdDurationTime = note.holdDurationTime,
            };
        }
    }

    void PasteNote()
    {
        if (clipboardNote == null) return;

        float time = enableSnap ? SnapTime(currentTime) : currentTime;

        var newNote = new NoteData
        {
            noteType = clipboardNote.noteType,
            targetTime = time,
            holdDurationTime = clipboardNote.holdDurationTime,
        };

        currentChart.notes.Add(newNote);
        SortNotes();

        selectedNoteIndices.Clear();
        selectedNoteIndices.Add(currentChart.notes.IndexOf(newNote));
        isDirty = true;
    }

    void SelectAllNotes()
    {
        selectedNoteIndices.Clear();
        for (int i = 0; i < currentChart.notes.Count; i++)
        {
            if (ShouldShowNote(currentChart.notes[i]))
            {
                selectedNoteIndices.Add(i);
            }
        }
    }

    float SnapTime(float time)
    {
        return Mathf.Round(time / snapInterval) * snapInterval;
    }

}
