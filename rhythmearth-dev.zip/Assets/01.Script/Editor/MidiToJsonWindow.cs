using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using Melanchall.DryWetMidi.Core;
using Melanchall.DryWetMidi.Interaction;



public class MidiToJsonWindow : EditorWindow
{
    private Object midiFile;
    private string outputFileName = "song_chart_final.json";

    private int channelToProcess = 0;
    private float holdThreshold = 0.2f;

    // ✨ 난이도 설정 변수
    private EDifficulty difficultyLevel = EDifficulty.Hard;
    private float easyNoteGap = 0.4f;
    private float normalNoteGap = 0.2f;

    // ✨ TapTapTap 설정을 위한 변수 추가
    private float tapTapTapThreshold = 1.0f; // 1초 이상 공백이면 TapTapTap (기본값)

    // ✨ 홀드 노트 자동 감지 설정
    private bool enableAutoHoldDetection = true; // 자동 홀드 감지 활성화
    private int minConsecutiveNotesForHold = 3; // 홀드로 판정할 최소 연속 노트 개수
    private float maxIntervalForHold = 0.15f; // 홀드로 판정할 최대 노트 간격 (초)


    [MenuItem("Tools/MIDI → JSON (난이도 조절)")]
    public static void ShowWindow()
    {
        GetWindow<MidiToJsonWindow>("MIDI to JSON (Difficulty)");
    }

    void OnGUI()
    {
        GUILayout.Label("MIDI → JSON (난이도 조절)", EditorStyles.boldLabel);
        GUILayout.Space(10);
        EditorGUILayout.HelpBox(
            "MIDI 원본 시간을 사용하며, 설정된 난이도에 따라 노트를 솎아냅니다.", MessageType.Info);

        // --- UI 필드 ---
        midiFile = EditorGUILayout.ObjectField("MIDI 파일", midiFile, typeof(Object), false);
        outputFileName = EditorGUILayout.TextField("출력 파일명", outputFileName);

        EditorGUILayout.Space(5);
        EditorGUILayout.LabelField("노트 생성 설정", EditorStyles.boldLabel);

        // 난이도 선택 UI
        difficultyLevel = (EDifficulty)EditorGUILayout.EnumPopup("난이도", difficultyLevel);

        // 난이도별 상세 설정
        if (difficultyLevel != EDifficulty.Hard)
        {
            EditorGUILayout.HelpBox("설정된 시간(초)보다 간격이 좁은 노트는 무시됩니다.", MessageType.None);
            if (difficultyLevel == EDifficulty.Easy)
                easyNoteGap = EditorGUILayout.FloatField("Easy 최소 간격(초)", easyNoteGap);
            if (difficultyLevel == EDifficulty.Normal)
                normalNoteGap = EditorGUILayout.FloatField("Normal 최소 간격(초)", normalNoteGap);
        }

        channelToProcess = EditorGUILayout.IntField(new GUIContent("처리할 MIDI 채널", "어떤 채널의 노트를 가져올지 지정합니다."), channelToProcess);
        holdThreshold = EditorGUILayout.FloatField(new GUIContent("홀드 노트 최소 길이 (초)", "노트의 길이가 이 값보다 길면 홀드 노트로 처리합니다."), holdThreshold);

        // ✨ TapTapTap 설정 UI 추가
        tapTapTapThreshold = EditorGUILayout.FloatField(new GUIContent("TapTapTap 최소 간격 (초)", "이전 노트와의 시간이 이 값보다 길면 TapTapTap으로 처리합니다."), tapTapTapThreshold);

        // ✨ 홀드 노트 자동 감지 설정 UI
        GUILayout.Space(5);
        EditorGUILayout.LabelField("홀드 노트 자동 감지", EditorStyles.boldLabel);
        enableAutoHoldDetection = EditorGUILayout.Toggle(new GUIContent("자동 홀드 감지 활성화", "연속된 노트 패턴을 분석하여 자동으로 홀드 노트를 생성합니다."), enableAutoHoldDetection);
        
        if (enableAutoHoldDetection)
        {
            EditorGUILayout.HelpBox("짧은 간격으로 연속된 노트가 나오면 첫 노트를 홀드로 변환하고, 나머지는 홀드 중 탭 노트로 처리합니다.", MessageType.Info);
            minConsecutiveNotesForHold = EditorGUILayout.IntField(new GUIContent("최소 연속 노트 개수", "이 개수 이상 연속되면 홀드로 판정합니다."), minConsecutiveNotesForHold);
            maxIntervalForHold = EditorGUILayout.FloatField(new GUIContent("최대 노트 간격 (초)", "이 시간 이내로 노트가 연속되면 홀드로 판정합니다."), maxIntervalForHold);
        }

        GUILayout.Space(10);

        if (GUILayout.Button("✅ 변환 실행", GUILayout.Height(30)))
        {
            ConvertMidi();
        }
    }

    void ConvertMidi()
    {
        if (midiFile == null)
        {
            EditorUtility.DisplayDialog("오류", "MIDI 파일을 선택해주세요!", "확인");
            return;
        }

        string midiPath = AssetDatabase.GetAssetPath(midiFile);
        string outputDir = Path.GetDirectoryName(midiPath);
        string jsonPath = Path.Combine(outputDir, outputFileName);

        try
        {
            var midi = MidiFile.Read(midiPath);
            var tempoMap = midi.GetTempoMap();
            var notes = midi.GetNotes();

            var tempoChanges = tempoMap.GetTempoChanges();
            float bpm = 120f;
            foreach (var tempoEvent in tempoChanges)
            {
                bpm = (float)tempoEvent.Value.BeatsPerMinute;
                break;
            }

            List<NoteData> noteList = new List<NoteData>();

            // 난이도 필터링을 위한 변수
            float minimumTimeGap = 0.0f;
            switch (difficultyLevel)
            {
                case EDifficulty.Easy:
                    minimumTimeGap = easyNoteGap;
                    break;
                case EDifficulty.Normal:
                    minimumTimeGap = normalNoteGap;
                    break;
                case EDifficulty.Hard:
                    minimumTimeGap = 0.0f;
                    break;
            }

            // ✨ 1단계: 먼저 모든 노트를 임시 리스트에 수집 (난이도 필터링 적용)
            List<NoteData> tempNoteList = new List<NoteData>();
            float lastAddedNoteTime = -100.0f;

            foreach (var note in notes)
            {
                if (note.Channel != channelToProcess)
                {
                    continue;
                }

                double startTimeSec = note.TimeAs<MetricTimeSpan>(tempoMap).TotalSeconds;
                float timeSinceLastNote = (float)startTimeSec - lastAddedNoteTime;

                // 난이도 필터링
                if (difficultyLevel != EDifficulty.Hard && timeSinceLastNote < minimumTimeGap)
                {
                    continue;
                }

                double durationSec = note.LengthAs<MetricTimeSpan>(tempoMap).TotalSeconds;
                
                // 일단 기본 타입으로 추가 (나중에 홀드 감지로 변경될 수 있음)
                NoteData data = new NoteData
                {
                    noteType = ENoteType.Tap,
                    targetTime = (float)startTimeSec,
                    holdDurationTime = (float)durationSec,
                };

                tempNoteList.Add(data);
                lastAddedNoteTime = (float)startTimeSec;
            }

            // ✨ 2단계: 자동 홀드 감지 활성화 시, 연속된 노트 패턴 분석
            if (enableAutoHoldDetection)
            {
                for (int i = 0; i < tempNoteList.Count; i++)
                {
                    // 현재 노트부터 연속된 노트 개수 세기
                    int consecutiveCount = 1;
                    float currentTime = tempNoteList[i].targetTime;

                    for (int j = i + 1; j < tempNoteList.Count; j++)
                    {
                        float interval = tempNoteList[j].targetTime - tempNoteList[j - 1].targetTime;
                        
                        // 간격이 설정값 이내면 연속으로 판정
                        if (interval <= maxIntervalForHold)
                        {
                            consecutiveCount++;
                        }
                        else
                        {
                            break; // 간격이 크면 연속 끊김
                        }
                    }

                    // 연속 노트가 최소 개수 이상이면 홀드 노트로 변환
                    if (consecutiveCount >= minConsecutiveNotesForHold)
                    {
                        // 첫 번째 노트를 홀드로 변환
                        float holdEndTime = tempNoteList[i + consecutiveCount - 1].targetTime;
                        tempNoteList[i].noteType = ENoteType.Hold;
                        tempNoteList[i].holdDurationTime = holdEndTime - currentTime;

                        // ✨ 나머지 연속 노트들은 HoldTap으로 변환 (홀드 중에 눌러야 하는 노트)
                        for (int k = i + 1; k < i + consecutiveCount; k++)
                        {
                            tempNoteList[k].noteType = ENoteType.HoldTap;
                            tempNoteList[k].holdDurationTime = 0.1f;
                        }
                        
                        // 다음 검사는 연속 구간 이후부터 시작
                        i += consecutiveCount - 1;
                    }
                }
            }

            // ✨ 3단계: 기존 로직 적용 (duration 기반 홀드, TapTapTap 판정)
            lastAddedNoteTime = -100.0f;
            for (int i = 0; i < tempNoteList.Count; i++)
            {
                NoteData data = tempNoteList[i];
                float timeSinceLastNote = data.targetTime - lastAddedNoteTime;

                // ✨ 이미 Hold 또는 HoldTap으로 변환된 노트는 그대로 유지
                if (data.noteType == ENoteType.Hold || data.noteType == ENoteType.HoldTap)
                {
                    // 홀드 노트와 홀드탭 노트는 그대로 유지
                }
                // duration 기반 홀드 체크
                else if (data.holdDurationTime >= holdThreshold)
                {
                    data.noteType = ENoteType.Hold;
                }
                // TapTapTap 체크
                else if (timeSinceLastNote >= tapTapTapThreshold)
                {
                    data.noteType = ENoteType.MultiTapNote;
                    data.holdDurationTime = 0.1f;
                }
                // 일반 Tap
                else
                {
                    data.noteType = ENoteType.Tap;
                    data.holdDurationTime = 0.1f;
                }

                noteList.Add(data);
                lastAddedNoteTime = data.targetTime;
            }

            Chart chartData = new Chart { bpm = bpm, notes = noteList };
            string json = JsonUtility.ToJson(chartData, true);
            File.WriteAllText(jsonPath, json);

            EditorUtility.DisplayDialog("완료", $"✅ {difficultyLevel} 난이도 변환 완료!\n\n총 {noteList.Count}개 노트 생성.\n경로:\n{jsonPath}", "확인");
            AssetDatabase.Refresh();
        }
        catch (System.Exception ex)
        {
            EditorUtility.DisplayDialog("오류", $"변환 중 오류 발생:\n{ex.Message}", "닫기");
        }
    }

}
