using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// 개별 음악 슬롯 UI
/// </summary>
public class UI_MusicSlot : MonoBehaviour
{
    [Header("UI 요소")]
    [SerializeField] private TextMeshProUGUI _songNameText;
    [SerializeField] private Image _thumbnailImage;
    [SerializeField] private GameObject _lockedOverlay;
    [SerializeField] private Image _selectedOutline;
    [SerializeField] private Button _button;

    [Header("색상 설정")]
    [SerializeField] private Color _normalColor = Color.white;
    [SerializeField] private Color _selectedColor = Color.yellow;
    [SerializeField] private Color _lockedColor = Color.gray;

    private Music _music;
    private bool _isSelected;

    public Music Music => _music;
    public bool IsSelected => _isSelected;

    private void Awake()
    {
        if (_button != null)
        {
            _button.onClick.AddListener(OnClick);
        }
    }

    /// <summary>
    /// 음악 데이터로 슬롯 초기화
    /// </summary>
    public void Initialize(Music music)
    {
        _music = music;
        UpdateUI();
    }

    /// <summary>
    /// UI 업데이트
    /// </summary>
    private void UpdateUI()
    {
        if (_music == null) return;

        // 곡 이름 표시
        if (_songNameText != null)
        {
            _songNameText.text = _music.SongName;
        }

        // 썸네일 이미지 로드
        if (_thumbnailImage != null && !string.IsNullOrEmpty(_music.ThumbnailPath))
        {
            Sprite thumbnail = Resources.Load<Sprite>(_music.ThumbnailPath);
            if (thumbnail != null)
            {
                _thumbnailImage.sprite = thumbnail;
            }
        }

        // 잠금 상태 표시
        if (_lockedOverlay != null)
        {
            _lockedOverlay.SetActive(!_music.IsUnlocked);
        }

        // 버튼 상호작용 설정
        if (_button != null)
        {
            _button.interactable = _music.IsUnlocked;
        }

        // 색상 업데이트
        UpdateColor();
    }

    /// <summary>
    /// 선택 상태 설정
    /// </summary>
    public void SetSelected(bool selected)
    {
        _isSelected = selected;
        UpdateColor();

        if (_selectedOutline != null)
        {
            _selectedOutline.gameObject.SetActive(selected);
        }
    }

    /// <summary>
    /// 색상 업데이트
    /// </summary>
    private void UpdateColor()
    {
        if (_songNameText == null) return;

        if (!_music.IsUnlocked)
        {
            _songNameText.color = _lockedColor;
        }
        else if (_isSelected)
        {
            _songNameText.color = _selectedColor;
        }
        else
        {
            _songNameText.color = _normalColor;
        }
    }

    /// 클릭 이벤트
    private void OnClick()
    {
        if (_music == null || !_music.IsUnlocked) return;

        // MusicManager를 통해 곡 선택
        if (MusicManager.Instance != null)
        {
            MusicManager.Instance.SelectMusic(_music);
        }
    }

    /// <summary>
    /// 최고 점수 표시 업데이트 (옵션)
    /// </summary>
    public void UpdateHighScore()
    {
        // 필요시 최고 점수 UI 업데이트
    }
}
