using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;
/// <summary>
/// 음악 선택 UI 전체 관리
/// </summary>
public class UI_Music : MonoBehaviour
{
    [Header("슬롯 설정")]
    [SerializeField] private Transform _slotContainer;
    [SerializeField] private GameObject _musicSlotPrefab;

    [Header("선택된 곡 정보")]
    [SerializeField] private TextMeshProUGUI _selectedSongNameText;
    [SerializeField] private Image _selectedThumbnailImage;
    [SerializeField] private TextMeshProUGUI _selectedHighScoreText;

    [Header("난이도 선택")]
    [SerializeField] private Button _easyButton;
    [SerializeField] private Button _normalButton;
    [SerializeField] private Button _hardButton;
    [SerializeField] private TextMeshProUGUI _easyButtonText;
    [SerializeField] private TextMeshProUGUI _normalButtonText;
    [SerializeField] private TextMeshProUGUI _hardButtonText;

    [Header("색상 설정")]
    [SerializeField] private Color _availableDifficultyColor = Color.white;
    [SerializeField] private Color _unavailableDifficultyColor = Color.gray;
    [SerializeField] private Color _selectedDifficultyColor = Color.yellow;

    [Header("기타 버튼")]
    [SerializeField] private Button _playButton;
    [SerializeField] private Button _prevButton;
    [SerializeField] private Button _nextButton;

    private List<UI_MusicSlot> _musicSlots = new List<UI_MusicSlot>();
    private UI_MusicSlot _currentSelectedSlot;

    private void Awake()
    {
        SetupButtons();
    }

    private void Start()
    {
        // MusicManager 이벤트 구독
        if (MusicManager.Instance != null)
        {
            MusicManager.Instance.OnMusicListLoaded += OnMusicListLoaded;
            MusicManager.Instance.OnMusicSelected += OnMusicSelected;
            MusicManager.Instance.OnDifficultyChanged += OnDifficultyChanged;

            // 이미 로드된 경우 즉시 이벤트 발생 (인게임에서 로비로 돌아올 때)
            MusicManager.Instance.NotifyMusicListIfLoaded();
        }
    }

    private void OnDestroy()
    {
        // 이벤트 구독 해제
        if (MusicManager.Instance != null)
        {
            MusicManager.Instance.OnMusicListLoaded -= OnMusicListLoaded;
            MusicManager.Instance.OnMusicSelected -= OnMusicSelected;
            MusicManager.Instance.OnDifficultyChanged -= OnDifficultyChanged;
        }
    }

    /// <summary>
    /// 버튼 이벤트 설정
    /// </summary>
    private void SetupButtons()
    {
        if (_easyButton != null)
            _easyButton.onClick.AddListener(() => SelectDifficulty(EDifficulty.Easy));

        if (_normalButton != null)
            _normalButton.onClick.AddListener(() => SelectDifficulty(EDifficulty.Normal));

        if (_hardButton != null)
            _hardButton.onClick.AddListener(() => SelectDifficulty(EDifficulty.Hard));

        if (_playButton != null)
            _playButton.onClick.AddListener(OnPlayButtonClicked);

        if (_prevButton != null)
            _prevButton.onClick.AddListener(() => MusicManager.Instance?.SelectPreviousMusic());

        if (_nextButton != null)
            _nextButton.onClick.AddListener(() => MusicManager.Instance?.SelectNextMusic());
    }

    /// <summary>
    /// 음악 목록 로드 완료 시
    /// </summary>
    private void OnMusicListLoaded(List<Music> musicList)
    {
        CreateMusicSlots(musicList);
    }

    /// <summary>
    /// 음악 슬롯 생성
    /// </summary>
    private void CreateMusicSlots(List<Music> musicList)
    {
        // 기존 슬롯 제거
        foreach (var slot in _musicSlots)
        {
            if (slot != null)
                Destroy(slot.gameObject);
        }
        _musicSlots.Clear();

        // 새 슬롯 생성
        foreach (var music in musicList)
        {
            GameObject slotObj = Instantiate(_musicSlotPrefab, _slotContainer);
            UI_MusicSlot slot = slotObj.GetComponent<UI_MusicSlot>();

            if (slot != null)
            {
                slot.Initialize(music);
                _musicSlots.Add(slot);
            }
        }
    }

    /// <summary>
    /// 음악 선택 시
    /// </summary>
    private void OnMusicSelected(Music music)
    {
        // 모든 슬롯의 선택 상태 해제
        foreach (var slot in _musicSlots)
        {
            slot.SetSelected(false);
        }

        // 선택된 슬롯 찾기 및 선택 상태 설정
        _currentSelectedSlot = _musicSlots.Find(s => s.Music == music);
        if (_currentSelectedSlot != null)
        {
            _currentSelectedSlot.SetSelected(true);
        }

        // 선택된 곡 정보 표시
        UpdateSelectedMusicInfo(music);

        // 난이도 버튼 업데이트
        UpdateDifficultyButtons(music);
    }

    /// <summary>
    /// 선택된 곡 정보 업데이트
    /// </summary>
    private void UpdateSelectedMusicInfo(Music music)
    {
        if (music == null) return;

        // 곡 이름
        if (_selectedSongNameText != null)
        {
            _selectedSongNameText.text = music.SongName;
        }

        // 썸네일
        if (_selectedThumbnailImage != null && !string.IsNullOrEmpty(music.ThumbnailPath))
        {
            Sprite thumbnail = Resources.Load<Sprite>(music.ThumbnailPath);
            if (thumbnail != null)
            {
                _selectedThumbnailImage.sprite = thumbnail;
            }
        }

        // 최고 점수
        if (_selectedHighScoreText != null)
        {
            _selectedHighScoreText.text = $"High Score: {music.HighScore}";
        }
    }

    /// <summary>
    /// 난이도 버튼 업데이트
    /// </summary>
    private void UpdateDifficultyButtons(Music music)
    {
        if (music == null) return;

        UpdateDifficultyButton(_easyButton, _easyButtonText, music.HasDifficulty(EDifficulty.Easy), 
            MusicManager.Instance.SelectedDifficulty == EDifficulty.Easy);

        UpdateDifficultyButton(_normalButton, _normalButtonText, music.HasDifficulty(EDifficulty.Normal), 
            MusicManager.Instance.SelectedDifficulty == EDifficulty.Normal);

        UpdateDifficultyButton(_hardButton, _hardButtonText, music.HasDifficulty(EDifficulty.Hard), 
            MusicManager.Instance.SelectedDifficulty == EDifficulty.Hard);
    }

    /// <summary>
    /// 개별 난이도 버튼 업데이트
    /// </summary>
    private void UpdateDifficultyButton(Button button, TextMeshProUGUI text, bool isAvailable, bool isSelected)
    {
        if (button == null || text == null) return;

        button.interactable = isAvailable;

        if (isSelected)
        {
            text.color = _selectedDifficultyColor;
        }
        else if (isAvailable)
        {
            text.color = _availableDifficultyColor;
        }
        else
        {
            text.color = _unavailableDifficultyColor;
        }
    }

    /// <summary>
    /// 난이도 선택
    /// </summary>
    private void SelectDifficulty(EDifficulty difficulty)
    {
        if (MusicManager.Instance != null)
        {
            MusicManager.Instance.SelectDifficulty(difficulty);
        }
    }

    /// <summary>
    /// 난이도 변경 시
    /// </summary>
    private void OnDifficultyChanged(EDifficulty difficulty)
    {
        if (MusicManager.Instance?.SelectedMusic != null)
        {
            UpdateDifficultyButtons(MusicManager.Instance.SelectedMusic);
        }
    }

    /// <summary>
    /// 플레이 버튼 클릭
    /// </summary>
    private void OnPlayButtonClicked()
    {
        if (MusicManager.Instance?.SelectedMusic == null)
        {
            Debug.LogWarning("선택된 곡이 없습니다.");
            return;
        }

        string chartPath = MusicManager.Instance.GetSelectedChartPath();
        if (string.IsNullOrEmpty(chartPath))
        {
            Debug.LogWarning("선택된 난이도의 차트가 없습니다.");
            return;
        }

        // 인게임 씬으로 전환
        FadeManager.Instance.FadeToScene("LoadingScene");

        //SceneManager.LoadScene("InGame");
        //Debug.Log($"게임 시작: {MusicManager.Instance.SelectedMusic.SongName} - {MusicManager.Instance.SelectedDifficulty}");
    }
}
