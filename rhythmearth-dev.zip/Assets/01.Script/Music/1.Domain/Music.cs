using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EDifficulty
{
    Easy,   // 쉬움
    Normal, // 보통
    Hard    // 어려움 (원본)
}

public class Music
{
    // 기본 정보
    public string SongId { get; private set; }
    public string SongName { get; private set; }
    public string AudioClipPath { get; private set; }
    public string ThumbnailPath { get; private set; }

    public Dictionary<EDifficulty, ChartInfo> Charts { get; private set; }

    public bool IsUnlocked { get; private set; }            // 해금 여부
    public int HighScore { get; private set; }              // 최고 점수

    public Music(
        string songId,
        string songName,
        string audioClipPath,
        string thumbnailPath = "",
        bool isUnlocked = true)
    {
        SongId = songId;
        SongName = songName;
        AudioClipPath = audioClipPath;
        ThumbnailPath = thumbnailPath;
        IsUnlocked = isUnlocked;
        HighScore = 0;

        Charts = new Dictionary<EDifficulty, ChartInfo>();
    }

    public void AddChart(EDifficulty difficulty, string chartPath, int noteCount)
    {
        if (!Charts.ContainsKey(difficulty))
        {
            Charts[difficulty] = new ChartInfo(chartPath, noteCount);
        }
    }

    public string GetChartPath(EDifficulty difficulty)
    {
        if (Charts.TryGetValue(difficulty, out ChartInfo chartInfo))
        {
            return chartInfo.ChartPath;
        }
        return null;
    }

    public bool HasDifficulty(EDifficulty difficulty)
    {
        return Charts.ContainsKey(difficulty);
    }

    public List<EDifficulty> GetAvailableDifficulties()
    {
        return new List<EDifficulty>(Charts.Keys);
    }

    public void Unlock()
    {
        IsUnlocked = true;
    }

    public void UpdateHighScore(int score)
    {
        if (score > HighScore)
        {
            HighScore = score;
        }
    }
}

public class ChartInfo
{
    public string ChartPath { get; private set; }       // 차트 파일 경로 (Resources/Charts 기준)
    public int NoteCount { get; private set; }          // 노트 개수

    public ChartInfo(string chartPath, int noteCount)
    {
        ChartPath = chartPath;
        NoteCount = noteCount;
    }
}
