using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System;

/// <summary>
/// 구글 스프레드시트에서 음악 정보를 가져오는 Repository
/// </summary>
public class MusicRepository
{
    private const string SPREADSHEET_URL = "YOUR_GOOGLE_SPREADSHEET_CSV_URL_HERE";
    
    /// 구글 스프레드시트에서 음악 목록을 비동기로 로드
    public IEnumerator LoadMusicListFromSpreadsheet(Action<List<Music>> onComplete, Action<string> onError)
    {
        using (UnityWebRequest request = UnityWebRequest.Get(SPREADSHEET_URL))
        {
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                onError?.Invoke($"스프레드시트 로드 실패: {request.error}");
                yield break;
            }

            string csvData = request.downloadHandler.text;
            List<Music> musicList = ParseCSVToMusicList(csvData);
            
            onComplete?.Invoke(musicList);
        }
    }

    /// CSV 데이터를 Music 리스트로 파싱
    /// CSV 형식: SongId, SongName, Duration, AudioPath, ThumbnailPath, IsUnlocked, EasyChart, NormalChart, HardChart
    private List<Music> ParseCSVToMusicList(string csvData)
    {
        List<Music> musicList = new List<Music>();
        
        string[] lines = csvData.Split('\n');
        
        // 첫 번째 줄은 헤더이므로 건너뜀
        for (int i = 1; i < lines.Length; i++)
        {
            string line = lines[i].Trim();
            if (string.IsNullOrEmpty(line)) continue;

            try
            {
                Music music = ParseLineToMusic(line);
                if (music != null)
                {
                    musicList.Add(music);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"CSV 파싱 오류 (라인 {i + 1}): {e.Message}");
            }
        }

        Debug.Log($"총 {musicList.Count}개의 음악 정보를 로드했습니다.");
        return musicList;
    }

    /// CSV 한 줄을 Music 객체로 변환
    private Music ParseLineToMusic(string line)
    {
        string[] values = SplitCSVLine(line);
        
        if (values.Length < 8)
        {
            Debug.LogWarning($"CSV 데이터 형식 오류: {line}");
            return null;
        }

        // CSV 데이터 파싱
        string songId = values[0].Trim();
        string songName = values[1].Trim();
        string audioPath = values[2].Trim();
        string thumbnailPath = values[3].Trim();
        bool isUnlocked = ParseBool(values[4]);
        
        // Music 객체 생성
        Music music = new Music(
            songId,
            songName,
            audioPath,
            thumbnailPath,
            isUnlocked
        );

        // 난이도별 차트 정보 추가
        AddChartIfExists(music, EDifficulty.Easy, values[5]);
        AddChartIfExists(music, EDifficulty.Normal, values[6]);
        AddChartIfExists(music, EDifficulty.Hard, values[7]);

        return music;
    }

    /// CSV 라인을 쉼표로 분리 (따옴표 안의 쉼표는 무시)
    private string[] SplitCSVLine(string line)
    {
        List<string> result = new List<string>();
        bool inQuotes = false;
        string currentValue = "";

        for (int i = 0; i < line.Length; i++)
        {
            char c = line[i];

            if (c == '"')
            {
                inQuotes = !inQuotes;
            }
            else if (c == ',' && !inQuotes)
            {
                result.Add(currentValue);
                currentValue = "";
            }
            else
            {
                currentValue += c;
            }
        }

        result.Add(currentValue);
        return result.ToArray();
    }

    /// 차트 정보가 있으면 Music에 추가
    private void AddChartIfExists(Music music, EDifficulty difficulty, string chartPath)
    {
        chartPath = chartPath.Trim();
        if (!string.IsNullOrEmpty(chartPath))
        {
            // 차트 파일에서 노트 개수 가져오기 (옵션)
            int noteCount = GetNoteCountFromChart(chartPath);
            music.AddChart(difficulty, chartPath, noteCount);
        }
    }

    /// 차트 파일에서 노트 개수 가져오기
    private int GetNoteCountFromChart(string chartPath)
    {
        try
        {
            var textAsset = Resources.Load<TextAsset>($"Charts/{chartPath}");
            if (textAsset != null)
            {
                Chart chart = JsonUtility.FromJson<Chart>(textAsset.text);
                return chart?.notes?.Count ?? 0;
            }
        }
        catch (Exception e)
        {
            Debug.LogWarning($"차트 파일 로드 실패 ({chartPath}): {e.Message}");
        }
        
        return 0;
    }

    /// 문자열을 bool로 파싱
    private bool ParseBool(string value)
    {
        value = value.Trim().ToLower();
        return value == "true" || value == "1" || value == "yes" || value == "o";
    }

    /// 로컬 CSV 파일에서 음악 목록 로드 (테스트용)
    public List<Music> LoadMusicListFromLocalCSV(string csvFilePath)
    {
        try
        {
            TextAsset csvFile = Resources.Load<TextAsset>(csvFilePath);
            if (csvFile != null)
            {
                return ParseCSVToMusicList(csvFile.text);
            }
            else
            {
                Debug.LogError($"CSV 파일을 찾을 수 없습니다: {csvFilePath}");
                return new List<Music>();
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"CSV 파일 로드 오류: {e.Message}");
            return new List<Music>();
        }
    }
}
