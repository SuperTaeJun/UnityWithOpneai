using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 음악 선택 및 관리를 담당하는 Manager
/// </summary>
public class MusicManager : PersistentSingleton<MusicManager>
{
    private MusicRepository _repository;
    private List<Music> _availableMusics = new List<Music>();
    private Music _selectedMusic;
    private EDifficulty _selectedDifficulty = EDifficulty.Normal;

    // 이벤트
    public event System.Action<Music> OnMusicSelected;
    public event System.Action<EDifficulty> OnDifficultyChanged;
    public event System.Action<List<Music>> OnMusicListLoaded;

    // 프로퍼티
    public Music SelectedMusic => _selectedMusic;
    public EDifficulty SelectedDifficulty => _selectedDifficulty;
    public List<Music> AvailableMusics => _availableMusics;
    public bool IsLoaded { get; private set; }

    [Header("설정")]
    [SerializeField] private bool _useLocalCSV = false;
    [SerializeField] private string _localCSVPath = "MusicData";

    protected override void Awake()
    {
        base.Awake();
        _repository = new MusicRepository();
    }

    private void Start()
    {
        LoadMusicList();
    }

    /// 음악 목록 로드
    public void LoadMusicList()
    {
        if (_useLocalCSV)
        {
            // 로컬 CSV 파일에서 로드 (테스트용)
            LoadFromLocalCSV();
        }
        else
        {
            // 구글 스프레드시트에서 로드
            StartCoroutine(LoadFromSpreadsheet());
        }
    }

    /// <summary>
    /// 이미 로드된 음악 리스트가 있으면 즉시 이벤트 발생
    /// 로비 씬으로 돌아올 때 UI를 다시 초기화하기 위해 사용
    /// </summary>
    public void NotifyMusicListIfLoaded()
    {
        if (IsLoaded && _availableMusics.Count > 0)
        {
            OnMusicListLoaded?.Invoke(_availableMusics);

            // 선택된 곡이 있으면 해당 이벤트도 발생
            if (_selectedMusic != null)
            {
                OnMusicSelected?.Invoke(_selectedMusic);
            }
        }
    }

    /// 로컬 CSV 파일에서 음악 목록 로드
    private void LoadFromLocalCSV()
    {
        _availableMusics = _repository.LoadMusicListFromLocalCSV(_localCSVPath);
        IsLoaded = true;
        OnMusicListLoaded?.Invoke(_availableMusics);

        // 첫 번째 곡을 기본 선택
        if (_availableMusics.Count > 0)
        {
            SelectMusic(_availableMusics[0]);
        }
    }

    /// 구글 스프레드시트에서 음악 목록 로드
    private IEnumerator LoadFromSpreadsheet()
    {
        yield return _repository.LoadMusicListFromSpreadsheet(
            onComplete: (musicList) =>
            {
                _availableMusics = musicList;
                IsLoaded = true;
                OnMusicListLoaded?.Invoke(_availableMusics);

                // 첫 번째 곡을 기본 선택
                if (_availableMusics.Count > 0)
                {
                    SelectMusic(_availableMusics[0]);
                }
            },
            onError: (error) =>
            {
                Debug.LogError($"음악 목록 로드 실패: {error}");
                IsLoaded = false;
            }
        );
    }

    /// 음악 선택
    public void SelectMusic(Music music)
    {
        if (music == null)
        {
            Debug.LogWarning("선택하려는 음악이 null입니다.");
            return;
        }

        if (!music.IsUnlocked)
        {
            Debug.LogWarning($"'{music.SongName}'은(는) 아직 해금되지 않았습니다.");
            return;
        }

        _selectedMusic = music;

        // 선택한 곡에 현재 난이도가 없으면 사용 가능한 첫 번째 난이도로 설정
        if (!_selectedMusic.HasDifficulty(_selectedDifficulty))
        {
            var availableDifficulties = _selectedMusic.GetAvailableDifficulties();
            if (availableDifficulties.Count > 0)
            {
                _selectedDifficulty = availableDifficulties[0];
            }
        }

        OnMusicSelected?.Invoke(_selectedMusic);
        Debug.Log($"음악 선택: {music.SongName}");
    }

    /// 난이도 선택
    public void SelectDifficulty(EDifficulty difficulty)
    {
        if (_selectedMusic == null)
        {
            Debug.LogWarning("선택된 음악이 없습니다.");
            return;
        }

        if (!_selectedMusic.HasDifficulty(difficulty))
        {
            Debug.LogWarning($"'{_selectedMusic.SongName}'에는 {difficulty} 난이도가 없습니다.");
            return;
        }

        _selectedDifficulty = difficulty;
        OnDifficultyChanged?.Invoke(_selectedDifficulty);
        Debug.Log($"난이도 선택: {difficulty}");
    }

    /// /// 선택된 곡의 차트 경로 가져오기
    public string GetSelectedChartPath()
    {
        if (_selectedMusic == null)
        {
            Debug.LogWarning("선택된 음악이 없습니다.");
            return null;
        }

        return _selectedMusic.GetChartPath(_selectedDifficulty);
    }

    /// 특정 ID의 음악 찾기
    public Music FindMusicById(string songId)
    {
        return _availableMusics.Find(m => m.SongId == songId);
    }

    /// 해금된 음악만 가져오기
    public List<Music> GetUnlockedMusics()
    {
        return _availableMusics.FindAll(m => m.IsUnlocked);
    }

    /// 음악 해금
    public void UnlockMusic(string songId)
    {
        Music music = FindMusicById(songId);
        if (music != null)
        {
            music.Unlock();
            Debug.Log($"'{music.SongName}' 해금!");
        }
    }

    /// 최고 점수 업데이트
    public void UpdateHighScore(string songId, int score)
    {
        Music music = FindMusicById(songId);
        if (music != null)
        {
            music.UpdateHighScore(score);
            Debug.Log($"'{music.SongName}' 최고 점수 업데이트: {score}");
        }
    }

    /// 다음 곡 선택
    public void SelectNextMusic()
    {
        if (_availableMusics.Count == 0 || _selectedMusic == null) return;

        int currentIndex = _availableMusics.IndexOf(_selectedMusic);
        int nextIndex = (currentIndex + 1) % _availableMusics.Count;
        SelectMusic(_availableMusics[nextIndex]);
    }

    /// 이전 곡 선택
    public void SelectPreviousMusic()
    {
        if (_availableMusics.Count == 0 || _selectedMusic == null) return;

        int currentIndex = _availableMusics.IndexOf(_selectedMusic);
        int previousIndex = (currentIndex - 1 + _availableMusics.Count) % _availableMusics.Count;
        SelectMusic(_availableMusics[previousIndex]);
    }
}
