using System.Collections;
using System.Collections.Generic;

// 고스트탭,탭탭,멀티탭,홀드 등은 타이밍까지 이동애니메이션과 파괴될때 애니메이션 연출이 달라서 따로 한번더 구현해줌
// 나머지는 위치만 따르게 표현할때 구분하기 위함 Mirro의 경우 좌우좌우 반복
public enum ENoteType
{
    Tap,
    Hold,
    MultiTapNote,
    HoldTap,
    Mirro,
    LeftTap,
    RightTap,
    UpTap,
    DoubleTap,
    GhostTap,
}

public enum EDirectionType
{
    Up,
    Left,
    Right,
    None,
}

public class Note
{
    public ENoteType NoteType { get; private set; }
    public EDirectionType TargetDir { get; private set; }
    public float TargetTime { get; private set; }
    public bool IsJudged { get; private set; }
    public bool IsActivated { get; private set; }
    public float HoldDurationTime { get; private set; }
    public UnityEngine.Vector2 TilePosition { get; private set; }
    public UnityEngine.Vector3 HoldEndPosition { get; private set; }

    //홀드 비트일때만
    public Note(ENoteType noteType, EDirectionType targetDir, float targetTime, float holdDurationTime = 0)
    {
        NoteType = noteType;
        TargetDir = targetDir;
        TargetTime = targetTime;
        HoldDurationTime = holdDurationTime;
        IsJudged = false;
        IsActivated = false;
        TilePosition = UnityEngine.Vector2.zero;

        //탭 노트일때 생성자에서 실수 방지
        if (ENoteType.Tap == NoteType)
            HoldDurationTime = 0;
    }
    public void Judge()
    {
        if (IsJudged) return;

        IsJudged = true;
    }

    public void Activate()
    {
        IsActivated = true;
    }

    public void SetTilePosition(UnityEngine.Vector2 position)
    {
        TilePosition = position;
    }

    public void SetHoldEndPosition(UnityEngine.Vector3 endPosition)
    {
        HoldEndPosition = endPosition;
    }

}
