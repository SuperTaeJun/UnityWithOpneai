using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class NoteRepository
{
    public Queue<Note> LoadChartAndSetupGame(string songName)
    {
        var textAsset = Resources.Load<TextAsset>($"Charts/{songName}");
        if (textAsset == null)
        {
            Debug.LogError($"차트 파일을 찾을 수 없습니다: Charts/{songName}");
            return null;
        }

        Chart chart = JsonUtility.FromJson<Chart>(textAsset.text);
        Queue<Note> notes = new Queue<Note>();

        if (chart == null) return null;

        var notesArray = chart.notes.ToArray();
        Array.Sort(notesArray, (a, b) => a.targetTime.CompareTo(b.targetTime));
        var sortedNotes = notesArray;

        var allDirections = System.Enum.GetValues(typeof(EDirectionType)).Cast<EDirectionType>().ToList();
        allDirections.Remove(EDirectionType.None);
        allDirections.Remove(EDirectionType.Up);

        EDirectionType lastDirection = EDirectionType.None;
        EDirectionType currentHoldDirection = EDirectionType.None;
        EDirectionType lastMirrorDirection = EDirectionType.Left;

        int currentLine = 3; // 1~7의 중앙 라인

        for (int i = 0; i < sortedNotes.Length; i++)
        {
            var noteData = sortedNotes[i];
            EDirectionType randomDir;

            bool isLastNote = (i == sortedNotes.Length - 1);
            if (isLastNote && currentLine != 4)
            {
                if (currentLine < 4) randomDir = EDirectionType.Right;
                else randomDir = EDirectionType.Left;

                lastDirection = randomDir;
            }
            else
            {
                // === UpTap ===
                if (noteData.noteType == ENoteType.UpTap)
                {
                    randomDir = EDirectionType.Up;
                    lastDirection = randomDir;
                }
                // === LeftTap ===
                else if (noteData.noteType == ENoteType.LeftTap)
                {
                    var valid = GetValidDirections(currentLine, new List<EDirectionType> { EDirectionType.Left });
                    if (valid.Count > 0) randomDir = valid[0];
                    else
                    {
                        valid = GetValidDirections(currentLine, new List<EDirectionType> { EDirectionType.Right });
                        randomDir = valid.Count > 0 ? valid[0] : EDirectionType.Left;
                    }
                    lastDirection = randomDir;
                }
                // === RightTap ===
                else if (noteData.noteType == ENoteType.RightTap)
                {
                    var valid = GetValidDirections(currentLine, new List<EDirectionType> { EDirectionType.Right });
                    if (valid.Count > 0) randomDir = valid[0];
                    else
                    {
                        valid = GetValidDirections(currentLine, new List<EDirectionType> { EDirectionType.Left });
                        randomDir = valid.Count > 0 ? valid[0] : EDirectionType.Right;
                    }
                    lastDirection = randomDir;
                }
                // === Mirror ===
                else if (noteData.noteType == ENoteType.Mirro)
                {
                    EDirectionType targetDir = GetOppositeDirection(lastMirrorDirection);
                    var valid = GetValidDirections(currentLine, new List<EDirectionType> { targetDir });

                    if (valid.Count > 0)
                    {
                        randomDir = valid[0];
                    }
                    else
                    {
                        valid = GetValidDirections(currentLine, new List<EDirectionType> { lastMirrorDirection });
                        randomDir = valid.Count > 0 ? valid[0] : lastMirrorDirection;
                    }

                    lastMirrorDirection = randomDir;
                    lastDirection = randomDir;
                }
                // === Hold ===
                else if (noteData.noteType == ENoteType.Hold)
                {
                    var holdDirs = new List<EDirectionType> { EDirectionType.Left, EDirectionType.Right };

                    if (lastDirection == EDirectionType.Left || lastDirection == EDirectionType.Right)
                        holdDirs.Remove(lastDirection);

                    var valid = GetValidDirections(currentLine, holdDirs);

                    randomDir = valid[UnityEngine.Random.Range(0, valid.Count)];

                    currentHoldDirection = randomDir;
                    lastDirection = randomDir;
                }
                // === HoldTap ===
                else if (noteData.noteType == ENoteType.HoldTap)
                {
                    if (currentHoldDirection != EDirectionType.None)
                    {
                        EDirectionType targetDir = GetOppositeDirection(currentHoldDirection);
                        var valid = GetValidDirections(currentLine, new List<EDirectionType> { targetDir });

                        if (valid.Count > 0) randomDir = valid[0];
                        else
                        {
                            valid = GetValidDirections(currentLine, new List<EDirectionType> { currentHoldDirection });
                            randomDir = valid.Count > 0 ? valid[0] : targetDir;
                        }
                    }
                    else
                    {
                        var valid = GetValidDirections(currentLine, new List<EDirectionType> { EDirectionType.Right });
                        randomDir = valid.Count > 0 ? valid[0] : EDirectionType.Right;
                    }

                    lastDirection = randomDir;
                }
                else
                {
                    currentHoldDirection = EDirectionType.None;

                    var valid = GetValidDirections(currentLine, allDirections);

                    randomDir = valid[UnityEngine.Random.Range(0, valid.Count)];
                    lastDirection = randomDir;
                }
            }

            Note note = new Note
            (
                noteData.noteType,
                randomDir,
                noteData.targetTime,
                noteData.holdDurationTime
            );

            notes.Enqueue(note);

            int prev = currentLine;
            currentLine = UpdateLine(currentLine, randomDir);

            if (currentLine < 1 || currentLine > 7)
            {
                Debug.LogError($"[노트 {i}] 라인 오류: {prev} -> {currentLine}, dir={randomDir}");
            }

            // === DoubleTap 처리 ===
            if (noteData.noteType == ENoteType.DoubleTap)
            {
                Note second = new Note
                (
                    noteData.noteType,
                    randomDir,
                    noteData.targetTime + 0.1f,
                    noteData.holdDurationTime
                );

                notes.Enqueue(second);

                prev = currentLine;
                currentLine = UpdateLine(currentLine, randomDir);
            }
        }

        Debug.Log($"{songName} 차트 로딩 완료! 총 {sortedNotes.Length}개");
        return notes;
    }


    private EDirectionType GetOppositeDirection(EDirectionType dir)
    {
        switch (dir)
        {
            case EDirectionType.Left: return EDirectionType.Right;
            case EDirectionType.Right: return EDirectionType.Left;
            default: return EDirectionType.None;
        }
    }

    /// 현재 라인(1~7)에서 이동 가능한 방향 반환
    private List<EDirectionType> GetValidDirections(int currentLine, List<EDirectionType> baseDirs)
    {
        var valid = new List<EDirectionType>(baseDirs);

        if (currentLine <= 1)
            valid.Remove(EDirectionType.Left);

        if (currentLine >= 5)
            valid.Remove(EDirectionType.Right);

        if (valid.Count == 0)
        {
            foreach (var dir in baseDirs)
            {
                var opp = GetOppositeDirection(dir);
                if (opp != EDirectionType.None)
                    return new List<EDirectionType> { opp };
            }
        }

        return valid;
    }

    /// 방향에 따라 라인 업데이트 (1~7 범위)
    private int UpdateLine(int currentLine, EDirectionType direction)
    {
        switch (direction)
        {
            case EDirectionType.Left:
                return Mathf.Max(1, currentLine - 1);
            case EDirectionType.Right:
                return Mathf.Min(5, currentLine + 1); // 6 → 7
            case EDirectionType.Up:
                return currentLine;
        }
        return currentLine;
    }
}
