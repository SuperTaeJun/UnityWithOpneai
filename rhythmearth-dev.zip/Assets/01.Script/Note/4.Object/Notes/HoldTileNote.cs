using UnityEngine;
using DG.Tweening;

public class HoldTileNote : TileNoteBase
{
    [Header("홀드 노트 설정")]
    [SerializeField] private Transform _endPosition;
    public Transform EndPosition => _endPosition;

    [SerializeField]
    private SpriteRenderer body;
    private Color originalColor;

    protected override void Awake()
    {
        base.Awake();
        originalColor = body.color;
    }
    protected override void OnEnable()
    {
        base.OnEnable();
        if (NoteManager.Instance)
            NoteManager.Instance.OnMiss += OnMiss;

        // 색상 및 스케일 초기화
        Color resetColor = originalColor;
        resetColor.a = 1f;
        body.color = resetColor;
        transform.localScale = Vector3.one;
    }
    protected override void OnDisable()
    {
        base.OnDisable();
        if (NoteManager.Instance)
            NoteManager.Instance.OnMiss -= OnMiss;
    }
    private void OnMiss(Note note)
    {
        if (note != NoteData) return;

        body.color = Color.red;

    }

    public override void Initialize(Note noteData, double approachDuration, Transform player)
    {
        base.Initialize(noteData, approachDuration, player);

        // PlayerJudgeLine의 속도를 가져와서 홀드 노트 길이 계산

        float judgeLineSpeed = 7F;
        float totalBodyLength = (float)noteData.HoldDurationTime * judgeLineSpeed;

        if (body != null)
        {
            body.size = new Vector2(body.size.x, totalBodyLength);
        }

        float halfLength = totalBodyLength / 2.0f;

        if (_landingPosition != null)
        {
            _landingPosition.localPosition = new Vector3(0, -halfLength, 0);
        }

        if (_endPosition != null)
        {
            _endPosition.localPosition = new Vector3(0, halfLength, 0);
        }
    }

    /// 홀드 타일의 코믹한 파괴 연출
    public override void DestroyTile()
    {
        if (_isDestroying) return;
        _isDestroying = true;

        DestroyEffect_Noodle();

    }


    /// 효과 3: 풍선 바람 빠지듯 회전하며 날아가기
    private void DestroyEffect_Balloon()
    {
        Sequence seq = DOTween.Sequence();

        // 지그재그로 날아가며 회전 (아래로)
        Vector3 currentPos = transform.localPosition;

        seq.Append(transform.DOLocalMove(currentPos + new Vector3(1.5f, -0.5f, 0), 0.15f));
        seq.Append(transform.DOLocalMove(currentPos + new Vector3(-1.5f, -1f, 0), 0.15f));
        seq.Append(transform.DOLocalMove(currentPos + new Vector3(1f, -1.5f, 0), 0.15f));
        seq.Append(transform.DOLocalMove(currentPos + new Vector3(-0.5f, -2f, 0), 0.15f));

        seq.Join(transform.DOLocalRotate(new Vector3(0, 0, 1080f), 0.6f, RotateMode.FastBeyond360));
        seq.Join(transform.DOScale(Vector3.zero, 0.6f).SetEase(Ease.InQuad));
        seq.Join(body.DOFade(0f, 0.6f));

        seq.OnComplete(() => ObjectPool.Instance.Return(gameObject));
    }

    /// 효과 4: 국수처럼 한쪽으로 빨려들어가기
    private void DestroyEffect_Noodle()
    {
        Sequence seq = DOTween.Sequence();

        // 아래쪽으로 빨려들어가는 효과
        float direction = -1f;

        // Y축 스케일만 0으로 줄어들면서 회전하고 이동
        seq.Append(transform.DOScaleY(0f, 0.4f).SetEase(Ease.InQuint));
        seq.Join(transform.DOLocalMoveY(transform.localPosition.y + (5f * direction), 0.4f).SetEase(Ease.InQuad));
        seq.Join(transform.DOLocalRotate(new Vector3(0, 0, 360f * direction), 0.4f, RotateMode.FastBeyond360));
        seq.Join(body.DOFade(0f, 0.3f).SetDelay(0.1f));

        seq.OnComplete(() => ObjectPool.Instance.Return(gameObject));
    }
}
