using UnityEngine;
using DG.Tweening;

public class MultiTapTileNote : TileNoteBase
{
    [SerializeField] Transform _tapTextSprite;
    [SerializeField] float _floatDistance = 0.4f; // 떠오르는 거리
    [SerializeField] float _floatDuration = 0.5f; // 한 사이클 시간
    [SerializeField] float _floatScale = 1.5f;   // 스케일 크기
    protected override void OnEnable()
    {
        base.OnEnable();

        TapTextLoop();
        _tapTextSprite.localScale = Vector3.one;

        if (NoteManager.Instance == null) return;
        NoteManager.Instance.OnMiss += OnMiss;
    }
    protected override void OnDisable()
    {
        base.OnDisable();
        _tapTextSprite.DOKill();
        if (NoteManager.Instance == null) return;
        NoteManager.Instance.OnMiss -= OnMiss;

    }
    private void OnMiss(Note note)
    {
        if (note != NoteData) return;

        _tapTextSprite.DOKill();
        _tapTextSprite.DOScale(0f, 0.2f);
    }


    private void TapTextLoop()
    {
        // 현재 로컬 포지션 저장
        Vector3 startPos = _tapTextSprite.localPosition;

        // 둥실둥실 떠있는 애니메이션
        _tapTextSprite.DOLocalMoveY(startPos.y + _floatDistance, _floatDuration)
            .SetEase(Ease.InOutSine)
            .SetLoops(-1, LoopType.Yoyo);

        // 스케일 애니메이션 (커졌다 작아졌다 반복)
        _tapTextSprite.DOScale(_floatScale, _floatDuration)
            .SetEase(Ease.InOutSine)
            .SetLoops(-1, LoopType.Yoyo);
    }


    public override void DestroyTile()
    {
        if (_isDestroying) return;
        _isDestroying = true;

        _tapTextSprite.DOKill();

        ObjectPool.Instance.Get(EPoolType.NoteHitVfx).transform.position = transform.position;

        // 간단한 축소 및 페이드아웃 연출
        Sequence seq = DOTween.Sequence();

        seq.Append(transform.DOScale(Vector3.zero, 0.5f).SetEase(Ease.InBack));
        seq.Join(GetComponent<SpriteRenderer>().DOFade(0f, 0.5f));
        seq.OnComplete(() =>
        {
            ObjectPool.Instance.Return(gameObject);
        });
    }
}
