using UnityEngine;
using DG.Tweening;
public class GhostTapTileNote : TileNoteBase
{
    [Header("파괴 연출 설정")]
    [Tooltip("점프 최고 높이")]
    [SerializeField] private float jumpPower = 1.5f;
    [Tooltip("옆으로 날아갈 거리")]
    [SerializeField] private float flingDistance = 2.0f;
    [Tooltip("최종적으로 떨어질 거리 (현재 위치 기준)")]
    [SerializeField] private float fallDistance = 3.0f;
    [Tooltip("총 연출 시간")]
    [SerializeField] private float duration = 1.0f;
    [Tooltip("총 회전 각도")]
    [SerializeField] private float rotationAmount = 720f; // 2바퀴

    [Tooltip("페이드 시작 지점 (0~1, 0.5 = 중간지점)")]
    [SerializeField] private SpriteRenderer _approachingTileRenderer;

    /// 기본 타일의 파괴 연출: 점프하면서 회전하고 페이드아웃
    public override void DestroyTile()
    {
        if (_isDestroying) return;
        _isDestroying = true;

        // 투명도 초기화 (완전 불투명)
        if (_approachingTileRenderer != null)
        {
            Color color = _approachingTileRenderer.color;
            color.a = 1f;
            _approachingTileRenderer.color = color;
        }


        //ObjectPool.Instance.Get(EPoolType.NoteHitVfx).transform.position = transform.position;

        // 타겟 위치 및 회전 계산
        float targetX = transform.position.x;
        float targetRotation = rotationAmount;

        float startY = transform.position.y;
        float peakY = startY + jumpPower;
        float endY = startY - fallDistance;

        float timeToPeak = duration * 0.4f;
        float timeToFall = duration * 0.6f;

        // 방향에 따른 연출 조정
        if (_noteData.TargetDir == EDirectionType.Left)
        {
            targetX += flingDistance;
            targetRotation = -targetRotation;
        }
        else if (_noteData.TargetDir == EDirectionType.Right)
        {
            targetX -= flingDistance;
        }
        else if (_noteData.TargetDir == EDirectionType.Up)
        {
            targetX += Random.Range(-flingDistance * 0.5f, flingDistance * 0.5f);
        }

        // DOTween 시퀀스 생성
        Sequence seq = DOTween.Sequence();

        // Y축 이동: 점프 (위로)
        seq.Append(
            transform.DOMoveY(peakY, timeToPeak).SetEase(Ease.OutQuad)
        );

        // Y축 이동: 낙하 (아래로)
        seq.Append(
            transform.DOMoveY(endY, timeToFall).SetEase(Ease.InQuad)
        );

        // X축 이동 (동시 진행)
        seq.Insert(0,
            transform.DOMoveX(targetX, duration).SetEase(Ease.Linear)
        );

        // 회전 (동시 진행)
        seq.Insert(0,
            transform.DORotate(new Vector3(0, 0, targetRotation), duration, RotateMode.FastBeyond360)
                     .SetEase(Ease.Linear)
        );

        // 페이드 아웃 (낙하 시작 시점부터)
        if (_renderer != null)
        {
            seq.Insert(timeToPeak,
                _renderer.DOFade(0f, timeToFall).SetEase(Ease.InQuad)
            );
        }

        // 완료 시 오브젝트 풀로 반환
        seq.OnComplete(() =>
        {
            ObjectPool.Instance.Return(gameObject);
        });

        seq.SetTarget(this.gameObject);
    }

    protected override void OnPlayerLandTile(Note note)
    {
        base.OnPlayerLandTile(note);

        // _approachingTileRenderer가 할당되지 않았으면 스킵
        if (_approachingTileRenderer == null) return;

        Color color = _approachingTileRenderer.color;
        color.a = 1f;
        _approachingTileRenderer.color = color;
    }

    protected override void OnEnable()
    {
        base.OnEnable();
    

        // 투명도 초기화 (완전 불투명)
        if (_approachingTileRenderer != null)
        {
            Color color = _approachingTileRenderer.color;
            color.a = 1f;
            _approachingTileRenderer.color = color;
        }
    }
}
