using UnityEngine;
using DG.Tweening;

public abstract class TileNoteBase : MonoBehaviour
{
    [Header("타일 기본 설정")]
    [SerializeField] protected Transform _landingPosition;
    public Transform LandingPositionTransform => _landingPosition;
    [SerializeField] protected SpriteRenderer _renderer;

    [Header("타일 이동 설정")]
    [SerializeField] protected float flyInDistance = 5.0f;

    [Header("VFX 설정")]
    [SerializeField] protected GameObject _tilePerpectVfxPrefab;

    [Header("디버그")]
    [SerializeField] protected bool _useSoundTest;

    // 공통 프로퍼티
    public Vector2 LandingPosition => _landingPosition.position;
    public Note NoteData => _noteData;

    // 공통 필드
    protected Note _noteData;
    protected double _spawnTime;
    protected double _approachDuration;
    protected bool _isStartingApproach = false;
    protected Vector3 _startPosition;
    protected bool _useFlyIn = false;
    protected bool _isDestroying = false;
    protected Vector3 _originScale;
    protected bool _debugsoundComplete;
    private Sequence _suckTween;
    protected virtual void Awake()
    {
        _originScale = transform.localScale;
    }

    protected virtual void OnEnable()
    {
        // DOTween 정리
        transform.DOKill(this);
        _renderer.DOKill(this);

        // 상태 초기화
        _isDestroying = false;
        _isStartingApproach = false;

        // 트랜스폼 리셋
        transform.position = Vector3.one;
        transform.rotation = Quaternion.identity;
        transform.localScale = _originScale;

        // 데이터 리셋
        _noteData = null;
        _approachDuration = 0f;
        _spawnTime = 0f;

        // 렌더러 알파 리셋
        if (_renderer != null)
        {
            Color color = _renderer.color;
            color.a = 1f;
            _renderer.color = color;
        }
        _debugsoundComplete = false;

        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnPlayerLandTile += OnPlayerLandTile;
            NoteManager.Instance.OnNoteTarget += SuckInTile;

        }
    }
    protected virtual void OnDisable()
    {
        if (NoteManager.Instance != null)
        {
            NoteManager.Instance.OnPlayerLandTile -= OnPlayerLandTile;
            NoteManager.Instance.OnNoteTarget -= SuckInTile;
        }
    }
    protected virtual void SuckInTile(float TargetTime)
    {
        if (_noteData.TargetTime != TargetTime) return;

        // 기존 트윈 재생 중이면 무시
        if (_suckTween != null && _suckTween.IsActive()) return;

        Vector3 shrinkScale = _originScale * 0.9f;
        Vector3 growScale = _originScale * 1.1f;
        float targetY = transform.localPosition.y - 0.1f;

        // 반드시 Sequence 먼저 생성
        _suckTween = DOTween.Sequence();

        // // 먼저 작아졌다가
        // _suckTween.Append(
        //     transform.DOScale(shrinkScale, 0.1f)
        //         .SetEase(Ease.InQuad)
        // );

        // 다시 커지는 애니메이션
        _suckTween.Append(
            transform.DOScale(growScale, 0.2f)
                .SetEase(Ease.OutQuad)
        );

        // 아래로 이동은 처음부터 끝까지 계속 진행
        _suckTween.Join(
            transform.DOLocalMoveY(targetY, 0.2f)
                .SetEase(Ease.OutQuad)
        );

    }

    protected virtual void OnPlayerLandTile(Note note)
    {
        if (note != _noteData) return;

        // VFX 생성
        Vector3 vfxPosition = transform.position;
        vfxPosition.y -= 0.7f;
        ObjectPool.Instance.Get(EPoolType.NoteLandVfx).transform.position = vfxPosition;

    }


    public virtual void Initialize(Note noteData, double approachDuration, Transform player)
    {
        _noteData = noteData;
        _approachDuration = approachDuration;
        _spawnTime = _noteData.TargetTime - _approachDuration;
    }

    public virtual void StartApproach()
    {
        _isStartingApproach = true;
    }

    // 타일을 파괴합니다 ** 반드시구현
    public abstract void DestroyTile();


}
