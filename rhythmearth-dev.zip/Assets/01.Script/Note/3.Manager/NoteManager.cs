using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using Cysharp.Threading.Tasks;

public class NoteManager : PersistentSingleton<NoteManager>, IResettable
{
    [Header("음악")]
    [SerializeField] private string _chartPath = ""; // MusicManager가 없을 때 사용할 차트 경로

    [Tooltip("음수면 타일이 더 느리게 양수면 타일이 더 빠르게 도착함 - 실제 노트의 타이밍보다")]
    [field: SerializeField] public float visualOffset { get; private set; }

    [field: Header("타이밍 윈도우")]
    [field: SerializeField] public float PerfectWindow { get; private set; } = 0.1f;
    [field: SerializeField] public float GoodWindow { get; private set; } = 0.2f;
    [field: SerializeField] public float BadWindow { get; private set; } = 0.3f;

    [Header("나오는 타이밍 몇 초전")]
    [SerializeField] private float _tileSpawnLeadTime = 1.5f;

    public double SongPosition { get; private set; }

    private Queue<Note> _notes = new Queue<Note>();
    private Queue<Note> _activeNotes = new Queue<Note>();
    private Queue<double> _targetTimes = new Queue<double>();

    private JudgementSystem _judgementSystem;
    private ComboSystem _comboSystem;
    private ScoreSystem _scoreSystem;
    private NoteRepository _repository;

    // 컨트롤러들
    private NoteSpawnSystem _noteSpawner;
    public NoteSpawnSystem NoteSpawnSystem => _noteSpawner;
    private NoteTimeSystem _noteTimeSystem;
    private TapNoteController _tapNoteController;
    private HoldNoteController _holdNoteController;
    private MultiTapNoteController _multiTapNoteController;

    // UniTask 최적화
    private CancellationTokenSource _cancellationTokenSource;

    // 마지막 노트 완료 체크
    private bool _allNotesCompletedEventFired = false;

    // 외부 이벤트
    public event Action<Note> OnHit;
    public event Action<int> OnComboChanged;
    public event Action<Note> OnMiss;
    public event Action<Note> OnTileSpawn;
    public event Action<EJudgement> OnJudgement;
    public event Action<Note> OnPlayerPassedTile;
    public event Action<Note> OnPlayerLandTile;
    public event Action<float> OnNoteTarget;
    public event Action<Note> OnHoldNoteStart;
    public event Action<Note> OnHoldNoteEnd;
    public event Action OnNotesLoaded; // 노트가 로드되고 초기화 완료되었을 때 발생
    public event Action<int> OnScoreChanged; // 점수가 변경되었을 때 발생 (현재 점수 전달)
    public event Action OnAllNotesCompleted; // 모든 노트가 완료되었을 때 발생

    public void TempTriger()
    {
        OnNotesLoaded?.Invoke();
    }

    /// 모든 노트가 완료되었는지 확인
    public bool IsAllNotesCompleted =>
        _comboSystem.GetMaxCombo() > 0 &&
        _notes.Count == 0 &&
        _activeNotes.Count == 0;

    protected override void Awake()
    {
        base.Awake();
        _repository = new NoteRepository();

        // 시스템 초기화
        _judgementSystem = new JudgementSystem(PerfectWindow, GoodWindow, BadWindow);
        _comboSystem = new ComboSystem();
        _scoreSystem = new ScoreSystem();

        // 컨트롤러 초기화 (생성자에서 의존성 주입)
        _noteSpawner = new NoteSpawnSystem(_tileSpawnLeadTime, _notes, _activeNotes, _targetTimes);
        _noteTimeSystem = new NoteTimeSystem(_targetTimes, _activeNotes, _judgementSystem, _comboSystem);
        _tapNoteController = new TapNoteController(_activeNotes, _judgementSystem, _comboSystem);
        _holdNoteController = new HoldNoteController(_activeNotes, _judgementSystem, _comboSystem);
        _multiTapNoteController = new MultiTapNoteController(_activeNotes, _judgementSystem, _comboSystem);

        // 이벤트 연결
        _judgementSystem.OnJudgement += (judgement) => OnJudgement?.Invoke(judgement);
        _comboSystem.OnComboChanged += (combo) => OnComboChanged?.Invoke(combo);

        // 스코어 시스템 이벤트 연결 (판정 발생 시 점수 추가)
        _judgementSystem.OnJudgement += (judgement) =>
        {
            int currentCombo = _comboSystem.GetCurrentCombo();
            _scoreSystem.AddScore(judgement, currentCombo);
        };

        // 스코어 변경 이벤트 연결
        _scoreSystem.OnScoreChanged += (score) => OnScoreChanged?.Invoke(score);

        //노트 스포너 이벤트
        _noteSpawner.OnTileSpawn += (note) => OnTileSpawn?.Invoke(note);

        //노트 타임 시스템 이벤트
        _noteTimeSystem.OnNoteTarget += (targetTime) => OnNoteTarget?.Invoke(targetTime);
        _noteTimeSystem.OnMiss += (note) => OnMiss?.Invoke(note);

        //탭노트 이벤트
        _tapNoteController.OnMiss += (note) => OnMiss?.Invoke(note);
        _tapNoteController.OnHit += (note) => OnHit?.Invoke(note);
        //홀드노트 이벤트
        _holdNoteController.OnMiss += (note) => OnMiss?.Invoke(note);
        _holdNoteController.OnHoldNoteStart += (note) => OnHoldNoteStart?.Invoke(note);
        _holdNoteController.OnHoldNoteEnd += (note) => OnHoldNoteEnd?.Invoke(note);

        //멀티탭노트 이벤트
        _multiTapNoteController.OnMiss += (note) => OnMiss?.Invoke(note);


    }

    private void Start()
    {
        // UniTask 기반 노트 처리를 위한 CancellationTokenSource 초기화
        _cancellationTokenSource = new CancellationTokenSource();
    }

    public void StartGame()
    {
        LoadSelectedMusic();
        ProcessNotesAsync(_cancellationTokenSource.Token).Forget();
    }

    protected override void OnDestroy()
    {
        base.OnDestroy();

        _cancellationTokenSource?.Cancel();
        _cancellationTokenSource?.Dispose();

    }

    // MusicManager에서 선택된 곡 로드 (없으면 _chartPath 사용)
    private void LoadSelectedMusic()
    {
        if (MusicManager.Instance != null && MusicManager.Instance.SelectedMusic != null)
        {
            Music selectedMusic = MusicManager.Instance.SelectedMusic;
            string chartPath = MusicManager.Instance.GetSelectedChartPath();

            if (string.IsNullOrEmpty(chartPath))
            {
                Debug.LogError($"선택된 난이도({MusicManager.Instance.SelectedDifficulty})의 차트가 없습니다!");
                return;
            }

            // 기존 Queue를 Clear하고 새 노트들로 채움
            Queue<Note> loadedNotes = _repository.LoadChartAndSetupGame(chartPath);
            _notes.Clear();
            foreach (var note in loadedNotes)
            {
                _notes.Enqueue(note);
            }

            // 최대 콤보 계산
            _comboSystem.CalculateMaxCombo(loadedNotes);

            // 최대 점수 계산
            _scoreSystem.CalculateMaxScore(_comboSystem.GetMaxCombo());

            if (!string.IsNullOrEmpty(selectedMusic.AudioClipPath))
            {
                if (SoundManager.Instance == null)
                {
                    Debug.LogError("SoundManager 인스턴스를 찾을 수 없습니다!");
                    return;
                }
            }
            else
            {
                Debug.LogWarning("선택된 곡의 AudioClip 경로가 비어있습니다!");

            }

            Debug.Log($"곡 로드 완료: {selectedMusic.SongName} - {MusicManager.Instance.SelectedDifficulty}");

            // 노트 로드 완료 이벤트 발생 (판정선 초기화 시작)
            OnNotesLoaded?.Invoke();
        }
        else
        {
            if (string.IsNullOrEmpty(_chartPath))
            {
                Debug.LogError("MusicManager가 없고 _chartPath도 설정되지 않았습니다!");
                return;
            }

            Debug.LogWarning("MusicManager를 찾을 수 없습니다. Inspector에 설정된 차트 경로를 사용합니다.");

            // 기존 Queue를 Clear하고 새 노트들로 채움
            Queue<Note> loadedNotes = _repository.LoadChartAndSetupGame(_chartPath);
            _notes.Clear();
            foreach (var note in loadedNotes)
            {
                _notes.Enqueue(note);
            }

            // 최대 콤보 계산
            _comboSystem.CalculateMaxCombo(loadedNotes);

            // 최대 점수 계산
            _scoreSystem.CalculateMaxScore(_comboSystem.GetMaxCombo());

            //SoundManager.Instance.PlayBGM(2.0);
            Debug.Log($"차트 로드 완료: {_chartPath}");

            // 노트 로드 완료 이벤트 발생 (판정선 초기화 시작)
            OnNotesLoaded?.Invoke();
        }
    }

    private void Update()
    {
        UpdateSongPosition();
        _noteTimeSystem.CheckNoteTargetTime(SongPosition);
    }

    //노트 처리 메인 루프
    private async UniTaskVoid ProcessNotesAsync(CancellationToken ct)
    {
        if (_notes.Count <= 0)
        {
            Debug.LogWarning("노트가 없습니다! 노트 처리를 시작할 수 없습니다.");
            return;
        }

        while (!ct.IsCancellationRequested && _notes.Count > 0)
        {
            try
            {
                // InGameManager가 없으면 루프 중단 (로비 씬으로 돌아간 경우)
                if (InGameManager.Instance == null)
                {
                    Debug.Log("[NoteManager] InGameManager가 없어 ProcessNotesAsync 중단");
                    break;
                }

                await _noteSpawner.ProcessTileSpawningAsync(SongPosition, ct);
                ProcessNoteTimeout();
                await UniTask.Yield(ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }
    }

    private void UpdateSongPosition()
    {
        if (SoundManager.Instance != null)
        {
            double bgmTime = SoundManager.Instance.GetCurrentBGMTime();
            SongPosition = (float)Mathf.Max(0, (float)bgmTime);
        }
    }

    private void ProcessNoteTimeout()
    {
        _noteTimeSystem.ProcessNoteTimeout(
            SongPosition,
            _holdNoteController.IsHoldNoteActive,
            _multiTapNoteController.IsMultiTapNoteActive,
            out bool shouldActivateHold
        );

        if (shouldActivateHold)
        {
            _holdNoteController.SetHoldActive(true);
        }
    }

    // 일반 노트 판정을 처리
    public bool CheckTapNote(EDirectionType direction, out EJudgement judgement)
    {
        return _tapNoteController.CheckTapNote(direction, out judgement, SongPosition);
    }

    // 멀티탭 노트 시작 판정을 처리
    public bool CheckMultiTapNoteStart(EDirectionType direction, out EJudgement judgement)
    {
        return _multiTapNoteController.CheckMultiTapNoteStart(direction, out judgement, SongPosition);
    }

    // 멀티탭 노트 종료 처리
    public bool CheckMultiTapNoteEnd()
    {
        double multiTapEndTime = _multiTapNoteController.GetMultiTapEndTime();
        return _multiTapNoteController.CheckMultiTapNoteEnd(SongPosition, multiTapEndTime);
    }

    // 홀드 노트 시작 판정을 처리
    public bool CheckHoldNoteStart(EDirectionType direction, out EJudgement judgement)
    {
        return _holdNoteController.CheckHoldNoteStart(direction, out judgement, SongPosition);
    }

    /// 홀드 노트 종료 시점이 판정 윈도우 내에 있는지 확인
    public bool IsWithinHoldEndWindow(double currentTime, double holdEndTime)
    {
        return _holdNoteController.IsWithinHoldEndWindow(currentTime, holdEndTime);
    }

    // 홀드 노트 종료 판정 처리
    public bool CheckHoldNoteEnd(double currentTime, double holdEndTime, out EJudgement judgement)
    {
        return _holdNoteController.CheckHoldNoteEnd(currentTime, holdEndTime, out judgement);
    }

    // 홀드 노트 종료 처리 (기존 메서드)
    public void CompleteHoldNote(bool isSuccess)
    {
        _holdNoteController.CompleteHoldNote(isSuccess);
    }

    public bool TryGetCurrentNote(out Note note)
    {
        if (_activeNotes.TryPeek(out var comp))
        {
            note = comp;
            return true;
        }
        note = null;
        return false;
    }

    public bool TryGetFirstNote(out Note note)
    {
        if (_notes.TryPeek(out var comp))
        {
            note = comp;
            return true;
        }
        note = null;
        return false;
    }

    public bool TryGetNextNote(out Note nextNote)
    {
        nextNote = null;

        if (_activeNotes.Count < 2)
            return false;

        var enumerator = _activeNotes.GetEnumerator();
        enumerator.MoveNext();
        enumerator.MoveNext();
        nextNote = enumerator.Current;
        return true;
    }

    /// 멀티탭 노트의 종료 시점을 계산
    public double GetMultiTapEndTime()
    {
        return _multiTapNoteController.GetMultiTapEndTime();
    }

    /// 플레이어가 타일을 지나갔음을 알림
    public void NotifyPlayerPassedTile(Note note)
    {
        OnPlayerPassedTile?.Invoke(note);
    }

    /// 플레이어가 타일에 착지했음을 알림 (점프 애니메이션 완료 후)
    public void NotifyPlayerLandedOnTile(Note note)
    {
        OnPlayerLandTile?.Invoke(note);
        // 모든 노트 완료 체크
        if (!_allNotesCompletedEventFired && IsAllNotesCompleted)
        {
            _allNotesCompletedEventFired = true;
            OnAllNotesCompleted?.Invoke();
        }

    }

    /// 현재 콤보 수를 반환
    public int GetCurrentCombo()
    {
        return _comboSystem.GetCurrentCombo();
    }

    /// 최대 콤보 수를 반환
    public int GetMaxCombo()
    {
        return _comboSystem.GetMaxCombo();
    }

    /// 현재 점수를 반환
    public int GetCurrentScore()
    {
        return _scoreSystem.CurrentScore;
    }

    /// 최대 점수를 반환
    public int GetMaxScore()
    {
        return _scoreSystem.MaxScore;
    }

    /// 정확도를 반환 (0~100%)
    public float GetAccuracy()
    {
        return _scoreSystem.GetAccuracy();
    }

    /// 등급을 반환 (S, A, B, C, D, F)
    public string GetGrade()
    {
        return _scoreSystem.GetGrade();
    }

    /// 점수 비율을 반환 (0~1)
    public float GetScoreRatio()
    {
        return _scoreSystem.GetScoreRatio();
    }

    /// Perfect 판정 횟수를 반환
    public int GetPerfectCount()
    {
        return _scoreSystem.PerfectCount;
    }

    /// Good 판정 횟수를 반환
    public int GetGoodCount()
    {
        return _scoreSystem.GoodCount;
    }

    /// Bad 판정 횟수를 반환
    public int GetBadCount()
    {
        return _scoreSystem.BadCount;
    }

    /// Miss 판정 횟수를 반환
    public int GetMissCount()
    {
        return _scoreSystem.MissCount;
    }

    /// 총 판정 횟수를 반환
    public int GetTotalJudgementCount()
    {
        return _scoreSystem.GetTotalJudgementCount();
    }

    public void ResetManager()
    {
        // CancellationToken 취소
        _cancellationTokenSource?.Cancel();
        _cancellationTokenSource?.Dispose();
        _cancellationTokenSource = new CancellationTokenSource();

        // 큐 초기화
        _notes.Clear();
        _activeNotes.Clear();
        _targetTimes.Clear();

        // 상태 초기화
        SongPosition = 0;
        _allNotesCompletedEventFired = false;

        LoadSelectedMusic();
        ProcessNotesAsync(_cancellationTokenSource.Token).Forget();
        Debug.Log("NoteManager 상태 초기화");
    }
}
