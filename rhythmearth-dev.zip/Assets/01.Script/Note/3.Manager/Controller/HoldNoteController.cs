using System;
using System.Collections.Generic;

/// <summary>
/// 홀드 노트 처리를 담당하는 클래스
/// </summary>
public class HoldNoteController
{
    private bool _isHoldNoteActive = false;
    private readonly Queue<Note> _activeNotes;
    private readonly JudgementSystem _judgementSystem;
    private readonly ComboSystem _comboSystem;

    public event Action<Note> OnHoldNoteStart;
    public event Action<Note> OnHoldNoteEnd;
    public event Action<Note> OnMiss;

    public bool IsHoldNoteActive => _isHoldNoteActive;

    public HoldNoteController(Queue<Note> activeNotes, JudgementSystem judgementSystem, ComboSystem comboSystem)
    {
        _activeNotes = activeNotes;
        _judgementSystem = judgementSystem;
        _comboSystem = comboSystem;
    }

    public void SetHoldActive(bool active)
    {
        _isHoldNoteActive = active;
    }

    /// <summary>
    /// 홀드 노트 시작 판정을 처리
    /// </summary>
    public bool CheckHoldNoteStart(EDirectionType direction, out EJudgement judgement, double songPosition)
    {
        if (_activeNotes.Count == 0)
        {
            judgement = EJudgement.Miss;
            return false;
        }

        Note noteToJudge = _activeNotes.Peek();

        // 홀드 노트가 아니면 false 반환
        if (noteToJudge.NoteType != ENoteType.Hold)
        {
            judgement = EJudgement.Miss;
            return false;
        }

        double timeDifference = songPosition - noteToJudge.TargetTime;

        // 판정 윈도우를 벗어난 입력은 무시
        if (!_judgementSystem.IsWithinJudgementWindow((float)timeDifference))
        {
            judgement = EJudgement.Miss;
            return false;
        }

        // 방향이 틀렸을 경우 Miss 처리
        if (noteToJudge.TargetDir != direction)
        {
            ProcessMiss(noteToJudge);
            judgement = EJudgement.Miss;
            return false;
        }

        // 정확한 입력 처리 - 홀드 시작 판정
        judgement = _judgementSystem.CalculateJudgement((float)timeDifference);
        
        // 홀드 시작 시 콤보 증가 및 판정 처리
        _comboSystem.IncreaseCombo();
        _judgementSystem.TriggerJudgement(judgement);

        // 홀드 활성화 플래그 설정
        _isHoldNoteActive = true;

        // 홀드 시작 이벤트 발생
        OnHoldNoteStart?.Invoke(noteToJudge);
        
        return true;
    }

    /// <summary>
    /// 홀드 노트 종료 시점이 판정 윈도우 내에 있는지 확인
    /// </summary>
    public bool IsWithinHoldEndWindow(double currentTime, double holdEndTime)
    {
        double timeDifference = currentTime - holdEndTime;
        return _judgementSystem.IsWithinJudgementWindow((float)timeDifference);
    }

    /// <summary>
    /// 홀드 노트 종료 판정 처리 (판정 윈도우 적용)
    /// </summary>
    public bool CheckHoldNoteEnd(double currentTime, double holdEndTime, out EJudgement judgement)
    {
        if (_activeNotes.Count == 0)
        {
            judgement = EJudgement.Miss;
            return false;
        }

        Note noteToJudge = _activeNotes.Peek();
        if (noteToJudge.NoteType != ENoteType.Hold)
        {
            judgement = EJudgement.Miss;
            return false;
        }

        // 홀드 종료 시점과의 시간 차이 계산
        double timeDifference = currentTime - holdEndTime;

        // 판정 계산
        judgement = _judgementSystem.CalculateJudgement((float)timeDifference);

        // 콤보 증가 및 판정 처리
        _comboSystem.IncreaseCombo();
        _judgementSystem.TriggerJudgement(judgement);

        noteToJudge.Judge();
        _activeNotes.Dequeue();

        // 홀드 비활성화 플래그 해제
        _isHoldNoteActive = false;

        // 홀드 종료 이벤트 발생
        OnHoldNoteEnd?.Invoke(noteToJudge);

        return true;
    }

    /// <summary>
    /// 홀드 노트 종료 처리 (기존 메서드 - 판정 윈도우 없이)
    /// </summary>
    public void CompleteHoldNote(bool isSuccess)
    {
        if (_activeNotes.Count == 0) return;

        Note noteToJudge = _activeNotes.Peek();
        if (noteToJudge.NoteType != ENoteType.Hold) return;

        if (isSuccess)
        {
            // 성공 처리
            _comboSystem.IncreaseCombo();
            _judgementSystem.TriggerJudgement(EJudgement.Perfect);
        }
        else
        {
            // 실패 처리
            _comboSystem.ResetCombo();
            _judgementSystem.TriggerJudgement(EJudgement.Miss);
            OnMiss?.Invoke(noteToJudge);
        }

        noteToJudge.Judge();
        _activeNotes.Dequeue();

        // 홀드 비활성화 플래그 해제
        _isHoldNoteActive = false;

        // 홀드 종료 이벤트 발생
        OnHoldNoteEnd?.Invoke(noteToJudge);
    }

    private void ProcessMiss(Note note)
    {
        _comboSystem.ResetCombo();
        OnMiss?.Invoke(note);
        _judgementSystem.TriggerJudgement(EJudgement.Miss);
        note.Judge();
        _activeNotes.Dequeue();
    }
}
