using System;
using System.Collections.Generic;

/// <summary>
/// 멀티탭 노트 처리를 담당하는 클래스
/// </summary>
public class MultiTapNoteController
{
    private bool _isMultiTapNoteActive = false;
    private readonly Queue<Note> _activeNotes;
    private readonly JudgementSystem _judgementSystem;
    private readonly ComboSystem _comboSystem;

    public event Action<Note> OnMiss;

    public bool IsMultiTapNoteActive => _isMultiTapNoteActive;

    public MultiTapNoteController(Queue<Note> activeNotes, JudgementSystem judgementSystem, ComboSystem comboSystem)
    {
        _activeNotes = activeNotes;
        _judgementSystem = judgementSystem;
        _comboSystem = comboSystem;
    }

    public void SetMultiTapActive(bool active)
    {
        _isMultiTapNoteActive = active;
    }

    /// <summary>
    /// 멀티탭 노트 시작 판정을 처리 (타이밍 및 방향 검증)
    /// </summary>
    public bool CheckMultiTapNoteStart(EDirectionType direction, out EJudgement judgement, double songPosition)
    {
        if (_activeNotes.Count == 0)
        {
            judgement = EJudgement.Miss;
            return false;
        }

        Note noteToJudge = _activeNotes.Peek();

        // 멀티탭 노트가 아니면 false 반환
        if (noteToJudge.NoteType != ENoteType.MultiTapNote)
        {
            judgement = EJudgement.Miss;
            return false;
        }

        double timeDifference = songPosition - noteToJudge.TargetTime;

        // 판정 윈도우를 벗어난 입력은 무시
        if (!_judgementSystem.IsWithinJudgementWindow((float)timeDifference))
        {
            judgement = EJudgement.Miss;
            return false;
        }

        // 방향이 틀렸을 경우 Miss 처리
        if (noteToJudge.TargetDir != direction)
        {
            ProcessMiss(noteToJudge);
            judgement = EJudgement.Miss;
            return false;
        }

        // 정확한 입력 처리 - 멀티탭 시작 판정
        judgement = _judgementSystem.CalculateJudgement((float)timeDifference);
        
        // 멀티탭 시작 시 콤보 증가 및 판정 표시
        _comboSystem.IncreaseCombo();
        _judgementSystem.TriggerJudgement(judgement);

        // 멀티탭 활성화 플래그 설정
        _isMultiTapNoteActive = true;

        // 착지 이벤트 발생
        //OnPlayerLandTile?.Invoke(noteToJudge);
        
        return true;
    }

    /// <summary>
    /// 멀티탭 노트 종료 처리
    /// </summary>
    public bool CheckMultiTapNoteEnd(double songPosition, double multiTapEndTime)
    {
        if (_activeNotes.Count == 0) return false;

        Note noteToJudge = _activeNotes.Peek();
        if (noteToJudge.NoteType != ENoteType.MultiTapNote) return false;

        // 멀티탭 종료 시점이 지났는지 확인
        if (songPosition >= multiTapEndTime)
        {
            _judgementSystem.TriggerJudgement(EJudgement.Perfect);
            noteToJudge.Judge();
            _activeNotes.Dequeue();

            // 멀티탭 비활성화 플래그 해제
            _isMultiTapNoteActive = false;

            return true;
        }

        return false;
    }

    /// <summary>
    /// 멀티탭 노트의 종료 시점을 계산합니다 (다음 노트의 타겟 타임 - 배드 윈도우 * 2)
    /// </summary>
    public double GetMultiTapEndTime()
    {
        if (_activeNotes.Count == 0)
            return double.MaxValue;

        Note currentNote = _activeNotes.Peek();
        if (currentNote.NoteType != ENoteType.MultiTapNote)
            return double.MaxValue;

        // 다음 노트가 있는지 확인
        if (_activeNotes.Count < 2)
        {
            // 다음 노트가 없으면 현재 노트의 타겟 타임 + 배드 윈도우
            return currentNote.TargetTime + _judgementSystem.BadWindow;
        }

        // 다음 노트 가져오기
        var enumerator = _activeNotes.GetEnumerator();
        enumerator.MoveNext(); // 현재 노트
        enumerator.MoveNext(); // 다음 노트
        Note nextNote = enumerator.Current;

        // 다음 노트의 타겟 타임 - 배드 윈도우 * 2 (다음 노트 준비 시간 확보)
        return nextNote.TargetTime - (_judgementSystem.BadWindow * 2);
    }

    private void ProcessMiss(Note note)
    {
        _comboSystem.ResetCombo();
        OnMiss?.Invoke(note);
        _judgementSystem.TriggerJudgement(EJudgement.Miss);
        note.Judge();
       // _activeNotes.Dequeue();
    }
}
