using System;
using System.Collections.Generic;

/// <summary>
/// 일반 탭 노트 판정을 담당하는 클래스
/// </summary>
public class TapNoteController
{
    private readonly Queue<Note> _activeNotes;
    private readonly JudgementSystem _judgementSystem;
    private readonly ComboSystem _comboSystem;

    public event Action<Note> OnMiss;
    public event Action<Note> OnHit;
    public TapNoteController(Queue<Note> activeNotes, JudgementSystem judgementSystem, ComboSystem comboSystem)
    {
        _activeNotes = activeNotes;
        _judgementSystem = judgementSystem;
        _comboSystem = comboSystem;
    }

    /// <summary>
    /// 일반 노트 판정을 처리
    /// </summary>
    public bool CheckTapNote(EDirectionType direction, out EJudgement judgement, double songPosition)
    {
        if (_activeNotes.Count == 0)
        {
            judgement = EJudgement.Miss;
            return false;
        }

        Note noteToJudge = _activeNotes.Peek();

        double timeDifference = songPosition - noteToJudge.TargetTime;

        // 판정 윈도우를 벗어난 입력은 무시
        if (!_judgementSystem.IsWithinJudgementWindow((float)timeDifference))
        {
            judgement = EJudgement.Miss;
            return false;
        }

        // 방향이 틀렸을 경우 Miss 처리
        if (noteToJudge.TargetDir != direction)
        {
            ProcessMiss(noteToJudge);
            judgement = EJudgement.Miss;
            return false;
        }

        ObjectPool.Instance.Get(EPoolType.NoteHitVfx).transform.position = noteToJudge.TilePosition;
        // 정확한 입력 처리
        judgement = _judgementSystem.CalculateJudgement((float)timeDifference);

        OnHit?.Invoke(noteToJudge);
        _comboSystem.IncreaseCombo();
        _judgementSystem.TriggerJudgement(judgement);
        noteToJudge.Judge();
        _activeNotes.Dequeue();
        return true;
    }
    private void ProcessMiss(Note note)
    {
        _comboSystem.ResetCombo();
        OnMiss?.Invoke(note);
        _judgementSystem.TriggerJudgement(EJudgement.Miss);
        note.Judge();
        //_activeNotes.Dequeue();
    }
}
