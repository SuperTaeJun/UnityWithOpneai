using System;
using UnityEngine;
public enum EJudgement
{
    Perfect,
    Good,
    Bad,
    Miss
}
/// 노트 판정을 담당하는 시스템
public class JudgementSystem
{
    private readonly float _perfectWindow;
    private readonly float _goodWindow;
    private readonly float _badWindow;

    public event Action<EJudgement> OnJudgement;

    public JudgementSystem(float perfectWindow, float goodWindow, float badWindow)
    {
        _perfectWindow = perfectWindow;
        _goodWindow = goodWindow;
        _badWindow = badWindow;
    }

    /// 시간 차이를 기반으로 판정을 계산합니다
    public EJudgement CalculateJudgement(float timeDifference)
    {
        timeDifference = Mathf.Abs(timeDifference);

        if (timeDifference <= _perfectWindow)
            return EJudgement.Perfect;
        else if (timeDifference <= _goodWindow)
            return EJudgement.Good;
        else if (timeDifference <= _badWindow)
            return EJudgement.Bad;
        else
            return EJudgement.Miss;
    }

    /// 입력이 판정 윈도우 내에 있는지 확인합니다
    public bool IsWithinJudgementWindow(float timeDifference)
    {
        return Mathf.Abs(timeDifference) <= _badWindow;
    }

    /// 판정 이벤트를 발생시킵니다
    public void TriggerJudgement(EJudgement judgement)
    {
        OnJudgement?.Invoke(judgement);
    }

    public float PerfectWindow => _perfectWindow;
    public float GoodWindow => _goodWindow;
    public float BadWindow => _badWindow;
}
