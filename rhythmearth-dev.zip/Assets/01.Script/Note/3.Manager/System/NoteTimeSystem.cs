using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 노트 타이밍 관리를 담당하는 클래스
/// </summary>
public class NoteTimeSystem
{
    private readonly Queue<double> _targetTimes;
    private readonly Queue<Note> _activeNotes;
    private readonly JudgementSystem _judgementSystem;
    private readonly ComboSystem _comboSystem;

    public event Action<float> OnNoteTarget;
    public event Action<Note> OnMiss;
    public NoteTimeSystem(
        Queue<double> targetTimes,
        Queue<Note> activeNotes,
        JudgementSystem judgementSystem,
        ComboSystem comboSystem)
    {
        _targetTimes = targetTimes;
        _activeNotes = activeNotes;
        _judgementSystem = judgementSystem;
        _comboSystem = comboSystem;
    }

    /// <summary>
    /// 액티브 노트들의 타겟 타임을 체크하여 착지 이벤트 발생
    /// </summary>
    public void CheckNoteTargetTime(double songPosition)
    {
        if (_targetTimes.Count == 0) return;

        // 첫 번째 타겟 타임만 체크 (Queue는 순서대로 처리되므로)
        if (_targetTimes.TryPeek(out double targetTime))
        {
            if (songPosition >= targetTime - _judgementSystem.BadWindow)
            {
                OnNoteTarget?.Invoke((float)targetTime);
                _targetTimes.Dequeue();
            }
        }
    }

    /// 노트 타임아웃 처리
    public void ProcessNoteTimeout(
        double songPosition,
        bool isHoldNoteActive,
        bool isMultiTapNoteActive,
        out bool shouldActivateHold)
    {
        shouldActivateHold = false;

        if (InGameManager.Instance.CurrentState != EGameState.Playing)
            return;

        if (!_activeNotes.TryPeek(out Note oldestNote))
            return;
        if (oldestNote.NoteType == ENoteType.MultiTapNote)
        {
            // 이미 멀티탭이 시작되었으면 타임아웃 체크 안 함
            if (isMultiTapNoteActive)
                return;
        }            // 이미 홀드가 시작되었으면 타임아웃 체크 안 함
        if (isHoldNoteActive)
            return;        // 일반 노트 타임아웃 처리
        if (songPosition > oldestNote.TargetTime + _judgementSystem.BadWindow)
        {
            ProcessMiss(oldestNote);
        }
    }

    /// 노트 Miss 처리
    private void ProcessMiss(Note note)
    {
        _comboSystem.ResetCombo();
        OnMiss?.Invoke(note);
        _judgementSystem.TriggerJudgement(EJudgement.Miss);
        note.Judge();
        _activeNotes.Dequeue();
    }
}
