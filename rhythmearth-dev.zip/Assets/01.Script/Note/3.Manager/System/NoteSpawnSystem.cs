using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using Cysharp.Threading.Tasks;

/// <summary>
/// 노트 스폰을 담당하는 클래스
/// </summary>
public class NoteSpawnSystem
{
    private readonly float _tileSpawnLeadTime;
    private readonly Queue<Note> _notes;
    private readonly Queue<Note> _activeNotes;
    private readonly Queue<double> _targetTimes;

    public event Action<Note> OnTileSpawn;

    public NoteSpawnSystem(float tileSpawnLeadTime, Queue<Note> notes, Queue<Note> activeNotes, Queue<double> targetTimes)
    {
        _tileSpawnLeadTime = tileSpawnLeadTime;
        _notes = notes;
        _activeNotes = activeNotes;
        _targetTimes = targetTimes;
    }

    /// <summary>
    /// 타일 스폰 처리
    /// </summary>
    public UniTask ProcessTileSpawningAsync(double songPosition, CancellationToken ct)
    {
        // InGameManager null 체크 추가
        if (InGameManager.Instance == null)
            return UniTask.CompletedTask;

        if (InGameManager.Instance.CurrentState != EGameState.Playing)
            return UniTask.CompletedTask;

        // 무한 루프 방지
        if (_notes.Count == 0 || ct.IsCancellationRequested)
            return UniTask.CompletedTask;

        if (!_notes.TryPeek(out Note nextNote))
            return UniTask.CompletedTask;

        // 멀티탭 노트는 즉시 생성
        if (nextNote.NoteType == ENoteType.MultiTapNote)
        {
            _activeNotes.Enqueue(nextNote);
            OnTileSpawn?.Invoke(nextNote);
            nextNote.Activate();
            _notes.Dequeue();
            return UniTask.CompletedTask;
        }

        // 이미 활성화된 노트는 스킵
        if (nextNote.IsActivated)
            return UniTask.CompletedTask;

        // 스폰 시간이 되었는지 확인
        if (songPosition >= nextNote.TargetTime - _tileSpawnLeadTime)
        {
            _activeNotes.Enqueue(nextNote);
            _targetTimes.Enqueue(nextNote.TargetTime); // 타겟 타임을 별도 큐에 저장
            OnTileSpawn?.Invoke(nextNote);
            nextNote.Activate();
            _notes.Dequeue();
        }

        return UniTask.CompletedTask;
    }
}
