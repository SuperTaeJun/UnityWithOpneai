using System;
using UnityEngine;

/// <summary>
/// 점수 계산 및 관리를 담당하는 시스템
/// </summary>
public class ScoreSystem
{
    private int _currentScore = 0;
    private int _maxScore = 0;

    // 판정별 기본 점수
    private readonly int _perfectScore;
    private readonly int _goodScore;
    private readonly int _badScore;
    private readonly int _missScore;

    // 콤보 보너스 설정
    private readonly bool _useComboBonus;
    private readonly int _comboThreshold; // 콤보 보너스가 시작되는 콤보 수
    private readonly float _comboBonusMultiplier; // 콤보 보너스 배율

    // 판정별 카운트
    private int _perfectCount = 0;
    private int _goodCount = 0;
    private int _badCount = 0;
    private int _missCount = 0;

    public event Action<int> OnScoreChanged;
    public event Action<int, EJudgement> OnScoreAdded; // 추가된 점수와 판정

    public int CurrentScore => _currentScore;
    public int MaxScore => _maxScore;
    public int PerfectCount => _perfectCount;
    public int GoodCount => _goodCount;
    public int BadCount => _badCount;
    public int MissCount => _missCount;

    /// <summary>
    /// ScoreSystem 생성자
    /// </summary>
    /// <param name="perfectScore">Perfect 판정 점수</param>
    /// <param name="goodScore">Good 판정 점수</param>
    /// <param name="badScore">Bad 판정 점수</param>
    /// <param name="missScore">Miss 판정 점수</param>
    /// <param name="useComboBonus">콤보 보너스 사용 여부</param>
    /// <param name="comboThreshold">콤보 보너스 시작 콤보 수</param>
    /// <param name="comboBonusMultiplier">콤보 보너스 배율</param>
    public ScoreSystem(
        int perfectScore = 100,
        int goodScore = 50,
        int badScore = 20,
        int missScore = 0,
        bool useComboBonus = true,
        int comboThreshold = 10,
        float comboBonusMultiplier = 0.1f)
    {
        _perfectScore = perfectScore;
        _goodScore = goodScore;
        _badScore = badScore;
        _missScore = missScore;
        _useComboBonus = useComboBonus;
        _comboThreshold = comboThreshold;
        _comboBonusMultiplier = comboBonusMultiplier;
    }

    /// <summary>
    /// 판정에 따라 점수를 추가합니다
    /// </summary>
    /// <param name="judgement">판정 결과</param>
    /// <param name="currentCombo">현재 콤보 수</param>
    public void AddScore(EJudgement judgement, int currentCombo = 0)
    {
        int baseScore = GetBaseScore(judgement);
        int bonusScore = CalculateComboBonus(baseScore, currentCombo);
        int totalScore = baseScore + bonusScore;

        _currentScore += totalScore;
        UpdateJudgementCount(judgement);

        OnScoreChanged?.Invoke(_currentScore);
        OnScoreAdded?.Invoke(totalScore, judgement);

    }

    /// <summary>
    /// 판정에 따른 기본 점수를 반환합니다
    /// </summary>
    private int GetBaseScore(EJudgement judgement)
    {
        return judgement switch
        {
            EJudgement.Perfect => _perfectScore,
            EJudgement.Good => _goodScore,
            EJudgement.Bad => _badScore,
            EJudgement.Miss => _missScore,
            _ => 0
        };
    }

    /// <summary>
    /// 콤보에 따른 보너스 점수를 계산합니다
    /// </summary>
    private int CalculateComboBonus(int baseScore, int currentCombo)
    {
        if (!_useComboBonus || currentCombo < _comboThreshold)
            return 0;

        // 콤보가 임계값을 넘으면 보너스 점수 계산
        int comboOverThreshold = currentCombo - _comboThreshold;
        float bonusMultiplier = 1 + (comboOverThreshold * _comboBonusMultiplier);
        int bonusScore = Mathf.FloorToInt(baseScore * bonusMultiplier) - baseScore;

        return bonusScore;
    }

    /// <summary>
    /// 판정 카운트를 업데이트합니다
    /// </summary>
    private void UpdateJudgementCount(EJudgement judgement)
    {
        switch (judgement)
        {
            case EJudgement.Perfect:
                _perfectCount++;
                break;
            case EJudgement.Good:
                _goodCount++;
                break;
            case EJudgement.Bad:
                _badCount++;
                break;
            case EJudgement.Miss:
                _missCount++;
                break;
        }
    }

    /// <summary>
    /// 최대 점수를 계산합니다 (모든 노트를 Perfect로 처리했을 때)
    /// </summary>
    /// <param name="maxCombo">최대 콤보 수</param>
    public void CalculateMaxScore(int maxCombo)
    {
        _maxScore = 0;

        // 모든 노트를 Perfect로 처리하고 콤보 보너스를 적용
        for (int combo = 1; combo <= maxCombo; combo++)
        {
            int baseScore = _perfectScore;
            int bonusScore = CalculateComboBonus(baseScore, combo);
            _maxScore += baseScore + bonusScore;
        }

        Debug.Log($"최대 점수 계산 완료: {_maxScore} (최대 콤보: {maxCombo})");
    }

    /// <summary>
    /// 현재 점수를 초기화합니다
    /// </summary>
    public void ResetScore()
    {
        _currentScore = 0;
        _perfectCount = 0;
        _goodCount = 0;
        _badCount = 0;
        _missCount = 0;

        OnScoreChanged?.Invoke(_currentScore);
        Debug.Log("점수 초기화");
    }

    /// <summary>
    /// 정확도를 계산합니다 (0~100%)
    /// </summary>
    public float GetAccuracy()
    {
        int totalNotes = _perfectCount + _goodCount + _badCount + _missCount;
        if (totalNotes == 0)
            return 0f;

        // Perfect = 100%, Good = 50%, Bad = 25%, Miss = 0%
        float accuracyScore = (_perfectCount * 100f) + (_goodCount * 50f) + (_badCount * 25f);
        return accuracyScore / totalNotes;
    }

    /// <summary>
    /// 등급을 계산합니다 s
    /// </summary>
    public string GetGrade()
    {
        if (_maxScore == 0)
            return "F";

        float scorePercentage = _currentScore / (float)_maxScore * 100f;

        if (scorePercentage >= 85f)
            return "S";
        else if (scorePercentage >= 70f)
            return "A";
        else if (scorePercentage >= 55f)
            return "B";
        else if (scorePercentage >= 40f)
            return "C";
        else if (scorePercentage >= 30f)
            return "D";
        else
            return "F";
    }

    /// <summary>
    /// 점수 비율을 반환합니다 (0~1)
    /// </summary>
    public float GetScoreRatio()
    {
        if (_maxScore == 0)
            return 0f;

        return _currentScore / (float)_maxScore;
    }

    /// <summary>
    /// 총 판정 횟수를 반환합니다
    /// </summary>
    public int GetTotalJudgementCount()
    {
        return _perfectCount + _goodCount + _badCount + _missCount;
    }
}
