using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 콤보 관리를 담당하는 시스템
/// </summary>
public class ComboSystem
{
    private int _comboCount = 0;
    private int _maxCombo = 0;

    public event Action<int> OnComboChanged;
    public event Action OnComboBreak;

    public int ComboCount => _comboCount;
    public int MaxCombo => _maxCombo;

    public void IncreaseCombo()
    {
        _comboCount++;
        OnComboChanged?.Invoke(_comboCount);
    }
    public void ResetCombo()
    {
        if (_comboCount > 0)
        {
            _comboCount = 0;
            OnComboBreak?.Invoke();
            OnComboChanged?.Invoke(_comboCount);
        }
    }
    public int GetCurrentCombo()
    {
        return _comboCount;
    }

    /// 모든 노트를 기반으로 최대 콤보 수를 계산합니다.
    /// 홀드 노트는 2콤보(시작+끝), 나머지 노트는 1콤보로 계산됩니다.
    public void CalculateMaxCombo(IEnumerable<Note> notes)
    {
        _maxCombo = 0;

        foreach (var note in notes)
        {
            if (note.NoteType == ENoteType.Hold)
            {
                // 홀드 노트는 시작과 끝 2콤보
                _maxCombo += 2;
            }
            else
            {
                // 나머지 노트는 1콤보
                _maxCombo += 1;
            }
        }

        Debug.Log($"최대 콤보 계산 완료: {_maxCombo}");
    }

    /// 계산된 최대 콤보 수를 반환합니다.
    public int GetMaxCombo()
    {
        return _maxCombo;
    }
}
