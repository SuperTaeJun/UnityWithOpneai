using System;
using System.Collections.Generic;

[Serializable]
public class NoteData
{
    public ENoteType noteType;
    public float targetTime;
    public float holdDurationTime;
}

[Serializable]
public class Chart
{
    public float bpm;
    public List<NoteData> notes = new List<NoteData>();
}
